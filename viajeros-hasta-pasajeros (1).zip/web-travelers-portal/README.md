# Web Travelers Portal

Frontend del **Seguro Viajero** (Positiva): cotización, selección de plan y captura de datos de los pasajeros.

Consume el BFF NestJS `viajeros-api`. Puede publicarse bajo una subruta configurando un base path.

---

## Stack

| Tecnología                     | Uso                                             |
| ------------------------------ | ----------------------------------------------- |
| Vue 3 + TypeScript             | UI (`<script setup>`)                           |
| Vite 8                         | Bundler y dev server                            |
| Vue Router 5                   | Rutas del flujo de compra                       |
| PrimeVue 4 (Aura)              | DatePicker y componentes UI (primary `#ff7500`) |
| Tailwind CSS 4                 | Estilos utilitarios                             |
| Vitest                         | Tests unitarios                                 |
| Playwright                     | Tests e2e                                       |
| Husky + lint-staged + Prettier | Pre-commit (formato + tests unitarios)          |

Gestor de paquetes: **Yarn**.

---

## Requisitos

- Node.js 20+ (recomendado LTS)
- Yarn
- BFF Viajeros en local (opcional pero necesario para cotización real): puerto **5001** → `http://localhost:5001/api/viajeros/v1`

Si el BFF no responde, Cotizador/Planes pueden degradar a catálogo/precios de referencia.

---

## Cómo levantar el proyecto

```bash
# 1. Descomprimir y entrar a la carpeta
cd web-travelers-portal

# 2. Dependencias
yarn install

# 3. Variables de entorno
cp .env.example .env
# Editar .env si el BFF no está en localhost:5001

# 4. Desarrollo
yarn dev
```

App en `http://localhost:5173` (o el puerto que indique Vite).

### Scripts útiles

| Script                               | Descripción                                 |
| ------------------------------------ | ------------------------------------------- |
| `yarn dev`                           | Servidor de desarrollo                      |
| `yarn build`                         | Typecheck (`vue-tsc`) + build de producción |
| `yarn preview`                       | Sirve el build local                        |
| `yarn format` / `yarn format:check`  | Prettier                                    |
| `yarn test` / `yarn test:watch`      | Vitest                                      |
| `yarn test:e2e` / `yarn test:e2e:ui` | Playwright (front + BFF levantados)         |

### E2E

Con front en `5173` y BFF en `5001`:

```bash
yarn test:e2e
```

Variables opcionales de Playwright:

| Variable        | Default                 | Descripción                       |
| --------------- | ----------------------- | --------------------------------- |
| `E2E_FRONT_URL` | `http://127.0.0.1:5173` | Base URL del front                |
| `E2E_API_URL`   | `http://127.0.0.1:5001` | Base del BFF (health / metadatos) |

---

## Variables de entorno

Definidas en [`.env.example`](./.env.example). Solo variables con prefijo `VITE_` se exponen al cliente.

| Variable            | Requerida        | Descripción                                                                                                                                                                           |
| ------------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `VITE_API_BASE_URL` | Sí (recomendado) | Base del BFF Viajeros. Default en código: `http://localhost:5001/api/viajeros/v1`.        |
| `VITE_BASE`         | No               | Base path al publicar bajo una subruta, p. ej. `/seguros/individuales/seguro-de-viajero/`. Debe alinearse con la opción `base` de Vite / `import.meta.env.BASE_URL` del router. |

Ejemplo local:

```env
VITE_API_BASE_URL=http://localhost:5001/api/viajeros/v1
```

No commits de `.env` (está en `.gitignore`). Usa solo `.env.example` como plantilla.

---

## Arquitectura

Arquitectura **hexagonal (puertos y adaptadores)** orientada al dominio de viajeros. La UI no habla HTTP directo al BFF: usa casos de uso y puertos; la infraestructura cablea adapters HTTP.

```
src/
├── domain/travelers/          # Modelos y puertos (contratos)
│   ├── models/
│   └── ports/                 # parametria, tarifacion, identidad
├── application/travelers/     # Casos de uso, mappers, sesión
│   ├── use-cases/             # cargar-paises, cotizar-planes, …
│   ├── mappers/
│   └── session/               # cotización en sessionStorage
├── infrastructure/
│   ├── http/                  # Cliente HTTP compartido (viajerosFetch)
│   └── travelers/             # Adapters HTTP + composition root
├── presentation/
│   ├── modules/travelers/     # Páginas, componentes, mocks UI
│   └── shared/layouts/        # MainLayout
├── router/                    # Rutas del flujo
└── shared/                    # Utilidades (p. ej. publicUrl)
```

**Flujo de dependencias:** `presentation` → `application` → `domain` ← `infrastructure` (adapters implementan puertos).

El composition root (`infrastructure/travelers/composition.ts`) exporta una sola instancia de cada puerto cableada a su adapter HTTP.

### Integración BFF

| Capacidad            | Endpoint (relativo a `VITE_API_BASE_URL`)             |
| -------------------- | ----------------------------------------------------- |
| Países / destino     | `GET /parametria/paises`                              |
| Tipos de documento   | `GET /parametria/tipos-documento`                     |
| Cotización de planes | `POST /tarifacion/calculo-prima-planes`               |
| Validación identidad | puerto identidad                                      |

La sesión de cotización (quote CRM, prima, viajeros) vive en `sessionStorage` (`viajeros.cotizacion.v1`).

Timeout HTTP por defecto hacia el BFF: **45 s** (CRM `calculoPrima` en PRE puede tardar ~20–45 s).

### Flujo de pantallas

| Ruta                                          | Página               |
| --------------------------------------------- | -------------------- |
| `/`                                           | Cotizador            |
| `/planes`                                     | Selección Plus / Pro |
| `/pasajeros`                                  | Datos de viajeros    |

---

## Notas importantes

- **Un solo viajero** por cotización (límite temporal en UI; “Agregar viajero” oculto).
- Coberturas comerciales en UI aún usan `planes-mock`; precios/quote vienen del CRM (o stub del BFF).
- Alcance de esta entrega: hasta la pantalla de datos de pasajeros (paso 2). Los pasos 3 y 4 del stepper se muestran como pendientes.
- Pre-commit: Prettier sobre staged + `yarn test`.
- Alias de imports: `@` → `src/`.
- Publicación bajo subruta: configurar base path (`VITE_BASE` / Vite `base`).
