import type { CotizacionSesion } from "@/domain/travelers/models/catalogos.types";

const KEY = "viajeros.cotizacion.v1";

export function leerCotizacionSesion(): CotizacionSesion | null {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CotizacionSesion;
  } catch {
    return null;
  }
}

export function guardarCotizacionSesion(sesion: CotizacionSesion): void {
  sessionStorage.setItem(KEY, JSON.stringify(sesion));
}

export function parchearCotizacionSesion(
  patch: Partial<CotizacionSesion>,
): CotizacionSesion | null {
  const actual = leerCotizacionSesion();
  if (!actual) return null;
  const next = { ...actual, ...patch };
  guardarCotizacionSesion(next);
  return next;
}

export function limpiarCotizacionSesion(): void {
  sessionStorage.removeItem(KEY);
}
