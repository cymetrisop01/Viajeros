import type { PlanUiId } from "@/domain/travelers/models/catalogos.types";

/** IDs CRM Viajeros 2026 (mismo contrato que viajeros-api). */
export const VIAJERO_PLANES = {
  PLUS_INTERNACIONAL: 1453,
  PLUS_NACIONAL: 1454,
  PRO_INTERNACIONAL: 1455,
  PRO_NACIONAL: 1456,
} as const;

export const CODIGO_COLOMBIA = "170";

export function esColombia(codigo: string, nombre?: string): boolean {
  const c = codigo.trim();
  if (c === CODIGO_COLOMBIA || c === "CO" || c.toUpperCase() === "COL") return true;
  return (nombre ?? "").trim().toLowerCase() === "colombia";
}

/** Nacional solo si origen y destino son Colombia. */
export function esViajeNacional(
  origenCodigo: string,
  origenNombre: string,
  destinoCodigo: string,
  destinoNombre: string,
): boolean {
  return esColombia(origenCodigo, origenNombre) && esColombia(destinoCodigo, destinoNombre);
}

export function planCrmId(planUi: PlanUiId, nacional: boolean): number {
  if (planUi === "plus") {
    return nacional ? VIAJERO_PLANES.PLUS_NACIONAL : VIAJERO_PLANES.PLUS_INTERNACIONAL;
  }
  return nacional ? VIAJERO_PLANES.PRO_NACIONAL : VIAJERO_PLANES.PRO_INTERNACIONAL;
}

export function formatoCop(valor: number): string {
  return new Intl.NumberFormat("es-CO").format(Math.round(valor));
}

export function precioFinalLabel(valor: number): string {
  return `COP ${formatoCop(valor)}`;
}

/** Vigencia mock del UI: fecha ida + N días. */
export function sumarDiasIso(iso: string, dias: number): string {
  const fecha = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(fecha.getTime())) return iso;
  fecha.setDate(fecha.getDate() + dias);
  const mes = String(fecha.getMonth() + 1).padStart(2, "0");
  const dia = String(fecha.getDate()).padStart(2, "0");
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

export const DIAS_VIGENCIA_DEFAULT = 17;
