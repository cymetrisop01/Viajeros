import { describe, expect, it } from "vitest";
import { esViajeNacional, planCrmId, VIAJERO_PLANES } from "./plan-crm";

describe("plan-crm", () => {
  it("marca nacional solo Colombia→Colombia", () => {
    expect(esViajeNacional("170", "Colombia", "170", "Colombia")).toBe(true);
    expect(esViajeNacional("170", "Colombia", "europa", "Europa")).toBe(false);
    expect(esViajeNacional("840", "Estados Unidos", "170", "Colombia")).toBe(false);
  });

  it("resuelve IDs CRM Plus/Pro", () => {
    expect(planCrmId("plus", true)).toBe(VIAJERO_PLANES.PLUS_NACIONAL);
    expect(planCrmId("plus", false)).toBe(VIAJERO_PLANES.PLUS_INTERNACIONAL);
    expect(planCrmId("pro", true)).toBe(VIAJERO_PLANES.PRO_NACIONAL);
    expect(planCrmId("pro", false)).toBe(VIAJERO_PLANES.PRO_INTERNACIONAL);
  });
});
