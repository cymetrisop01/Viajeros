const TIPOS_POR_NOMBRE: Record<string, string> = {
  "Cédula de ciudadanía": "CC",
  "Cédula de extranjería": "CE",
  Pasaporte: "PA",
  "Tarjeta de identidad": "TI",
  NIT: "NIT",
};

const GENEROS: Record<string, string> = {
  Femenino: "female",
  Masculino: "male",
  Otro: "other",
};

const CODIGOS_CONOCIDOS = new Set(["CC", "CE", "TI", "PA", "NIT", "RC", "PEP"]);

/** Acepta etiqueta UI o código ya normalizado (CC, CE, …). */
export function tipoDocumentoCodigo(labelOrCodigo: string): string {
  const raw = labelOrCodigo.trim();
  if (!raw) return "CC";
  const upper = raw.toUpperCase();
  if (CODIGOS_CONOCIDOS.has(upper)) return upper;
  return TIPOS_POR_NOMBRE[raw] ?? upper;
}

export function generoCodigo(label: string): string {
  return GENEROS[label] ?? "other";
}

/** Normaliza a yyyy-MM-dd (acepta dd/MM/yyyy). */
export function normalizarFechaIso(raw: string): string {
  const s = raw.trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const dmy = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`;
  return s;
}
