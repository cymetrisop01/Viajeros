import type { TipoDocumentoItem } from "@/domain/travelers/models/catalogos.types";
import type { ParametriaPort } from "@/domain/travelers/ports/parametria.port";

/** Fallback alineado a siniestros MOCK_TIPOS_DOCUMENTO / seed BFF. */
export const TIPOS_DOCUMENTO_FALLBACK: TipoDocumentoItem[] = [
  { codigo: "CC", nombre: "Cédula de ciudadanía" },
  { codigo: "CE", nombre: "Cédula de extranjería" },
  { codigo: "TI", nombre: "Tarjeta de identidad" },
  { codigo: "PA", nombre: "Pasaporte" },
  { codigo: "NIT", nombre: "NIT" },
];

export async function cargarTiposDocumento(port: ParametriaPort): Promise<TipoDocumentoItem[]> {
  try {
    const items = await port.listarTiposDocumento();
    if (!items?.length) return [...TIPOS_DOCUMENTO_FALLBACK];
    return items;
  } catch {
    return [...TIPOS_DOCUMENTO_FALLBACK];
  }
}
