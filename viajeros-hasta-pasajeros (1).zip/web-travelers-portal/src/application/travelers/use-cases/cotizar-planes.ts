import type { CotizacionViaje, PlanTarifa } from "@/domain/travelers/models/catalogos.types";
import type { TarifacionPort } from "@/domain/travelers/ports/tarifacion.port";

/**
 * Cotiza Plus + Pro vía BFF.
 * El BFF hace dos POST a CRM calculoPrima con plan_id según esNacional.
 */
export async function cotizarPlanes(
  port: TarifacionPort,
  viaje: CotizacionViaje,
): Promise<PlanTarifa[]> {
  return port.calcularPrimasPlanes(viaje);
}
