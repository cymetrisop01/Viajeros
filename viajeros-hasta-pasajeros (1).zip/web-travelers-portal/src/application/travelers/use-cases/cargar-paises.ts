import type { PaisItem } from "@/domain/travelers/models/catalogos.types";
import type { ParametriaPort } from "@/domain/travelers/ports/parametria.port";
import { esColombia } from "../mappers/plan-crm";

const FALLBACK: PaisItem[] = [
  { codigo: "170", nombre: "Colombia", iso2: "CO" },
  { codigo: "840", nombre: "Estados Unidos", iso2: "US" },
  { codigo: "724", nombre: "España", iso2: "ES" },
  { codigo: "484", nombre: "México", iso2: "MX" },
];

export async function cargarPaises(port: ParametriaPort): Promise<PaisItem[]> {
  try {
    const items = await port.listarPaises();
    if (!items.length) return FALLBACK;
    return [...items].sort((a, b) => {
      if (esColombia(a.codigo, a.nombre)) return -1;
      if (esColombia(b.codigo, b.nombre)) return 1;
      return a.nombre.localeCompare(b.nombre, "es");
    });
  } catch {
    return FALLBACK;
  }
}

export function paisPorCodigo(paises: PaisItem[], codigo: string): PaisItem | undefined {
  return paises.find((p) => p.codigo === codigo);
}

function normalizarNombrePais(nombre: string): string {
  return nombre.trim().toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
}

export function paisPorNombre(paises: PaisItem[], nombre: string): PaisItem | undefined {
  const n = normalizarNombrePais(nombre);
  return paises.find((p) => normalizarNombrePais(p.nombre) === n);
}
