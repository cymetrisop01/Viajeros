<template>
  <div class="flex min-h-screen flex-col bg-[#f7f7f7] text-[#173748]">
    <TravelersHeader />
    <main class="flex-1">
      <RouterView />
    </main>
    <TravelersFooter />
  </div>
</template>

<script setup lang="ts">
import { TravelersFooter, TravelersHeader } from "@/presentation/modules/travelers/components";
</script>
