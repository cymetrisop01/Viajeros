import { describe, expect, it } from "vitest";
import { mount } from "@vue/test-utils";
import CampoFormulario from "./CampoFormulario.vue";

describe("CampoFormulario", () => {
  it("emite update:modelValue al escribir texto", async () => {
    const wrapper = mount(CampoFormulario, {
      props: {
        etiqueta: "Correo*",
        modelValue: "",
        tipo: "texto",
      },
    });

    const input = wrapper.get("input");
    await input.setValue("camsua@email.com");

    expect(wrapper.emitted("update:modelValue")?.[0]).toEqual(["camsua@email.com"]);
  });

  it("renderiza opciones en tipo lista", () => {
    const wrapper = mount(CampoFormulario, {
      props: {
        etiqueta: "Género*",
        modelValue: "",
        tipo: "lista",
        opciones: ["Femenino", "Masculino"],
      },
    });

    const options = wrapper.findAll("option");
    expect(options.length).toBeGreaterThanOrEqual(3);
    expect(wrapper.text()).toContain("Femenino");
  });
});
