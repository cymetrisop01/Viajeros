<template>
  <!-- Figma 24:10961 — Footer portal siniestros (1440px, padding 40/48) -->
  <footer class="footer-positiva text-white">
    <!-- Bloque principal: franja Vigilado + grid 3 columnas -->
    <div class="footer-main flex w-full bg-[#173748]">
      <aside
        class="footer-vigilado hidden w-[50px] shrink-0 flex-col items-center justify-center self-stretch py-12 md:flex"
        aria-label="Vigilado Superintendencia Financiera de Colombia"
      >
        <img
          :src="$publicUrl('images/footer/icon-vigilado.svg')"
          alt="Icono de vigilado"
          width="10"
          height="139"
          class="h-[139px] w-[10px] shrink-0 object-contain"
          aria-hidden="true"
        />
      </aside>

      <div class="min-w-0 flex-1">
        <div class="footer-inner mx-auto max-w-[1440px] px-10 py-12">
          <div class="footer-grid grid grid-cols-1 gap-8 lg:grid-cols-3 lg:gap-8">
            <!-- Columna 1 -->
            <div class="footer-col flex flex-col gap-10">
              <section class="footer-block">
                <header class="footer-section-head">
                  <span class="footer-icon" aria-hidden="true">
                    <img
                      :src="$publicUrl('images/footer/icon_contacto.svg')"
                      alt="Icono de contacto"
                      width="20"
                      height="20"
                      class="block h-5 w-5"
                    />
                  </span>
                  <h2 class="footer-section-title">Contáctanos</h2>
                </header>
                <div class="footer-body">
                  <p class="footer-row">
                    <span class="footer-label"> Líneas gratuitas de atención nacional </span>
                    <a class="footer-accent" href="tel:018000111170"> 01-8000-111-170 </a>
                  </p>
                  <p class="footer-row">
                    <span class="footer-label"> Líneas de atención en Bogotá </span>
                    <a class="footer-accent" href="tel:+576013307000"> +57 (601) 330-7000 </a>
                  </p>
                  <p class="footer-row">
                    <span class="footer-label">Correo electrónico</span>
                    <a class="footer-accent" href="mailto:servicioalcliente@positiva.gov.co">
                      servicioalcliente@positiva.gov.co
                    </a>
                  </p>
                  <p class="footer-row">
                    <span class="footer-label">PQRD</span>
                    <a
                      class="footer-accent footer-link"
                      href="https://positiva.gov.co/web/guest/pqrd"
                      target="_blank"
                      rel="noopener noreferrer"
                      >Tramita tu PQRD</a
                    >
                  </p>
                </div>
              </section>

              <section class="footer-block">
                <header class="footer-section-head footer-section-head--no-border">
                  <span class="footer-icon" aria-hidden="true">
                    <img
                      :src="$publicUrl('images/footer/icon_sede.svg')"
                      alt="Icono de sede"
                      width="20"
                      height="20"
                      class="block h-5 w-5"
                    />
                  </span>
                  <h2 class="footer-section-title">Sede Administrativa</h2>
                </header>
                <div class="footer-body">
                  <p class="footer-text-block">Autopista Norte Cra. 45 # 94 - 72 Bogotá D.C.</p>
                  <p class="footer-text-block">
                    En esta dirección solo opera la administración central para recibir información
                    dirígete a nuestros
                    <a class="footer-accent footer-link" href="#" @click.prevent
                      >puntos de atención</a
                    >
                  </p>
                </div>
              </section>
            </div>

            <!-- Columna 2 -->
            <section class="footer-block">
              <header class="footer-section-head">
                <span class="footer-icon" aria-hidden="true">
                  <img
                    :src="$publicUrl('images/footer/icon_denuncia.svg')"
                    alt="Icono de denuncia"
                    width="20"
                    height="20"
                    class="block h-5 w-5"
                  />
                </span>
                <h2 class="footer-section-title">Denuncia aquí</h2>
              </header>
              <div class="footer-body">
                <p class="footer-subtitle">Casos de fraude o corrupción</p>
                <p class="footer-row">
                  <span class="footer-label"> Correo electrónico de línea ética </span>
                  <a class="footer-accent" href="mailto:lineaetica@positiva.gov.co">
                    lineaetica@positiva.gov.co
                  </a>
                </p>
                <p class="footer-row">
                  <span class="footer-label">Línea gratuita nacional de denuncia</span>
                  <span class="footer-accent-stack">
                    <a class="footer-accent" href="tel:018000112870">01-8000-112870</a>
                    <a class="footer-accent" href="tel:+576016502209">+57 (601) 650 2209</a>
                    <span class="footer-accent footer-accent-plain"
                      >+57 (601) 650 2200 ext. 9102</span
                    >
                  </span>
                </p>
                <p class="footer-subtitle">Casos de acoso y discriminación</p>
                <p class="footer-row">
                  <span class="footer-label">Línea gratuita nacional de denuncia</span>
                  <span class="footer-accent footer-accent-plain"
                    >+57 (601) 650 2200 ext. 11111</span
                  >
                </p>
                <p class="footer-row">
                  <span class="footer-label">Denuncia virtual</span>
                  <a class="footer-accent footer-link" href="#" @click.prevent
                    >Tramita denuncia virtual</a
                  >
                </p>
              </div>
            </section>

            <!-- Columna 3 -->
            <div class="footer-col flex flex-col gap-10">
              <section class="footer-block">
                <header class="footer-section-head">
                  <span class="footer-icon" aria-hidden="true">
                    <img
                      :src="$publicUrl('images/footer/icon_normativa.svg')"
                      alt="Icono de normativa"
                      width="20"
                      height="20"
                      class="block h-5 w-5"
                    />
                  </span>
                  <h2 class="footer-section-title">Normativa</h2>
                </header>
                <div class="footer-body">
                  <p class="footer-row">
                    <span class="footer-label">Incumplimientos normativos</span>
                    <a class="footer-accent" href="mailto:cumplimientonormativo@positiva.gov.co">
                      cumplimientonormativo@positiva.gov.co
                    </a>
                  </p>
                  <p class="footer-row">
                    <span class="footer-label">Notificaciones judiciales</span>
                    <a class="footer-accent" href="mailto:notificacionesjudiciales@positiva.gov.co">
                      notificacionesjudiciales@positiva.gov.co
                    </a>
                  </p>
                  <p class="footer-row">
                    <span class="footer-label">Defensor del Consumidor</span>
                    <a class="footer-accent" href="mailto:defensordelcliente@positiva.gov.co">
                      defensordelcliente@positiva.gov.co
                    </a>
                  </p>
                </div>
              </section>

              <section class="footer-block footer-block--social">
                <h3 class="footer-social-title">Redes sociales</h3>
                <div class="footer-social-list">
                  <a
                    class="footer-social"
                    href="https://www.facebook.com/PositivaCompaniaDeSeguros"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Facebook"
                  >
                    <img
                      :src="$publicUrl('images/footer/icon_social_facebook.svg')"
                      alt="Icono de Facebook"
                      width="16"
                      height="16"
                      class="footer-social-icon"
                    />
                  </a>
                  <a
                    class="footer-social"
                    href="https://www.instagram.com/positivacol/"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Instagram"
                  >
                    <img
                      :src="$publicUrl('images/footer/icon_social_instagram.svg')"
                      alt="Icono de Instagram"
                      width="16"
                      height="16"
                      class="footer-social-icon"
                    />
                  </a>
                  <a
                    class="footer-social"
                    href="https://x.com/positivacol"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="X (Twitter)"
                  >
                    <img
                      :src="$publicUrl('images/footer/icon_social_x.svg')"
                      alt="Icono de X"
                      width="16"
                      height="16"
                      class="footer-social-icon"
                    />
                  </a>
                  <a
                    class="footer-social"
                    href="https://www.youtube.com/@PositivaColombia"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="YouTube"
                  >
                    <img
                      :src="$publicUrl('images/footer/icon_social_youtube.svg')"
                      alt="Icono de YouTube"
                      width="16"
                      height="16"
                      class="footer-social-icon"
                    />
                  </a>
                </div>
                <img
                  :src="$publicUrl('images/footer/logo-grupo-bicentenario.png')"
                  alt="Grupo Bicentenario"
                  width="160"
                  height="37"
                  class="mt-4 block h-[37px] w-auto"
                />
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Barra enlaces legales + GOV.CO -->
    <div class="footer-legal w-full border-t border-[rgba(255,255,255)] bg-[#173748]">
      <div
        class="footer-inner mx-auto flex max-w-[1440px] flex-col items-center justify-center gap-6 px-10 py-5 lg:flex-row"
      >
        <nav
          class="footer-legal-nav flex flex-wrap items-center justify-center gap-x-2 gap-y-2"
          aria-label="Enlaces legales"
        >
          <a
            class="footer-nav-link"
            href="https://www.positiva.gov.co/politica-de-privacidad"
            target="_blank"
            rel="noopener noreferrer"
          >
            Políticas de privacidad
          </a>
          <span class="footer-nav-sep" aria-hidden="true">|</span>
          <a
            class="footer-nav-link"
            href="https://www.positiva.gov.co/politica-de-privacidad"
            target="_blank"
            rel="noopener noreferrer"
          >
            Tratamiento de datos personales
          </a>
          <span class="footer-nav-sep" aria-hidden="true">|</span>
          <a class="footer-nav-link" href="#" @click.prevent> Políticas de derecho de autor </a>
          <span class="footer-nav-sep" aria-hidden="true">|</span>
          <a
            class="footer-nav-link"
            href="https://www.positiva.gov.co/mapadelsitio"
            target="_blank"
            rel="noopener noreferrer"
            >Mapa del sitio</a
          >
        </nav>
        <a
          href="https://www.gov.co"
          target="_blank"
          rel="noopener noreferrer"
          class="footer-gov shrink-0"
          aria-label="GOV.CO — portal del Estado Colombiano"
        >
          <img
            :src="$publicUrl('images/footer/gov_co.svg')"
            width="120"
            height="32"
            alt="GOV.CO — portal del Estado Colombiano"
            class="block h-8 w-[120px]"
          />
        </a>
      </div>
    </div>

    <!-- Copyright -->
    <div class="footer-copy w-full border-t border-[rgba(255,255,255,0.1)] bg-[#0f2d42]">
      <p class="footer-copy-text mx-auto max-w-[1440px] px-10 py-4 text-center">
        © {{ year }} Positiva Compañía de Seguros. Todos los derechos reservados.
      </p>
    </div>

    <!-- Vigilado — solo móvil -->
    <div
      class="footer-vigilado-mobile flex items-center justify-center gap-3 border-t border-[rgba(255,255,255,0.15)] bg-[#173748] px-4 py-3 md:hidden"
      aria-label="Vigilado Superintendencia Financiera de Colombia"
    >
      <img
        :src="$publicUrl('images/footer/icon-vigilado.svg')"
        alt="Icono de vigilado"
        width="10"
        height="80"
        class="h-20 w-[10px] shrink-0 object-contain"
        aria-hidden="true"
      />
      <span class="footer-vigilado-mobile-label">
        Vigilado Superintendencia Financiera de Colombia
      </span>
    </div>
  </footer>
</template>

<script setup lang="ts">
const year = new Date().getFullYear();
</script>

<style scoped>
/*
 * Figma 24:10961 — tokens
 * Fondo principal #173748 | Copyright #0f2d42 | Acento #FF7500
 * Contenedor 1440px | padding 40px horizontal, 48px vertical (bloque principal)
 * Grid 3 cols gap 32px | Secciones apiladas gap 40px
 * Título sección: Poppins 16/24 semibold | Cuerpo: Roboto 14/22
 * Valores/links naranja: Poppins 14/22 bold | Icono cabecera: 32px círculo, borde 2px #FF7500
 */
.footer-positiva {
  --footer-bg: #173748;
  --footer-bg-copy: #0f2d42;
  --footer-accent: #ff7500;
  --footer-icon-size: 32px;
  --footer-social-size: 32px;
  --footer-pad-x: 40px;
  --footer-pad-y-main: 48px;
  --footer-pad-y-legal: 20px;
  --footer-pad-y-copy: 16px;
  --footer-gap-grid: 32px;
  --footer-gap-col-stack: 40px;
  --footer-gap-body: 16px;
  --footer-gap-head: 12px;
}

.footer-inner {
  padding-left: var(--footer-pad-x);
  padding-right: var(--footer-pad-x);
}

.footer-main .footer-inner {
  padding-top: var(--footer-pad-y-main);
  padding-bottom: var(--footer-pad-y-main);
}

.footer-legal .footer-inner {
  padding-top: var(--footer-pad-y-legal);
  padding-bottom: var(--footer-pad-y-legal);
}

.footer-grid {
  gap: var(--footer-gap-grid);
}

.footer-col {
  gap: var(--footer-gap-col-stack);
}

.footer-section-head {
  display: flex;
  align-items: center;
  gap: var(--footer-gap-head);
  padding-bottom: 12px;
  margin-bottom: 16px;
  border-bottom: 1.5px solid rgba(255, 255, 255);
}

.footer-section-head--no-border {
  border-bottom: none;
}

.footer-icon {
  display: inline-flex;
  height: var(--footer-icon-size);
  width: var(--footer-icon-size);
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  border-radius: 9999px;
}

.footer-section-title {
  margin: 0;
  font-family: var(--font-family-poppins);
  font-size: 16px;
  font-weight: 600;
  line-height: 24px;
  letter-spacing: 0;
  color: #fff;
}

.footer-body {
  display: flex;
  flex-direction: column;
  gap: var(--footer-gap-body);
}

.footer-row {
  margin: 0;
}

.footer-label {
  display: block;
  margin-bottom: 2px;
  font-family: var(--font-family-roboto);
  font-size: 14px;
  font-weight: 400;
  line-height: 22px;
  letter-spacing: 0;
  color: #fff;
}

.footer-text-block {
  margin: 0;
  font-family: var(--font-family-roboto);
  font-size: 14px;
  font-weight: 400;
  line-height: 22px;
  color: #fff;
}

.footer-subtitle {
  margin: 0;
  font-family: var(--font-family-poppins);
  font-size: 14px;
  font-weight: 600;
  line-height: 22px;
  color: var(--footer-accent);
}

.footer-accent {
  display: block;
  font-family: var(--font-family-poppins);
  font-size: 14px;
  font-weight: 700;
  line-height: 22px;
  color: var(--footer-accent);
  text-decoration: none;
}

.footer-accent:hover {
  text-decoration: underline;
  text-underline-offset: 2px;
}

.footer-accent-plain {
  cursor: default;
}

.footer-accent-plain:hover {
  text-decoration: none;
}

.footer-accent-stack {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.footer-link {
  text-decoration: underline;
  text-underline-offset: 3px;
}

.footer-social-title {
  margin: 0 0 16px;
  font-family: var(--font-family-poppins);
  font-size: 16px;
  font-weight: 600;
  line-height: 24px;
  color: #fff;
}

.footer-social-list {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.footer-nav-link {
  font-family: var(--font-family-poppins);
  font-size: 14px;
  font-weight: 600;
  line-height: 22px;
  color: #fff;
  text-decoration: underline;
  text-underline-offset: 3px;
}

.footer-nav-link:hover {
  opacity: 0.9;
}

.footer-nav-sep {
  color: rgba(255, 255, 255, 0.5);
  font-family: var(--font-family-poppins);
  font-size: 14px;
  line-height: 22px;
}

.footer-social {
  display: inline-flex;
  height: var(--footer-social-size);
  width: var(--footer-social-size);
  align-items: center;
  justify-content: center;
  border-radius: 9999px;
  border: 1px solid rgba(255, 255, 255, 0.85);
  transition: background-color 0.15s ease;
}

.footer-social:hover {
  background-color: rgba(255, 255, 255, 0.12);
}

.footer-social-icon {
  display: block;
  height: 16px;
  width: 16px;
  flex-shrink: 0;
}

.footer-copy-text {
  margin: 0;
  font-family: var(--font-family-roboto);
  font-size: 12px;
  font-weight: 400;
  line-height: 20px;
  color: rgba(255, 255, 255, 0.9);
}

.footer-vigilado-mobile-label {
  max-width: 280px;
  text-align: center;
  font-family: var(--font-family-roboto);
  font-size: 10px;
  font-weight: 400;
  line-height: 14px;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.9);
}
</style>
