<script setup lang="ts">
import DatePicker from "primevue/datepicker";
import { asDatePickerModel, coerceLocalDateIso, todayLocalDate } from "../utils/fecha-local";

withDefaults(
  defineProps<{
    etiqueta: string;
    modelValue: string;
    tipo?: "texto" | "lista" | "fecha";
    placeholder?: string;
    /** Lista simple (value = label) o catálogo codigo/nombre. */
    opciones?: Array<string | { codigo: string; nombre: string }>;
  }>(),
  {
    tipo: "texto",
    placeholder: "Ingresa",
    opciones: () => [],
  },
);

function opcionValue(opcion: string | { codigo: string; nombre: string }) {
  return typeof opcion === "string" ? opcion : opcion.codigo;
}

function opcionLabel(opcion: string | { codigo: string; nombre: string }) {
  return typeof opcion === "string" ? opcion : opcion.nombre;
}

const emit = defineEmits<{ "update:modelValue": [valor: string] }>();

const maxFechaNacimiento = todayLocalDate();

function actualizar(evento: Event) {
  const campo = evento.target;
  if (campo instanceof HTMLInputElement || campo instanceof HTMLSelectElement) {
    emit("update:modelValue", campo.value);
  }
}

function onFechaChange(value: unknown) {
  emit("update:modelValue", coerceLocalDateIso(value));
}
</script>

<template>
  <label class="flex min-w-0 flex-1 flex-col gap-1">
    <span
      class="pl-3 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#5d6977]"
    >
      {{ etiqueta }}
    </span>
    <span class="relative block">
      <select
        v-if="tipo === 'lista'"
        :value="modelValue"
        class="w-full appearance-none rounded-[7px] border bg-white py-2 pr-10 pl-[15px] text-base leading-6 outline-none"
        :class="
          modelValue
            ? 'rounded-[9px] border-[#ededed] text-[#173748]'
            : 'border-[#d9dce3] text-[#173748]/60'
        "
        @change="actualizar"
      >
        <option value="" disabled>{{ placeholder }}</option>
        <option v-for="opcion in opciones" :key="opcionValue(opcion)" :value="opcionValue(opcion)">
          {{ opcionLabel(opcion) }}
        </option>
      </select>
      <DatePicker
        v-else-if="tipo === 'fecha'"
        :model-value="asDatePickerModel(modelValue)"
        show-icon
        icon-display="input"
        date-format="dd/mm/yy"
        :placeholder="placeholder"
        fluid
        :max-date="maxFechaNacimiento"
        :show-button-bar="false"
        :input-class="'w-full'"
        class="pasajeros-datepicker w-full [&_.p-inputtext]:w-full"
        @update:model-value="onFechaChange"
      />
      <input
        v-else
        :value="modelValue"
        type="text"
        :placeholder="placeholder"
        class="w-full rounded-[7px] border border-[#d9dce3] bg-white px-[15px] py-2 text-base leading-6 text-[#173748] outline-none placeholder:text-[#173748]/60"
        @input="actualizar"
      />
      <img
        v-if="tipo === 'lista'"
        :src="$publicUrl('images/pasajeros/icon-expand.svg')"
        alt=""
        width="22"
        height="22"
        class="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2"
      />
    </span>
  </label>
</template>
