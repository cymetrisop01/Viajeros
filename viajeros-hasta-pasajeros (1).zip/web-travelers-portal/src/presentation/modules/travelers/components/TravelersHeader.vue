<template>
  <header class="border-b border-[#b3b7c3] bg-white">
    <div class="mx-auto flex max-w-[1440px] px-6 py-[18px] md:px-[100px]">
      <RouterLink to="/" class="inline-flex no-underline">
        <img
          :src="$publicUrl('images/header-lockup.svg')"
          width="270"
          height="62"
          alt="Un producto de Positiva Compañía de Seguros y Previsora"
          class="block h-auto max-w-full"
        />
      </RouterLink>
    </div>
  </header>
</template>
