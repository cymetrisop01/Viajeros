export interface BeneficioMock {
  texto: string;
  destacado: string;
}

export interface CoberturaFila {
  concepto: string;
  valores: string[];
  destacada?: boolean;
}

export interface TablaCobertura {
  titulo: string;
  barra: string;
  textoBarra: string;
  borde: string;
  monedas: string[];
  columna: string;
  lineaMoneda: string;
  filas: CoberturaFila[];
}

export interface PlanMock {
  id: "plus" | "pro";
  nombre: string;
  badge: string;
  badgeWidth: number;
  badgeHeight: number;
  precio: string;
  precioAbierto: string;
  descuento: string;
  precioFinal: string;
  montoTitulo: string;
  montoTituloClase: string;
  montoValor: string;
  montoValorClase: string;
  beneficios: BeneficioMock[];
  tabla: TablaCobertura;
  detalleBoton: string;
  iconoRegalo: string;
  seleccionar: string;
}

const FILAS_PLUS: CoberturaFila[] = [
  { concepto: "Monto máximo Global", valores: ["USD 60.000.000"], destacada: true },
  { concepto: "Asistencia médica en caso de accidente*", valores: ["USD 60.000.000"] },
  {
    concepto: "Asistencia medica en caso de enfermedad no preexistente (incluido COVID_19) *",
    valores: ["USD 10.000"],
  },
  { concepto: "Asistencia medica en caso de enfermedad preexistente *", valores: ["USD 500"] },
  {
    concepto: "Odontología de urgencia (Max. € 300 /USD 300 por pieza)",
    valores: ["USD 1000"],
  },
  { concepto: "Medicamentos ambulatorios", valores: ["Incluido"] },
  { concepto: "Medicamentos en caso de hospitalización", valores: ["USD 10.000"] },
  { concepto: "Práctica de deportes*", valores: ["USD 10.000"] },
  { concepto: "Estado de Embarazo", valores: ["USD 2.500"] },
  { concepto: "Prótesis y ortesis", valores: ["Incluido"] },
  { concepto: "Traslados sanitarios", valores: ["Incluido"] },
  { concepto: "Repatriaciones (Sanitaria o Funeraria)", valores: ["Incluido"] },
  { concepto: "Regreso de Acompañante del titular repatriado", valores: ["Incluido"] },
  { concepto: "Traslado de un Familiar", valores: ["Máximo USD 400"] },
  { concepto: "Estancia de un familiar (Limite Diario)", valores: ["Máximo USD 900"] },
  { concepto: "Estancia de un familiar (Limite total)", valores: ["Incluido"] },
  {
    concepto: "Gastos de Hotel por reposo luego de una hospitalización (Límite Diario)",
    valores: ["Incluido"],
  },
  {
    concepto: "Gastos de Hotel por reposo luego de una hospitalización (Límite Total)",
    valores: ["Incluido"],
  },
  { concepto: "Acompañamiento de menores o mayores", valores: ["USD 8.000"] },
  { concepto: "Regreso anticipado por siniestro grave en el domicilio", valores: ["USD 8.000"] },
  {
    concepto: "Asistencia legal por responsabilidad en un accidente (Préstamo)",
    valores: ["Incluido"],
  },
  { concepto: "Anticipo de fondos para finanzas (Préstamo)", valores: ["Incluido"] },
  { concepto: "Asistencia en caso de robo o extravío de documentos, etc.", valores: ["Incluido"] },
  { concepto: "Localización de equipajes", valores: ["No incluido"] },
  { concepto: "Telemedicina - Consultas médicas online", valores: ["No incluido"] },
];

const FILAS_PRO: CoberturaFila[] = [
  { concepto: "Monto máximo Global", valores: ["€ 35.000", "USD 35.000"], destacada: true },
  {
    concepto: "Asistencia médica en caso de accidente*",
    valores: ["€ 35.000", "USD 35.000"],
  },
  {
    concepto: "Asistencia medica en caso de enfermedad no preexistente (incluido COVID_19) *",
    valores: ["€ 35.000", "USD 35.000"],
  },
  {
    concepto: "Asistencia medica en caso de enfermedad preexistente *",
    valores: ["€ 5.000", "USD 5.000"],
  },
  {
    concepto: "Odontología de urgencia (Max. € 300 /USD 300 por pieza)",
    valores: ["€ 500", "USD 500"],
  },
  { concepto: "Medicamentos ambulatorios", valores: ["€ 800", "USD 800"] },
  { concepto: "Medicamentos en caso de hospitalización", valores: ["Incluido", "Incluido"] },
  { concepto: "Práctica de deportes*", valores: ["€ 10.000", "USD 10.000"] },
  { concepto: "Estado de Embarazo", valores: ["€ 10.000", "USD 10.000"] },
  { concepto: "Prótesis y ortesis", valores: ["€ 1300", "USD 1300"] },
  { concepto: "Traslados sanitarios", valores: ["Incluido", "Incluido"] },
  { concepto: "Repatriaciones (Sanitaria o Funeraria)", valores: ["Incluido", "Incluido"] },
  { concepto: "Regreso de Acompañante del titular repatriado", valores: ["Incluido", "Incluido"] },
  { concepto: "Traslado de un Familiar", valores: ["Incluido", "Incluido"] },
  { concepto: "Estancia de un familiar (Límite Diario)", valores: ["€ 100", "USD 100"] },
  { concepto: "Estancia de un familiar (Límite total)", valores: ["€ 400", "USD 400"] },
  {
    concepto: "Gastos de Hotel por reposo luego de una hospitalización (Límite Diario)",
    valores: ["€ 180", "USD 180"],
  },
  {
    concepto: "Gastos de Hotel por reposo luego de una hospitalización (Límite Total)",
    valores: ["€ 900", "USD 900"],
  },
  { concepto: "Acompañamiento de menores o mayores", valores: ["Incluido", "Incluido"] },
  {
    concepto: "Regreso anticipado por siniestro grave en el domicilio",
    valores: ["Incluido", "Incluido"],
  },
  {
    concepto: "Asistencia legal por responsabilidad en un accidente (Préstamo)",
    valores: ["€ 8000", "USD 8000"],
  },
  { concepto: "Anticipo de fondos para finanzas (Préstamo)", valores: ["€ 8000", "USD 8000"] },
  {
    concepto: "Asistencia en caso de robo o extravío de documentos, etc.",
    valores: ["Incluido", "Incluido"],
  },
  { concepto: "Localización de equipajes", valores: ["Incluido", "Incluido"] },
  { concepto: "Telemedicina - Consultas médicas online", valores: ["Incluido", "Incluido"] },
];

export const PLANES_MOCK: PlanMock[] = [
  {
    id: "plus",
    nombre: "Plus",
    badge: "images/planes/badge-plus.svg",
    badgeWidth: 26,
    badgeHeight: 35,
    precio: "750.436",
    precioAbierto: "text-[#ff7500]",
    descuento: "Descuento: 10%",
    precioFinal: "COP 675.392",
    montoTitulo: "MONTO MÁXIMO GLOBAL:",
    montoTituloClase: "font-semibold text-[#ff7500]",
    montoValor: "USD 60.000",
    montoValorClase: "text-base font-bold leading-6",
    beneficios: [
      {
        texto: "Asistencia por enfermedades preexistentes: ",
        destacado: "USD 10.000",
      },
      { texto: "Perdida de equipaje: ", destacado: "USD 1.200" },
      {
        texto: " Atiéndete con un medico a través de nuestra App móvil",
        destacado: "Telemedicina:",
      },
    ],
    tabla: {
      titulo: "Viajero Plus",
      barra: "bg-[#ff7500]",
      textoBarra: "text-sm leading-5",
      borde: "border border-[#ff7500]",
      monedas: ["DOLARES"],
      columna: "w-[125px]",
      lineaMoneda: "w-[125px]",
      filas: FILAS_PLUS,
    },
    detalleBoton: "bg-[#fae9dd] text-[#ff7500]",
    iconoRegalo: "images/planes/icon-gift-plus.svg",
    seleccionar: "border border-[#ff7500] bg-[#ff7500] text-white hover:bg-[#e06600]",
  },
  {
    id: "pro",
    nombre: "Pro",
    badge: "images/planes/badge-pro.svg",
    badgeWidth: 34,
    badgeHeight: 35,
    precio: "314.955",
    precioAbierto: "text-[#173748]",
    descuento: "Descuento: 10%",
    precioFinal: "COP 283.459",
    montoTitulo: "MONTO MAXIMO GLOBAL:",
    montoTituloClase: "font-semibold text-[#173748]",
    montoValor: "USD 35.000",
    montoValorClase: "font-semibold",
    beneficios: [
      {
        texto: "Asistencia por enfermedades preexistentes: ",
        destacado: "USD 5.000",
      },
      { texto: "Perdida de equipaje: ", destacado: "USD 1.200" },
      {
        texto: " Atiéndete con un medico a través de nuestra App móvil",
        destacado: "Telemedicina:",
      },
    ],
    tabla: {
      titulo: "PLAN PRO",
      barra: "bg-[#173748]",
      textoBarra: "text-xs leading-4",
      borde: "border border-[#173748]",
      monedas: ["EUROS", "DOLARES"],
      columna: "w-[70px]",
      lineaMoneda: "w-full",
      filas: FILAS_PRO,
    },
    detalleBoton: "bg-[#e0f2ff] text-[#173748]",
    iconoRegalo: "images/planes/icon-gift-pro.svg",
    seleccionar: "bg-[#173748] text-white hover:bg-[#0d2333]",
  },
];

export const PASOS_MOCK = [
  { titulo: "Selecciona tu plan", paso: "Paso 1", activo: true },
  { titulo: "Información de los pasajeros", paso: "Paso 2", activo: false },
  { titulo: "Resumen de tu Seguro Viajero", paso: "Paso 3", activo: false },
  { titulo: "Paga tu seguro Viajero", paso: "Paso 4", activo: false },
] as const;
