export { default as CotizadorPage } from "./CotizadorPage.vue";
export { default as PasajerosPage } from "./PasajerosPage.vue";
export { default as PlanesPage } from "./PlanesPage.vue";
