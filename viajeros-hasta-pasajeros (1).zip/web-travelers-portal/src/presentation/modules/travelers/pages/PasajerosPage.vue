<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import type {
  DivisionPoliticaItem,
  TipoDocumentoItem,
  ViajeroSesion,
} from "@/domain/travelers/models/catalogos.types";
import {
  generoCodigo,
  normalizarFechaIso,
  tipoDocumentoCodigo,
} from "@/application/travelers/mappers/documento.mapper";
import { CODIGO_COLOMBIA, formatoCop } from "@/application/travelers/mappers/plan-crm";
import {
  leerCotizacionSesion,
  parchearCotizacionSesion,
} from "@/application/travelers/session/cotizacion-session";
import {
  cargarTiposDocumento,
  TIPOS_DOCUMENTO_FALLBACK,
} from "@/application/travelers/use-cases/cargar-tipos-documento";
import { identidadPort, parametriaPort } from "@/infrastructure/travelers/composition";
import { ViajerosHttpError } from "@/infrastructure/http/viajeros-http";
import CampoFormulario from "@/presentation/modules/travelers/components/CampoFormulario.vue";
import { PLANES_MOCK } from "@/presentation/modules/travelers/data/planes-mock";

interface ViajeroFormulario {
  id: number;
  abierto: boolean;
  principal: boolean;
  menor: boolean;
  tutor: boolean;
  tipoDocumento: string;
  numeroDocumento: string;
  nacimiento: string;
  primerNombre: string;
  segundoNombre: string;
  primerApellido: string;
  segundoApellido: string;
  genero: string;
  correo: string;
  celular: string;
  direccion: string;
  departamento: string;
  ciudad: string;
  ciiu: string;
  peps: boolean;
}

const GENEROS = ["Femenino", "Masculino", "Otro"];
const ACTIVIDADES = ["Asalariado", "Comercio", "Servicios", "Educación"];
const PRECIO_PERSONA = 104_985;

const PASOS = [
  { titulo: "Selecciona tu plan", paso: "Paso 1", estado: "hecho" },
  { titulo: "Información de los pasajeros", paso: "Paso 2", estado: "activo" },
  { titulo: "Resumen de tu Seguro Viajero", paso: "Paso 3", estado: "pendiente" },
  { titulo: "Paga tu seguro Viajero", paso: "Paso 4", estado: "pendiente" },
] as const;

const route = useRoute();
const router = useRouter();

/** Temporal: cotización limitada a 1 viajero. */
const MAX_VIAJEROS = 1;

const planId = computed(() => (textoQuery("plan") === "pro" ? "pro" : "plus"));
const plan = computed(() => PLANES_MOCK.find((item) => item.id === planId.value) ?? PLANES_MOCK[0]);
const origen = computed(() => textoQuery("origen") || "Colombia");
const destino = computed(() => textoQuery("destino") || "Europa");
const fechaIda = computed(() => textoQuery("fecha") || "2026-07-12");

const sesion = leerCotizacionSesion();
const viajeros = ref<ViajeroFormulario[]>(crearGrupo(cantidadInicial()));
const recibeVoucher = ref("");
const correoVoucher = ref("");
const celularVoucher = ref("");
const autorizaDatos = ref(true);
const divisiones = ref<DivisionPoliticaItem[]>([]);
const tiposDocumento = ref<TipoDocumentoItem[]>([...TIPOS_DOCUMENTO_FALLBACK]);
const mensajeIdentidad = ref("");
const errorContinuar = ref("");
const validandoIdentidad = ref(false);

const COTIZACION = computed(
  () => sesion?.quoteHeaderId || sesion?.planNombre || "Pendiente de cotización",
);
const DEPARTAMENTOS = computed(() => {
  if (!divisiones.value.length) {
    return ["Cundinamarca", "Antioquia", "Valle del Cauca", "Atlántico"];
  }
  return divisiones.value.map((d) => d.nombre);
});
const CIUDADES = computed(() => DEPARTAMENTOS.value);

const rutaIda = computed(() => `${origen.value} - ${destino.value}`);
const rutaVuelta = computed(() => `${destino.value} - ${origen.value}`);
const vigencia = computed(() => {
  const vuelta = sesion?.fechaFin || sumarDias(fechaIda.value, 17);
  return `Vigencia ${formatearCorta(fechaIda.value)} al ${formatearCorta(vuelta)}`;
});
const opcionesVoucher = computed(() => [
  ...viajeros.value.map((viajero) => `Viajero ${viajero.id}`),
  "Otra persona",
]);

const carrito = computed(() => {
  const total = viajeros.value.length;
  const ninos = total > 2 ? 1 : 0;
  const adultos = total - ninos;
  const primaCrm = sesion?.prima;
  if (primaCrm && primaCrm > 0) {
    return {
      lineas: [
        {
          titulo: sesion?.esNacional ? "Nacional" : "Internacional",
          detalle: total === 1 ? "1 viajero" : `${total} viajeros`,
          valor: formatoCop(primaCrm),
        },
      ],
      subtotal: formatoCop(primaCrm),
      descuento: "0",
      total: formatoCop(primaCrm),
    };
  }
  const subtotal = PRECIO_PERSONA * total;
  const descuento = Math.round(subtotal * 0.1);
  const totalPagar =
    plan.value.id === "plus" && adultos === 2 && ninos === 1 ? 675_392 : subtotal - descuento;
  const lineas = [];
  if (adultos > 0) {
    lineas.push({
      titulo: "Internacional",
      detalle: adultos === 1 ? "1 adulto" : `${adultos} adultos`,
      valor: formato(PRECIO_PERSONA * adultos),
    });
  }
  if (ninos > 0) {
    lineas.push({
      titulo: "Internacional",
      detalle: "1 niño",
      valor: formato(PRECIO_PERSONA),
    });
  }
  const descuentoVisible =
    plan.value.id === "plus" && adultos === 2 && ninos === 1 ? "31.495" : formato(descuento);
  const subtotalVisible =
    plan.value.id === "plus" && adultos === 2 && ninos === 1 ? "314.955" : formato(subtotal);
  return {
    lineas,
    subtotal: subtotalVisible,
    descuento: descuentoVisible,
    total: formato(totalPagar),
  };
});

onMounted(() => {
  void cargarDivisionPolitica();
  void cargarCatalogoTiposDocumento();
});

async function cargarDivisionPolitica() {
  const idPais = sesion?.origenCodigo || CODIGO_COLOMBIA;
  try {
    divisiones.value = await parametriaPort.consultarDivisionPolitica(idPais);
  } catch {
    divisiones.value = [];
  }
}

async function cargarCatalogoTiposDocumento() {
  tiposDocumento.value = await cargarTiposDocumento(parametriaPort);
}

async function validarIdentidadPrincipal() {
  const principal = viajeros.value.find((v) => v.principal) ?? viajeros.value[0];
  if (!principal?.tipoDocumento || !principal.numeroDocumento || !principal.nacimiento) {
    return true;
  }
  validandoIdentidad.value = true;
  mensajeIdentidad.value = "";
  try {
    const res = await identidadPort.consultar({
      tipoDocumento: tipoDocumentoCodigo(principal.tipoDocumento),
      numeroDocumento: principal.numeroDocumento.trim(),
      fechaNacimiento: normalizarFechaIso(principal.nacimiento),
    });
    if (res.valido) {
      if (res.primerNombre && !principal.primerNombre) {
        principal.primerNombre = res.primerNombre;
      }
      if (res.primerApellido && !principal.primerApellido) {
        principal.primerApellido = res.primerApellido;
      }
      mensajeIdentidad.value = "Identidad validada con BUS.";
      return true;
    }
    mensajeIdentidad.value = res.mensaje || "La identidad no fue validada.";
    return false;
  } catch (e) {
    mensajeIdentidad.value =
      e instanceof ViajerosHttpError
        ? e.message
        : "No se pudo validar identidad; puedes continuar y reintentar.";
    return true;
  } finally {
    validandoIdentidad.value = false;
  }
}

function aViajeroSesion(v: ViajeroFormulario): ViajeroSesion {
  return {
    id: v.id,
    principal: v.principal,
    menor: v.menor,
    tipoDocumento: v.tipoDocumento,
    tipoDocumentoCodigo: tipoDocumentoCodigo(v.tipoDocumento),
    numeroDocumento: v.numeroDocumento,
    nacimiento: normalizarFechaIso(v.nacimiento),
    primerNombre: v.primerNombre,
    segundoNombre: v.segundoNombre,
    primerApellido: v.primerApellido,
    segundoApellido: v.segundoApellido,
    genero: v.genero,
    generoCodigo: generoCodigo(v.genero),
    correo: v.correo,
    celular: v.celular,
    direccion: v.direccion,
    departamento: v.departamento,
    ciudad: v.ciudad,
    ciiu: v.ciiu,
    peps: v.peps,
  };
}

function textoQuery(clave: string) {
  const valor = route.query[clave];
  return typeof valor === "string" ? valor : "";
}

function cantidadInicial() {
  const valor = Number(textoQuery("viajeros") || String(MAX_VIAJEROS));
  if (!Number.isFinite(valor) || valor < 1) return MAX_VIAJEROS;
  return Math.min(valor, MAX_VIAJEROS);
}

function crearViajero(indice: number, total: number): ViajeroFormulario {
  const menor = total > 2 && indice === total - 1;
  return {
    id: indice + 1,
    abierto: true,
    principal: indice === 0,
    menor,
    tutor: false,
    tipoDocumento: "",
    numeroDocumento: "",
    nacimiento: "",
    primerNombre: "",
    segundoNombre: "",
    primerApellido: "",
    segundoApellido: "",
    genero: "",
    correo: "",
    celular: "",
    direccion: "",
    departamento: "",
    ciudad: "",
    ciiu: indice === 0 ? "Asalariado" : "",
    peps: false,
  };
}

function crearGrupo(total: number) {
  return Array.from({ length: total }, (_, indice) => crearViajero(indice, total));
}

function reclasificar() {
  const total = viajeros.value.length;
  viajeros.value.forEach((viajero, indice) => {
    viajero.id = indice + 1;
    viajero.principal = indice === 0;
    viajero.menor = total > 2 && indice === total - 1;
    if (viajero.principal && !viajero.ciiu) viajero.ciiu = "Asalariado";
  });
}

function agregarViajero() {
  if (viajeros.value.length >= MAX_VIAJEROS) return;
  viajeros.value.push(crearViajero(viajeros.value.length, viajeros.value.length + 1));
  reclasificar();
}

function sumarDias(iso: string, dias: number) {
  const fecha = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(fecha.getTime())) return iso;
  fecha.setDate(fecha.getDate() + dias);
  const mes = String(fecha.getMonth() + 1).padStart(2, "0");
  const dia = String(fecha.getDate()).padStart(2, "0");
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

function formatearCorta(iso: string) {
  const fecha = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(fecha.getTime())) return iso;
  const dia = String(fecha.getDate()).padStart(2, "0");
  const mes = String(fecha.getMonth() + 1).padStart(2, "0");
  return `${dia}/${mes}/${fecha.getFullYear()}`;
}

function formato(valor: number) {
  return new Intl.NumberFormat("es-CO").format(valor);
}

function volver() {
  const consulta = { ...route.query };
  delete consulta.plan;
  void router.push({ name: "Planes", query: consulta });
}

async function continuar() {
  if (!autorizaDatos.value) return;
  errorContinuar.value = "";
  const principal = viajeros.value[0];
  if (
    !principal?.tipoDocumento ||
    !principal.numeroDocumento ||
    !principal.nacimiento ||
    !principal.primerNombre ||
    !principal.primerApellido ||
    !principal.correo ||
    !principal.celular ||
    !principal.direccion
  ) {
    errorContinuar.value = "Completa los datos obligatorios del viajero principal.";
    return;
  }
  await validarIdentidadPrincipal();
  parchearCotizacionSesion({
    viajeros: viajeros.value.map(aViajeroSesion),
    cantidadViajeros: viajeros.value.length,
  });
}
</script>

<template>
  <section class="relative overflow-hidden bg-[#f7f7f7] px-6 pt-[50px] pb-[90px] md:px-[120px]">
    <img
      :src="$publicUrl('images/cotizador/bg-map.svg')"
      alt=""
      width="650"
      height="650"
      class="pointer-events-none absolute -top-[62px] -left-[83px] select-none"
    />

    <div class="relative mx-auto w-full max-w-[1200px]">
      <div
        class="flex flex-col gap-10 rounded-3xl bg-white p-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)] md:p-10"
      >
        <div class="flex flex-col gap-6">
          <div class="px-2 md:px-10">
            <div class="flex items-center gap-4">
              <p
                class="font-[family-name:var(--font-family-poppins)] text-[32px] leading-10 font-bold text-[#ff7500]"
              >
                IDA
              </p>
              <div class="flex min-w-0 flex-1 items-center gap-2">
                <span class="h-0 flex-1 border-t-2 border-dashed border-[#ff7500]" />
                <img
                  :src="$publicUrl('images/planes/icon-plane.svg')"
                  alt=""
                  width="28"
                  height="24"
                />
                <span class="h-0 flex-1 border-t-2 border-dashed border-[#173748]" />
              </div>
              <p
                class="font-[family-name:var(--font-family-poppins)] text-[32px] leading-10 font-bold text-[#173748]"
              >
                VUELTA
              </p>
            </div>
            <div
              class="mt-1 flex items-center justify-between font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#747474]"
            >
              <span>{{ rutaIda }}</span>
              <span>{{ rutaVuelta }}</span>
            </div>
          </div>

          <ol
            class="grid grid-cols-1 overflow-hidden rounded-lg shadow-[3px_3px_10px_rgba(23,55,72,0.3)] md:grid-cols-4"
          >
            <li
              v-for="paso in PASOS"
              :key="paso.paso"
              class="bg-white px-4 py-2.5"
              :class="paso.estado === 'pendiente' ? '' : 'border-b-4 border-[#ff7500]'"
            >
              <p
                class="font-[family-name:var(--font-family-poppins)] font-semibold"
                :class="
                  paso.estado === 'activo'
                    ? 'text-base leading-[22px] text-[#ff7500]'
                    : paso.estado === 'hecho'
                      ? 'text-sm leading-5 text-[#173748]'
                      : 'text-sm leading-5 text-[#b3b7c3]'
                "
              >
                {{ paso.titulo }}
              </p>
              <p
                class="text-xs leading-5"
                :class="
                  paso.estado === 'pendiente'
                    ? 'text-[#b3b7c3]'
                    : paso.estado === 'activo'
                      ? 'text-[#173748]'
                      : 'text-[#5d6977]'
                "
              >
                {{ paso.paso }}
              </p>
            </li>
          </ol>
        </div>

        <div class="flex flex-col items-start gap-10 xl:flex-row">
          <aside
            class="w-full shrink-0 rounded-lg border border-[#d9dce3] bg-white px-4 py-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)] xl:w-[320px]"
          >
            <div class="flex items-start gap-[5px]">
              <img
                :src="$publicUrl('images/pasajeros/icon-cart.svg')"
                alt=""
                width="20"
                height="32"
              />
              <div>
                <h2
                  class="font-[family-name:var(--font-family-poppins)] text-2xl leading-8 font-bold text-[#173748]"
                >
                  Tu <span class="text-[#ff7500]">Carrito</span>
                </h2>
                <p
                  class="mt-1 inline-flex items-center gap-2 rounded bg-[#fae9dd] px-2 py-0.5 text-[#173748]"
                >
                  <span class="text-xs leading-4">Número de cotización:</span>
                  <span
                    class="font-[family-name:var(--font-family-poppins)] text-base leading-[22px] font-semibold"
                  >
                    {{ COTIZACION }}
                  </span>
                </p>
                <p class="mt-1 text-[10px] leading-3 text-[#747474]">{{ vigencia }}</p>
              </div>
            </div>

            <div class="mt-5 flex flex-col gap-4 pl-6 text-[#173748]">
              <div
                v-for="linea in carrito.lineas"
                :key="linea.detalle"
                class="flex items-center gap-[5px]"
              >
                <div class="min-w-0 flex-1">
                  <p class="text-sm leading-[22px]">{{ linea.titulo }}</p>
                  <p class="text-[10px] leading-3">{{ linea.detalle }}</p>
                </div>
                <p
                  class="w-[95px] text-right font-[family-name:var(--font-family-poppins)] font-semibold"
                >
                  <span class="text-xs leading-[18px]">COP</span>
                  <span class="ml-1 text-sm leading-5">{{ linea.valor }}</span>
                </p>
              </div>
              <div class="h-px w-full bg-[#ededed]" />
              <div class="flex items-start gap-[5px] text-sm leading-[22px]">
                <p class="flex-1">Subtotal</p>
                <p
                  class="w-[95px] text-right font-[family-name:var(--font-family-poppins)] font-semibold"
                >
                  <span class="text-xs leading-[18px]">COP</span>
                  <span class="ml-1">{{ carrito.subtotal }}</span>
                </p>
              </div>
              <div class="flex items-start gap-[5px] text-sm leading-[22px]">
                <p class="flex-1">Descuento 10%</p>
                <p
                  class="w-[95px] text-right font-[family-name:var(--font-family-poppins)] font-semibold"
                >
                  <span class="text-xs leading-[18px]">COP</span>
                  <span class="ml-1">{{ carrito.descuento }}</span>
                </p>
              </div>
              <div
                class="flex items-start gap-[5px] rounded bg-[#ededed] font-[family-name:var(--font-family-poppins)] font-semibold"
              >
                <p class="flex-1 text-base leading-[22px]">TOTAL</p>
                <p class="w-[95px] text-right">
                  <span class="text-xs leading-[18px]">COP</span>
                  <span class="ml-1 text-base leading-[22px]">{{ carrito.total }}</span>
                </p>
              </div>
            </div>
          </aside>

          <div
            class="flex w-full min-w-0 flex-1 flex-col gap-10 rounded-lg border border-[#d9dce3] bg-white p-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)]"
          >
            <template v-for="(viajero, indice) in viajeros" :key="viajero.id">
              <div v-if="indice > 0" class="h-px w-full bg-[#ededed]" />
              <article class="flex flex-col gap-6">
                <button
                  type="button"
                  class="flex w-full items-center justify-between text-left"
                  @click="viajero.abierto = !viajero.abierto"
                >
                  <span class="flex items-start gap-[5px]">
                    <img
                      :src="$publicUrl('images/pasajeros/icon-traveler.svg')"
                      alt=""
                      width="24"
                      height="24"
                      class="mt-1"
                    />
                    <span>
                      <span
                        class="block font-[family-name:var(--font-family-poppins)] text-2xl leading-8 font-bold text-[#173748]"
                      >
                        Viajero {{ viajero.id }}
                        <span v-if="viajero.principal" class="text-[#ff7500]">principal</span>
                      </span>
                      <span class="block text-sm leading-[22px] text-[#5d6977]">
                        {{ viajero.menor ? "Menor de edad" : "Mayor de edad" }}
                      </span>
                    </span>
                  </span>
                  <img
                    :src="$publicUrl('images/pasajeros/icon-collapse.svg')"
                    alt=""
                    width="24"
                    height="24"
                    class="transition"
                    :class="viajero.abierto ? 'rotate-180' : ''"
                  />
                </button>

                <div v-if="viajero.abierto" class="flex flex-col gap-5 px-2 md:px-6">
                  <label
                    v-if="viajero.menor"
                    class="inline-flex w-fit items-center gap-3 text-sm leading-[22px] text-[#173748]"
                  >
                    <input
                      v-model="viajero.tutor"
                      type="checkbox"
                      class="size-4 rounded border-[1.5px] border-[#f7f7f7] accent-[#ff7500]"
                    />
                    Soy (tomador) su tutor legal.
                  </label>

                  <div class="grid grid-cols-1 gap-5 md:grid-cols-3">
                    <CampoFormulario
                      v-model="viajero.tipoDocumento"
                      etiqueta="Tipo de documento*"
                      tipo="lista"
                      placeholder="Selecciona"
                      :opciones="tiposDocumento"
                    />
                    <CampoFormulario
                      v-model="viajero.numeroDocumento"
                      etiqueta="Número de documento*"
                    />
                    <CampoFormulario
                      v-model="viajero.nacimiento"
                      etiqueta="Fecha de nacimiento*"
                      tipo="fecha"
                      placeholder="dd/mm/aaaa"
                    />
                  </div>
                  <p
                    v-if="viajero.principal && (mensajeIdentidad || validandoIdentidad)"
                    class="text-sm"
                    :class="
                      mensajeIdentidad.includes('validada') ? 'text-[#0f766e]' : 'text-[#b45309]'
                    "
                  >
                    {{ validandoIdentidad ? "Validando identidad…" : mensajeIdentidad }}
                  </p>

                  <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <CampoFormulario
                      v-if="!viajero.menor"
                      v-model="viajero.primerNombre"
                      etiqueta="Primer Nombre*"
                    />
                    <CampoFormulario v-model="viajero.segundoNombre" etiqueta="Segundo Nombre" />
                    <CampoFormulario
                      v-if="viajero.menor"
                      v-model="viajero.primerNombre"
                      etiqueta="Primer Nombre*"
                    />
                  </div>
                  <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <CampoFormulario
                      v-if="!viajero.menor"
                      v-model="viajero.primerApellido"
                      etiqueta="Primer Apellido*"
                    />
                    <CampoFormulario
                      v-model="viajero.segundoApellido"
                      etiqueta="Segundo Apellido"
                    />
                    <CampoFormulario
                      v-if="viajero.menor"
                      v-model="viajero.primerApellido"
                      etiqueta="Primer Apellido*"
                    />
                  </div>
                  <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <CampoFormulario
                      v-model="viajero.genero"
                      etiqueta="Género*"
                      tipo="lista"
                      placeholder="Selecciona"
                      :opciones="GENEROS"
                    />
                    <CampoFormulario v-model="viajero.correo" etiqueta="Correo electrónico*" />
                  </div>
                  <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <CampoFormulario v-model="viajero.celular" etiqueta="Celular*" />
                    <CampoFormulario v-model="viajero.direccion" etiqueta="Dirección*" />
                  </div>
                  <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <CampoFormulario
                      v-model="viajero.departamento"
                      etiqueta="Departamento*"
                      tipo="lista"
                      placeholder="Selecciona"
                      :opciones="DEPARTAMENTOS"
                    />
                    <CampoFormulario
                      v-model="viajero.ciudad"
                      etiqueta="Ciudad*"
                      tipo="lista"
                      placeholder="Selecciona"
                      :opciones="CIUDADES"
                    />
                  </div>
                  <CampoFormulario
                    v-if="viajero.principal"
                    v-model="viajero.ciiu"
                    etiqueta="Actividad CIIU*"
                    tipo="lista"
                    placeholder="Selecciona"
                    :opciones="ACTIVIDADES"
                  />

                  <div class="flex items-start gap-[5px]">
                    <label
                      class="flex min-w-0 flex-1 items-center gap-3 text-sm leading-[22px] text-[#173748]"
                    >
                      <input
                        v-model="viajero.peps"
                        type="checkbox"
                        class="size-4 shrink-0 rounded border-[1.5px] border-[#ededed]"
                      />
                      Eres una persona políticamente Expuesta (PEPS)?
                    </label>
                    <img
                      :src="$publicUrl('images/pasajeros/icon-info.svg')"
                      alt="Información sobre personas expuestas políticamente"
                      width="16"
                      height="16"
                    />
                  </div>
                </div>
              </article>
            </template>

            <button
              v-if="viajeros.length < MAX_VIAJEROS"
              type="button"
              class="mx-auto inline-flex items-center gap-2 rounded-lg border border-[#ff7500] bg-[#ff7500] px-[30px] py-3 font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-white transition hover:bg-[#e06600]"
              @click="agregarViajero"
            >
              Agregar viajero
              <img
                :src="$publicUrl('images/pasajeros/icon-add.svg')"
                alt=""
                width="18"
                height="18"
              />
            </button>
          </div>
        </div>

        <div
          class="rounded-[10px] border border-[#d9dce3] bg-white p-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)]"
        >
          <div class="flex items-center gap-[5px]">
            <img
              :src="$publicUrl('images/pasajeros/icon-ticket.svg')"
              alt=""
              width="23"
              height="23"
            />
            <h2
              class="font-[family-name:var(--font-family-poppins)] text-xl leading-[37px] font-bold tracking-[-0.6px] text-[#173748]"
            >
              Información del <span class="text-[#ff7500]">voucher</span>
            </h2>
          </div>
          <div class="mt-5 grid grid-cols-1 gap-5 md:grid-cols-3">
            <CampoFormulario
              v-model="recibeVoucher"
              etiqueta="¿Quién recibe el voucher?*"
              tipo="lista"
              placeholder="Selecciona"
              :opciones="opcionesVoucher"
            />
            <CampoFormulario v-model="correoVoucher" etiqueta="Correo electrónico*" />
            <CampoFormulario v-model="celularVoucher" etiqueta="Celular*" />
          </div>
        </div>

        <label class="flex items-center gap-3 text-base leading-6 text-black">
          <span
            class="inline-flex size-4 shrink-0 items-center justify-center rounded"
            :class="autorizaDatos ? 'bg-[#ff7500]' : 'border-[1.5px] border-[#ededed] bg-white'"
          >
            <input v-model="autorizaDatos" type="checkbox" class="sr-only" />
            <img
              v-if="autorizaDatos"
              :src="$publicUrl('images/pasajeros/icon-check-on.svg')"
              alt=""
              width="16"
              height="16"
            />
          </span>
          <span>
            He leído y autorizo el tratamiento de datos personales según la
            <a
              href="https://www.positiva.gov.co/politica-de-privacidad"
              class="font-bold text-[#ff7500] underline"
              target="_blank"
              rel="noopener noreferrer"
              @click.stop
            >
              Política de privacidad de Positiva
            </a>
          </span>
        </label>

        <p v-if="errorContinuar" class="text-right text-sm text-[#b45309]">{{ errorContinuar }}</p>
        <div class="flex flex-wrap justify-end gap-10">
          <button
            type="button"
            class="inline-flex w-[170px] items-center justify-center gap-2 rounded-lg border border-[#173748] px-4 py-3 font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-[#173748]"
            @click="volver"
          >
            <img
              :src="$publicUrl('images/pasajeros/icon-volver.svg')"
              alt=""
              width="24"
              height="24"
            />
            Volver
          </button>
          <button
            type="button"
            class="inline-flex w-[170px] items-center justify-center gap-2 rounded-lg border border-[#ff7500] bg-[#ff7500] px-[30px] py-3 font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-white"
            @click="void continuar()"
          >
            Continuar
            <img
              :src="$publicUrl('images/pasajeros/icon-continuar.svg')"
              alt=""
              width="18"
              height="18"
            />
          </button>
        </div>
      </div>
    </div>
  </section>
</template>
