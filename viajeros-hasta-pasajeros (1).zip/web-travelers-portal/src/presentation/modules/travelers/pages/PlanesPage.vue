<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import type { PlanTarifa } from "@/domain/travelers/models/catalogos.types";
import {
  DIAS_VIGENCIA_DEFAULT,
  esViajeNacional,
  formatoCop,
  precioFinalLabel,
  sumarDiasIso,
} from "@/application/travelers/mappers/plan-crm";
import {
  leerCotizacionSesion,
  parchearCotizacionSesion,
} from "@/application/travelers/session/cotizacion-session";
import { cotizarPlanes } from "@/application/travelers/use-cases/cotizar-planes";
import { tarifacionPort } from "@/infrastructure/travelers/composition";
import { ViajerosHttpError } from "@/infrastructure/http/viajeros-http";
import {
  PASOS_MOCK,
  PLANES_MOCK,
  type PlanMock,
} from "@/presentation/modules/travelers/data/planes-mock";

const route = useRoute();
const router = useRouter();

const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];

const origen = computed(() => textoQuery("origen", "Colombia"));
const destino = computed(() => textoQuery("destino", "Europa"));
const viajeros = computed(() => {
  const valor = Number(textoQuery("viajeros", "1"));
  return Number.isFinite(valor) && valor > 0 ? valor : 1;
});
const fechaIda = computed(() => textoQuery("fecha", "2026-07-12"));
const fechaVuelta = computed(() => sumarDiasIso(fechaIda.value, DIAS_VIGENCIA_DEFAULT));

const rutaIda = computed(() => `${origen.value} - ${destino.value}`);
const rutaVuelta = computed(() => `${destino.value} - ${origen.value}`);
const rangoFechas = computed(
  () => `${formatearFecha(fechaIda.value)} - ${formatearFecha(fechaVuelta.value)}`,
);
const pasajeros = computed(() => {
  const total = viajeros.value;
  if (total <= 1) return "1 adulto";
  if (total === 2) return "2 adultos";
  return `${total - 1} adultos, 1 niño`;
});

const detallesAbiertos = ref<Record<PlanMock["id"], boolean>>({
  plus: false,
  pro: false,
});
const planSeleccionado = ref<PlanMock["id"] | null>(null);
const tarifas = ref<Partial<Record<PlanMock["id"], PlanTarifa>>>({});
const cargandoTarifas = ref(true);
const errorTarifa = ref("");
const seleccionando = ref(false);
const modalidadNacional = ref(false);

const modalidadLabel = computed(() =>
  modalidadNacional.value ? "Seguro nacional" : "Seguro internacional",
);

const planesVista = computed(() =>
  PLANES_MOCK.map((plan) => {
    const tarifa = tarifas.value[plan.id];
    if (!tarifa?.prima) {
      return {
        ...plan,
        precio: cargandoTarifas.value ? "…" : plan.precio,
        precioFinal: cargandoTarifas.value ? "Consultando…" : plan.precioFinal,
        descuento: cargandoTarifas.value ? "CRM…" : plan.descuento,
        tienePrimaCrm: false,
      };
    }
    const primaLabel = formatoCop(tarifa.prima);
    return {
      ...plan,
      precio: primaLabel,
      precioFinal: precioFinalLabel(tarifa.prima),
      descuento:
        tarifa.fuente === "crm"
          ? `Prima CRM · ${modalidadLabel.value}`
          : tarifa.fuente === "stub"
            ? "Prima stub"
            : plan.descuento,
      tienePrimaCrm: true,
    };
  }),
);

onMounted(() => {
  void cargarTarifas();
});

async function cargarTarifas() {
  cargandoTarifas.value = true;
  errorTarifa.value = "";
  tarifas.value = {};
  const sesion = leerCotizacionSesion();
  const esNacional =
    sesion?.esNacional ??
    esViajeNacional(
      sesion?.origenCodigo ?? "170",
      sesion?.origenNombre ?? origen.value,
      sesion?.destinoCodigo ?? destino.value,
      sesion?.destinoNombre ?? destino.value,
    );
  modalidadNacional.value = esNacional;

  const viaje = {
    origenCodigo: sesion?.origenCodigo ?? "170",
    origenNombre: sesion?.origenNombre ?? origen.value,
    destinoCodigo: sesion?.destinoCodigo ?? destino.value.toLowerCase(),
    destinoNombre: sesion?.destinoNombre ?? destino.value,
    esNacional,
    fechaInicio: sesion?.fechaInicio ?? fechaIda.value,
    fechaFin: sesion?.fechaFin ?? fechaVuelta.value,
    cantidadViajeros: sesion?.cantidadViajeros ?? viajeros.value,
  };

  parchearCotizacionSesion({ esNacional });

  try {
    const lista = await cotizarPlanes(tarifacionPort, viaje);
    const map: Partial<Record<PlanMock["id"], PlanTarifa>> = {};
    for (const item of lista) map[item.planUi] = item;
    tarifas.value = map;
    if (!lista.length) {
      errorTarifa.value = "No se obtuvieron primas del BFF. Se muestran precios de referencia.";
    } else if (lista.length < 2) {
      errorTarifa.value =
        "Solo se obtuvo una prima CRM. El otro plan muestra precio de referencia.";
    }
  } catch (e) {
    errorTarifa.value =
      e instanceof ViajerosHttpError
        ? e.message
        : "No se pudo tarifar con el BFF. Se muestran precios de referencia.";
  } finally {
    cargandoTarifas.value = false;
  }
}

function textoQuery(clave: string, respaldo: string) {
  const valor = route.query[clave];
  return typeof valor === "string" && valor.trim() ? valor : respaldo;
}

function formatearFecha(iso: string) {
  const fecha = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(fecha.getTime())) return iso;
  return `${fecha.getDate()} ${MESES[fecha.getMonth()]}. ${fecha.getFullYear()}`;
}

function regresar() {
  void router.push({ name: "Cotizador" });
}

function alternarDetalle(id: PlanMock["id"]) {
  detallesAbiertos.value[id] = !detallesAbiertos.value[id];
}

function seleccionar(id: PlanMock["id"]) {
  if (seleccionando.value || cargandoTarifas.value) return;
  const tarifa = tarifas.value[id];
  if (!tarifa?.quoterHeaderId) {
    errorTarifa.value = "Espera la cotización CRM o recotiza antes de seleccionar el plan.";
    return;
  }
  seleccionando.value = true;
  planSeleccionado.value = id;
  parchearCotizacionSesion({
    planUi: id,
    planCrmId: tarifa.planCrmId,
    quoteHeaderId: tarifa.quoterHeaderId,
    prima: tarifa.prima,
    planNombre: tarifa.nombreCrm,
    esNacional: modalidadNacional.value,
  });
  void router
    .push({
      name: "Pasajeros",
      query: { ...route.query, plan: id },
    })
    .finally(() => {
      seleccionando.value = false;
    });
}
</script>

<template>
  <section class="relative overflow-hidden bg-[#f7f7f7] px-6 pt-[50px] pb-[90px] md:px-[120px]">
    <img
      :src="$publicUrl('images/cotizador/bg-map.svg')"
      alt=""
      width="650"
      height="650"
      class="pointer-events-none absolute -top-[62px] -left-[83px] select-none"
    />

    <div class="relative mx-auto flex w-full max-w-[1200px] flex-col gap-[29px]">
      <button
        type="button"
        class="inline-flex w-fit items-center gap-2 rounded-lg border border-[#173748] bg-transparent px-4 py-2 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#173748] transition hover:bg-white"
        @click="regresar"
      >
        <img :src="$publicUrl('images/cotizador/icon-back.svg')" alt="" width="18" height="18" />
        Regresar
      </button>

      <div class="flex flex-col items-start gap-5 lg:flex-row lg:items-start">
        <h1
          class="w-full max-w-[262px] shrink-0 font-[family-name:var(--font-family-poppins)] text-[35px] leading-[45px] font-bold tracking-[-1.05px] text-[#0d2333]"
        >
          Cotizador del Seguro
          <span class="text-[#ff7500]">Viajero</span>
        </h1>

        <div
          class="flex w-full min-w-0 flex-1 flex-col items-start justify-between gap-6 rounded-2xl border-b-4 border-l-4 border-[#ff7500] bg-white px-8 py-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)] lg:flex-row lg:items-end"
        >
          <div class="min-w-0 flex-1">
            <h2
              class="font-[family-name:var(--font-family-poppins)] text-lg leading-6 font-semibold text-[#173748]"
            >
              Detalles de tu viaje
            </h2>
            <div class="my-2 h-px w-full max-w-[280px] bg-[#ff7500]" />
            <div
              class="flex flex-wrap items-center gap-x-5 gap-y-2 text-base leading-6 text-[#173748]"
            >
              <span class="inline-flex items-center gap-1">
                <img
                  :src="$publicUrl('images/planes/icon-pin.svg')"
                  alt=""
                  width="20"
                  height="20"
                />
                {{ rutaIda }}
              </span>
              <span class="inline-flex items-center gap-1">
                <img
                  :src="$publicUrl('images/planes/icon-calendar.svg')"
                  alt=""
                  width="20"
                  height="20"
                />
                {{ rangoFechas }}
              </span>
              <span class="inline-flex items-center gap-1">
                <img
                  :src="$publicUrl('images/planes/icon-people.svg')"
                  alt=""
                  width="20"
                  height="20"
                />
                {{ pasajeros }}
              </span>
            </div>
          </div>
          <button
            type="button"
            class="inline-flex shrink-0 items-center gap-2 rounded-lg bg-[#173748] px-[30px] py-2.5 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-white transition hover:bg-[#0d2333]"
            @click="regresar"
          >
            <img
              :src="$publicUrl('images/planes/icon-refresh.svg')"
              alt=""
              width="20"
              height="20"
            />
            Recotizar
          </button>
        </div>
      </div>

      <div
        class="flex flex-col gap-10 rounded-3xl bg-white p-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)] md:p-10"
      >
        <div class="flex flex-col gap-6">
          <div class="px-2 md:px-10">
            <div class="flex items-center gap-4">
              <p
                class="font-[family-name:var(--font-family-poppins)] text-[32px] leading-10 font-bold text-[#ff7500]"
              >
                IDA
              </p>
              <div class="flex min-w-0 flex-1 items-center gap-2">
                <span class="h-0 flex-1 border-t-2 border-dashed border-[#ff7500]" />
                <img
                  :src="$publicUrl('images/planes/icon-plane.svg')"
                  alt=""
                  width="28"
                  height="24"
                />
                <span class="h-0 flex-1 border-t-2 border-dashed border-[#173748]" />
              </div>
              <p
                class="font-[family-name:var(--font-family-poppins)] text-[32px] leading-10 font-bold text-[#173748]"
              >
                VUELTA
              </p>
            </div>
            <div
              class="mt-1 flex items-center justify-between font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#747474]"
            >
              <span>{{ rutaIda }}</span>
              <span>{{ rutaVuelta }}</span>
            </div>
          </div>

          <ol
            class="grid grid-cols-1 overflow-hidden rounded-lg shadow-[3px_3px_10px_rgba(23,55,72,0.3)] md:grid-cols-4"
          >
            <li
              v-for="paso in PASOS_MOCK"
              :key="paso.paso"
              class="bg-white px-4 py-2.5"
              :class="paso.activo ? 'border-b-4 border-[#ff7500]' : ''"
            >
              <p
                class="font-[family-name:var(--font-family-poppins)] leading-[22px] font-semibold"
                :class="
                  paso.activo ? 'text-base text-[#ff7500]' : 'text-sm leading-5 text-[#b3b7c3]'
                "
              >
                {{ paso.titulo }}
              </p>
              <p
                class="text-xs leading-5"
                :class="paso.activo ? 'text-[#173748]' : 'text-[#b3b7c3]'"
              >
                {{ paso.paso }}
              </p>
            </li>
          </ol>
        </div>

        <p class="text-sm font-semibold text-[#173748]">
          Modalidad: <span class="text-[#ff7500]">{{ modalidadLabel }}</span>
        </p>
        <div
          v-if="cargandoTarifas"
          class="flex flex-col items-center justify-center gap-3 py-8"
          role="status"
          aria-live="polite"
          aria-busy="true"
          data-testid="loader-tarifas"
        >
          <span
            class="inline-block size-10 animate-spin rounded-full border-[3px] border-[#ededed] border-t-[#ff7500]"
            aria-hidden="true"
          />
          <span class="sr-only">Consultando primas Plus y Pro en CRM</span>
        </div>
        <p v-else-if="errorTarifa" class="text-sm text-[#b45309]">{{ errorTarifa }}</p>

        <div class="grid grid-cols-1 gap-10 xl:grid-cols-2">
          <article
            v-for="plan in planesVista"
            :key="plan.id"
            class="flex flex-col gap-4 rounded-[10px] bg-white px-4 pt-6 pb-4 shadow-[3px_3px_10px_rgba(23,55,72,0.3)]"
            :class="[
              detallesAbiertos[plan.id] ? plan.tabla.borde : 'border border-transparent',
              planSeleccionado === plan.id ? 'ring-2 ring-[#ff7500]' : '',
            ]"
          >
            <div class="flex items-start gap-4">
              <div class="flex shrink-0 flex-col gap-[9px]">
                <div class="flex items-start gap-2">
                  <img
                    :src="$publicUrl(plan.badge)"
                    :alt="`Plan ${plan.nombre}`"
                    :width="plan.badgeWidth"
                    :height="plan.badgeHeight"
                  />
                  <div>
                    <p
                      class="font-[family-name:var(--font-family-poppins)] text-base leading-[22px] font-semibold text-[#173748]"
                    >
                      {{ plan.nombre }}
                    </p>
                    <p class="text-[10px] leading-3 text-[#5d6977]">Viajero</p>
                  </div>
                </div>
                <div class="w-[125px] rounded bg-[#f7f7f7] p-1">
                  <p
                    class="font-[family-name:var(--font-family-poppins)] font-semibold"
                    :class="detallesAbiertos[plan.id] ? plan.precioAbierto : 'text-[#173748]'"
                  >
                    <span class="text-sm leading-5">COP</span>
                    <span class="ml-1 text-xl leading-7">{{ plan.precio }}</span>
                  </p>
                  <p class="text-[10px] leading-3 text-[#5d6977]">{{ plan.descuento }}</p>
                  <p class="mt-1 text-xs leading-4 text-[#5d6977]">Precio final:</p>
                  <p
                    class="font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#173748]"
                  >
                    {{ plan.precioFinal }}
                  </p>
                </div>
              </div>

              <div class="w-px self-stretch bg-[#ededed]" />

              <div class="min-w-0 flex-1">
                <p class="text-sm leading-[22px]" :class="plan.montoTituloClase">
                  {{ plan.montoTitulo }}
                </p>
                <p class="text-sm leading-[22px] text-[#173748]">
                  <span :class="plan.montoValorClase">{{ plan.montoValor }}</span>
                  DE ASISTENCIA MÉDICA
                </p>
                <ul class="mt-2 flex flex-col gap-2.5">
                  <li
                    v-for="beneficio in plan.beneficios"
                    :key="beneficio.destacado"
                    class="flex items-start gap-2 text-sm leading-[22px] text-[#173748]"
                  >
                    <img
                      :src="$publicUrl('images/planes/icon-check.svg')"
                      alt=""
                      width="15"
                      height="21"
                    />
                    <span>
                      <template v-if="beneficio.destacado.startsWith('Telemedicina')">
                        <strong class="font-semibold">{{ beneficio.destacado }}</strong
                        >{{ beneficio.texto }}
                      </template>
                      <template v-else>
                        {{ beneficio.texto
                        }}<strong class="font-semibold">{{ beneficio.destacado }}</strong
                        >.
                      </template>
                    </span>
                  </li>
                </ul>
              </div>
            </div>

            <div class="flex flex-col gap-2.5 sm:flex-row">
              <button
                type="button"
                class="inline-flex min-w-0 flex-1 items-center gap-2.5 rounded-[5px] px-[15px] py-2 text-base leading-6"
                :class="plan.detalleBoton"
                :aria-expanded="detallesAbiertos[plan.id]"
                @click="alternarDetalle(plan.id)"
              >
                <img :src="$publicUrl(plan.iconoRegalo)" alt="" width="16" height="16" />
                <span class="min-w-0 flex-1 text-left tracking-[-0.48px] whitespace-nowrap"
                  >Ver detalle, cobertura y beneficios</span
                >
                <img
                  :src="$publicUrl('images/cotizador/icon-chevron.svg')"
                  alt=""
                  width="16"
                  height="16"
                  class="transition"
                  :class="detallesAbiertos[plan.id] ? 'rotate-180' : ''"
                />
              </button>
              <button
                type="button"
                class="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg px-[30px] py-2.5 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold transition disabled:cursor-not-allowed disabled:opacity-50"
                :class="plan.seleccionar"
                :disabled="cargandoTarifas || !tarifas[plan.id]?.quoterHeaderId"
                @click="seleccionar(plan.id)"
              >
                {{
                  cargandoTarifas
                    ? "Cotizando…"
                    : planSeleccionado === plan.id
                      ? "Seleccionado"
                      : "Seleccionar"
                }}
                <img
                  :src="$publicUrl('images/cotizador/icon-arrow.svg')"
                  alt=""
                  width="18"
                  height="18"
                />
              </button>
            </div>

            <div v-if="detallesAbiertos[plan.id]" class="flex w-full flex-col gap-2">
              <div
                class="flex items-center justify-center gap-6 rounded-[5px] px-5 py-2.5 text-center font-[family-name:var(--font-family-poppins)] font-semibold text-white"
                :class="[plan.tabla.barra, plan.tabla.textoBarra]"
              >
                <p class="w-[55%] shrink-0">COBERTURAS</p>
                <p class="min-w-0 flex-1">{{ plan.tabla.titulo }}</p>
              </div>

              <div class="flex flex-col gap-2 px-4">
                <div
                  class="flex items-center justify-center gap-4 px-5 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#173748]"
                >
                  <p class="min-w-0 flex-1">MONEDA</p>
                  <p
                    v-for="moneda in plan.tabla.monedas"
                    :key="moneda"
                    class="shrink-0 text-center"
                    :class="plan.tabla.columna"
                  >
                    {{ moneda }}
                  </p>
                </div>
                <div class="flex justify-end px-5">
                  <span class="h-px bg-[#d5d8de]" :class="plan.tabla.lineaMoneda" />
                </div>

                <template v-for="fila in plan.tabla.filas" :key="fila.concepto">
                  <div
                    class="flex items-center gap-2 px-5"
                    :class="
                      fila.destacada
                        ? 'font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#173748]'
                        : 'pb-1 text-xs leading-4 text-[#5d6977]'
                    "
                  >
                    <p class="min-w-0 flex-1">{{ fila.concepto }}</p>
                    <p
                      v-for="(valor, indice) in fila.valores"
                      :key="`${fila.concepto}-${indice}`"
                      class="shrink-0 text-center"
                      :class="plan.tabla.columna"
                    >
                      {{ valor }}
                    </p>
                  </div>
                  <div v-if="fila.destacada" class="h-px w-full bg-[#d5d8de]" />
                </template>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  </section>
</template>
