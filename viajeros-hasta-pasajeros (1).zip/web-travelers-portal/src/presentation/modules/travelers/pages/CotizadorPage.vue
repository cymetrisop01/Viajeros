<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import DatePicker from "primevue/datepicker";
import type { PaisItem } from "@/domain/travelers/models/catalogos.types";
import {
  CODIGO_COLOMBIA,
  DIAS_VIGENCIA_DEFAULT,
  esColombia,
  esViajeNacional,
  sumarDiasIso,
} from "@/application/travelers/mappers/plan-crm";
import { guardarCotizacionSesion } from "@/application/travelers/session/cotizacion-session";
import {
  cargarPaises,
  paisPorCodigo,
  paisPorNombre,
} from "@/application/travelers/use-cases/cargar-paises";
import { parametriaPort } from "@/infrastructure/travelers/composition";
import { asDatePickerModel, coerceLocalDateIso, todayStartLocalDate } from "../utils/fecha-local";

const router = useRouter();

/** Preferencias de destino internacional (nombres del catálogo BFF, sin acentos). */
const DESTINO_INTL_PREFERIDOS = ["ESPAÑA", "ESTADOS UNIDOS", "MEXICO", "FRANCIA"] as const;

/** Temporal: solo 1 viajero habilitado en cotización. */
const VIAJEROS = [{ value: "1", label: "1 viajero" }] as const;

const paises = ref<PaisItem[]>([]);
const cargandoPaises = ref(true);
const errorPaises = ref("");
const cotizando = ref(false);

const soyColombiano = ref(true);
const origenCodigo = ref(CODIGO_COLOMBIA);
/** Destino por código ISO numérico del mismo catálogo BFF que Origen. */
const destinoCodigo = ref("");
const fecha = ref("");
const viajeros = ref("1");

const origenNombre = computed(
  () => paisPorCodigo(paises.value, origenCodigo.value)?.nombre ?? "Colombia",
);
const destinoBloqueado = computed(() => !esColombia(origenCodigo.value, origenNombre.value));
/** Mismo catálogo API que Origen; si origen ≠ Colombia solo queda Colombia. */
const destinos = computed(() => {
  if (!paises.value.length) return [];
  if (destinoBloqueado.value) {
    const co = paises.value.find((p) => esColombia(p.codigo, p.nombre));
    return co ? [co] : [];
  }
  return paises.value;
});
const errorCotizar = ref("");

const minFechaViaje = todayStartLocalDate();

const viajerosLabel = computed(() => {
  const match = VIAJEROS.find((item) => item.value === viajeros.value);
  return match?.label ?? "Seleccionar";
});

function codigoColombia(): string {
  return paisPorNombre(paises.value, "Colombia")?.codigo ?? CODIGO_COLOMBIA;
}

/** Destino internacional por defecto (no Colombia) desde el catálogo API. */
function codigoDestinoInternacional(): string {
  for (const nombre of DESTINO_INTL_PREFERIDOS) {
    const match = paisPorNombre(paises.value, nombre);
    if (match) return match.codigo;
  }
  const otro = paises.value.find((p) => !esColombia(p.codigo, p.nombre));
  return otro?.codigo ?? "";
}

function asegurarDestinoValido() {
  if (destinoBloqueado.value) {
    destinoCodigo.value = codigoColombia();
    return;
  }
  if (!destinoCodigo.value || !paisPorCodigo(paises.value, destinoCodigo.value)) {
    destinoCodigo.value = codigoDestinoInternacional();
  }
}

onMounted(async () => {
  cargandoPaises.value = true;
  errorPaises.value = "";
  try {
    paises.value = await cargarPaises(parametriaPort);
    if (!paisPorCodigo(paises.value, origenCodigo.value)) {
      origenCodigo.value = codigoColombia();
    }
    asegurarDestinoValido();
  } catch {
    errorPaises.value = "No se pudieron cargar los países. Se usará un catálogo local.";
  } finally {
    cargandoPaises.value = false;
  }
});

function aplicarOrigen(codigo: string) {
  origenCodigo.value = codigo;
  const pais = paisPorCodigo(paises.value, codigo);
  if (esColombia(codigo, pais?.nombre)) {
    soyColombiano.value = true;
    if (esColombia(destinoCodigo.value, paisPorCodigo(paises.value, destinoCodigo.value)?.nombre)) {
      destinoCodigo.value = codigoDestinoInternacional();
    }
    return;
  }
  soyColombiano.value = false;
  destinoCodigo.value = codigoColombia();
}

function toggleColombiano() {
  if (soyColombiano.value) {
    soyColombiano.value = false;
    const usa = paisPorNombre(paises.value, "Estados Unidos");
    origenCodigo.value = usa?.codigo ?? "840";
    destinoCodigo.value = codigoColombia();
    return;
  }
  soyColombiano.value = true;
  origenCodigo.value = codigoColombia();
  if (esColombia(destinoCodigo.value, paisPorCodigo(paises.value, destinoCodigo.value)?.nombre)) {
    destinoCodigo.value = codigoDestinoInternacional();
  }
}

function volver() {
  if (window.history.length > 1) {
    router.back();
    return;
  }
  void router.push({ name: "Cotizador" });
}

function onFechaChange(value: unknown) {
  fecha.value = coerceLocalDateIso(value);
}

function resolverDestino(): { codigo: string; nombre: string } {
  const match = paisPorCodigo(paises.value, destinoCodigo.value);
  if (match) return { codigo: match.codigo, nombre: match.nombre };
  const co = codigoColombia();
  return {
    codigo: co,
    nombre: paisPorCodigo(paises.value, co)?.nombre ?? "Colombia",
  };
}

function cotizar() {
  errorCotizar.value = "";
  if (cotizando.value) return;
  if (!fecha.value || !viajeros.value) {
    errorCotizar.value = "Selecciona fecha del viaje y número de viajeros para continuar.";
    return;
  }
  cotizando.value = true;
  const destino = resolverDestino();
  const nacional = esViajeNacional(
    origenCodigo.value,
    origenNombre.value,
    destino.codigo,
    destino.nombre,
  );
  const cantidad = Number(viajeros.value) || 1;
  const fechaFin = sumarDiasIso(fecha.value, DIAS_VIGENCIA_DEFAULT);

  guardarCotizacionSesion({
    origenCodigo: origenCodigo.value,
    origenNombre: origenNombre.value,
    destinoCodigo: destino.codigo,
    destinoNombre: destino.nombre,
    esNacional: nacional,
    fechaInicio: fecha.value,
    fechaFin,
    cantidadViajeros: cantidad,
  });

  void router
    .push({
      name: "Planes",
      query: {
        origen: origenNombre.value,
        destino: destino.nombre,
        fecha: fecha.value,
        viajeros: String(cantidad),
      },
    })
    .finally(() => {
      cotizando.value = false;
    });
}
</script>

<template>
  <section class="relative overflow-hidden bg-[#f7f7f7] px-6 pt-[50px] pb-[90px] md:px-[120px]">
    <img
      :src="$publicUrl('images/cotizador/bg-map.svg')"
      alt=""
      width="650"
      height="650"
      class="pointer-events-none absolute -top-[100px] -left-[85px] select-none"
    />

    <div class="relative mx-auto flex w-full max-w-[1200px] flex-col gap-[29px]">
      <button
        type="button"
        class="inline-flex w-fit items-center gap-2 rounded-lg border border-[#173748] bg-transparent px-4 py-2 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-[#173748] transition hover:bg-white"
        @click="volver"
      >
        <img :src="$publicUrl('images/cotizador/icon-back.svg')" alt="" width="18" height="18" />
        Volver al seguro viajeros
      </button>

      <form
        class="flex w-full flex-col gap-5 rounded-3xl bg-white p-6 shadow-[3px_3px_10px_rgba(23,55,72,0.3)] md:p-10"
        novalidate
        @submit.prevent="cotizar"
      >
        <div class="flex flex-col items-start gap-6 lg:flex-row lg:items-center lg:gap-10">
          <h1
            class="w-full max-w-[262px] font-[family-name:var(--font-family-poppins)] text-[35px] leading-[45px] font-bold tracking-[-1.05px] text-[#0d2333]"
          >
            Cotizador del Seguro
            <span class="text-[#ff7500]">Viajero</span>
          </h1>
          <p class="min-w-0 flex-1 text-lg leading-7 text-[#173748]">
            <span class="font-[family-name:var(--font-family-poppins)] leading-6 font-semibold">
              Importante:
            </span>
            Si seleccionas Colombia como país de origen, podrás elegir cualquier destino. Sin
            embargo, si seleccionas otro país como origen, el destino se ajustará automáticamente a
            Colombia y los demás países no estarán disponibles.
          </p>
        </div>

        <p v-if="errorPaises" class="text-sm text-[#b45309]">{{ errorPaises }}</p>
        <p v-else-if="cargandoPaises" class="text-sm text-[#5d6977]">Cargando países…</p>

        <button
          type="button"
          class="inline-flex w-fit items-center gap-3"
          :aria-pressed="soyColombiano"
          @click="toggleColombiano"
        >
          <span
            class="inline-flex size-4 items-center justify-center rounded bg-[#ff7500]"
            aria-hidden="true"
          >
            <img
              v-if="soyColombiano"
              :src="$publicUrl('images/cotizador/icon-check.svg')"
              alt=""
              width="16"
              height="16"
            />
          </span>
          <span class="leading-[22px] font-semibold text-[#173748]">Soy Colombiano</span>
        </button>

        <div class="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
          <label class="flex flex-col gap-[5px]">
            <span
              class="font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-[#173748]"
            >
              Origen*
            </span>
            <span
              class="flex items-center gap-2.5 rounded-[5px] border border-[#ededed] bg-white px-[15px] py-2"
            >
              <img
                :src="$publicUrl('images/cotizador/icon-origin.svg')"
                alt=""
                width="16"
                height="16"
              />
              <select
                class="min-w-0 flex-1 appearance-none bg-transparent text-base leading-6 text-[#173748] outline-none"
                :value="origenCodigo"
                :disabled="cargandoPaises && !paises.length"
                @change="aplicarOrigen(($event.target as HTMLSelectElement).value)"
              >
                <option v-for="pais in paises" :key="pais.codigo" :value="pais.codigo">
                  {{ pais.nombre }}
                </option>
              </select>
              <img
                :src="$publicUrl('images/cotizador/icon-chevron.svg')"
                alt=""
                width="16"
                height="16"
              />
            </span>
          </label>

          <label class="flex flex-col gap-[5px]">
            <span
              class="font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-[#173748]"
            >
              Destino*
            </span>
            <span
              class="flex items-center gap-2.5 rounded-[5px] border border-[#ededed] bg-white px-[15px] py-2"
            >
              <img
                :src="$publicUrl('images/cotizador/icon-origin.svg')"
                alt=""
                width="16"
                height="16"
              />
              <select
                class="min-w-0 flex-1 appearance-none bg-transparent text-base leading-6 text-[#173748] outline-none disabled:cursor-not-allowed disabled:opacity-70"
                :value="destinoCodigo"
                :disabled="destinoBloqueado || (cargandoPaises && !paises.length)"
                @change="destinoCodigo = ($event.target as HTMLSelectElement).value"
              >
                <option v-for="pais in destinos" :key="pais.codigo" :value="pais.codigo">
                  {{ pais.nombre }}
                </option>
              </select>
              <img
                :src="$publicUrl('images/cotizador/icon-chevron.svg')"
                alt=""
                width="16"
                height="16"
              />
            </span>
          </label>

          <div class="flex flex-col gap-[5px]">
            <label
              class="font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-[#173748]"
              for="cotizador-fecha-viaje-input"
            >
              Fecha del viaje*
            </label>
            <DatePicker
              id="cotizador-fecha-viaje"
              :model-value="asDatePickerModel(fecha)"
              show-icon
              icon-display="input"
              date-format="dd/mm/yy"
              placeholder="Seleccionar"
              fluid
              :min-date="minFechaViaje"
              :show-button-bar="false"
              input-id="cotizador-fecha-viaje-input"
              :input-class="'w-full'"
              class="cotizador-datepicker w-full [&_.p-inputtext]:w-full"
              required
              aria-label="Fecha del viaje"
              @update:model-value="onFechaChange"
            />
          </div>

          <label class="flex flex-col gap-[5px]">
            <span
              class="font-[family-name:var(--font-family-poppins)] text-base leading-6 font-semibold text-[#173748]"
            >
              Viajeros*
            </span>
            <span
              class="relative flex items-center gap-2.5 rounded-[5px] border border-[#ededed] bg-white px-[15px] py-2"
            >
              <img
                :src="$publicUrl('images/cotizador/icon-travelers.svg')"
                alt=""
                width="16"
                height="16"
              />
              <span
                class="pointer-events-none min-w-0 flex-1 truncate text-base leading-6 text-[#173748]"
              >
                {{ viajerosLabel }}
              </span>
              <img
                :src="$publicUrl('images/cotizador/icon-chevron.svg')"
                alt=""
                width="16"
                height="16"
              />
              <select
                v-model="viajeros"
                required
                aria-label="Viajeros"
                class="absolute inset-0 cursor-pointer opacity-0"
              >
                <option v-for="item in VIAJEROS" :key="item.value" :value="item.value">
                  {{ item.label }}
                </option>
              </select>
            </span>
          </label>
        </div>

        <p v-if="errorCotizar" class="text-right text-sm text-[#b45309]">{{ errorCotizar }}</p>
        <div class="flex justify-end">
          <button
            type="submit"
            class="inline-flex items-center gap-2 rounded-lg border border-[#ff7500] bg-[#ff7500] px-[30px] py-2.5 font-[family-name:var(--font-family-poppins)] text-sm leading-5 font-semibold text-white transition hover:bg-[#e06600] disabled:opacity-60"
            :disabled="cotizando"
          >
            {{ cotizando ? "Cotizando…" : "Cotizar" }}
            <img
              :src="$publicUrl('images/cotizador/icon-arrow.svg')"
              alt=""
              width="18"
              height="18"
            />
          </button>
        </div>
      </form>
    </div>
  </section>
</template>
