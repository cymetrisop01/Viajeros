import { describe, expect, it } from "vitest";
import {
  asDatePickerModel,
  coerceLocalDateIso,
  formatLocalDate,
  parseLocalDate,
  todayLocalDate,
  todayStartLocalDate,
} from "./fecha-local";

describe("parseLocalDate", () => {
  it("parsea YYYY-MM-DD a Date local a mediodía", () => {
    const fecha = parseLocalDate("2026-07-12");
    expect(fecha).not.toBeNull();
    expect(fecha?.getFullYear()).toBe(2026);
    expect(fecha?.getMonth()).toBe(6);
    expect(fecha?.getDate()).toBe(12);
    expect(fecha?.getHours()).toBe(12);
  });

  it("retorna null con valor inválido", () => {
    expect(parseLocalDate("")).toBeNull();
    expect(parseLocalDate("12/07/2026")).toBeNull();
  });
});

describe("formatLocalDate", () => {
  it("formatea Date a YYYY-MM-DD", () => {
    expect(formatLocalDate(new Date(2026, 6, 12, 12))).toBe("2026-07-12");
  });
});

describe("coerceLocalDateIso", () => {
  it("normaliza string ISO", () => {
    expect(coerceLocalDateIso("2026-07-12")).toBe("2026-07-12");
  });

  it("normaliza Date", () => {
    expect(coerceLocalDateIso(new Date(2026, 8, 28, 15, 30))).toBe("2026-09-28");
  });

  it("retorna vacío con valores nulos", () => {
    expect(coerceLocalDateIso(null)).toBe("");
    expect(coerceLocalDateIso("")).toBe("");
  });
});

describe("asDatePickerModel", () => {
  it("convierte ISO a Date o null", () => {
    expect(asDatePickerModel("2026-07-12")).toBeInstanceOf(Date);
    expect(asDatePickerModel("")).toBeNull();
    expect(asDatePickerModel(null)).toBeNull();
  });
});

describe("todayLocalDate / todayStartLocalDate", () => {
  it("devuelve límites del día local", () => {
    const inicio = todayStartLocalDate();
    const fin = todayLocalDate();
    const ahora = new Date();
    expect(inicio.getFullYear()).toBe(ahora.getFullYear());
    expect(inicio.getMonth()).toBe(ahora.getMonth());
    expect(inicio.getDate()).toBe(ahora.getDate());
    expect(inicio.getHours()).toBe(0);
    expect(fin.getHours()).toBe(23);
    expect(fin.getMinutes()).toBe(59);
  });
});
