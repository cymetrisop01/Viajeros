/** Modelo fecha `YYYY-MM-DD` ↔ `Date` local (mediodía) para DatePicker. */
export function parseLocalDate(s: string): Date | null {
  const m = s?.trim().match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]) - 1;
  const d = Number(m[3]);
  return new Date(y, mo, d, 12, 0, 0, 0);
}

export function formatLocalDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function toLocalCalendarDate(value: unknown): Date | null {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate(), 12, 0, 0, 0);
  }
  if (Array.isArray(value)) return toLocalCalendarDate(value[0]);
  if (typeof value === "string" && value.trim()) return parseLocalDate(value);
  return null;
}

/** Normaliza valor del DatePicker a `YYYY-MM-DD` (vacío si no es válido). */
export function coerceLocalDateIso(value: unknown): string {
  if (value == null || value === "") return "";
  if (typeof value === "string") {
    const trimmed = value.trim();
    const m = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[1]}-${m[2]}-${m[3]}`;
    const d = parseLocalDate(trimmed);
    return d ? formatLocalDate(d) : "";
  }
  const d = toLocalCalendarDate(value);
  return d ? formatLocalDate(d) : "";
}

/** Fin del día de hoy (local). Usar como `maxDate` en DatePicker. */
export function todayLocalDate(): Date {
  const n = new Date();
  return new Date(n.getFullYear(), n.getMonth(), n.getDate(), 23, 59, 59, 999);
}

/** Inicio del día de hoy (local). Usar como `minDate` en DatePicker. */
export function todayStartLocalDate(): Date {
  const n = new Date();
  return new Date(n.getFullYear(), n.getMonth(), n.getDate(), 0, 0, 0, 0);
}

/** Valor para `:model-value` de PrimeVue DatePicker. */
export function asDatePickerModel(value: string | null | undefined): Date | null {
  if (value == null || value === "") return null;
  return parseLocalDate(value);
}
