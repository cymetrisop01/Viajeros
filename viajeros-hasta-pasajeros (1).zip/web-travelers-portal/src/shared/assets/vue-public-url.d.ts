declare module "vue" {
  interface ComponentCustomProperties {
    $publicUrl: (path: string) => string;
  }
}

export {};
