/**
 * Ruta bajo `public/` respetando Vite `BASE_URL`.
 */
export function publicUrl(path: string): string {
  const base = String(import.meta.env.BASE_URL || "/");
  const normalized = path.replace(/^\/+/, "");
  const prefix = base.endsWith("/") ? base : `${base}/`;
  return `${prefix}${normalized}`;
}
