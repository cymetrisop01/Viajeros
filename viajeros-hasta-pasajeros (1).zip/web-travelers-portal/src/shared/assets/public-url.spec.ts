import { describe, expect, it } from "vitest";
import { publicUrl } from "./public-url";

describe("publicUrl", () => {
  it("normaliza path sin slash inicial", () => {
    expect(publicUrl("images/logo.svg")).toBe("/images/logo.svg");
    expect(publicUrl("/images/logo.svg")).toBe("/images/logo.svg");
  });
});
