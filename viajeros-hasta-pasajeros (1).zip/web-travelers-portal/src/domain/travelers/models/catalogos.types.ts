export type PaisItem = {
  codigo: string;
  nombre: string;
  iso2?: string;
  iso3?: string;
};

export type DivisionPoliticaItem = {
  id: string;
  nombre: string;
  idPais: string;
  tipo?: string;
};

/** Catálogo BFF /parametria/tipos-documento (seed siniestros). */
export type TipoDocumentoItem = {
  codigo: string;
  nombre: string;
};

export type PlanUiId = "plus" | "pro";

export type CotizacionViaje = {
  origenCodigo: string;
  origenNombre: string;
  destinoCodigo: string;
  destinoNombre: string;
  esNacional: boolean;
  fechaInicio: string;
  fechaFin: string;
  cantidadViajeros: number;
};

export type PlanTarifa = {
  planUi: PlanUiId;
  planCrmId: number;
  nombreCrm?: string;
  quoterHeaderId: string;
  prima: number;
  fuente: string;
};

export type IdentidadResultado = {
  valido: boolean;
  tipoDocumento: string;
  numeroDocumento: string;
  primerNombre?: string;
  primerApellido?: string;
  fuente: string;
  mensaje?: string;
};

export type ViajeroSesion = {
  id: number;
  principal: boolean;
  menor: boolean;
  tipoDocumento: string;
  tipoDocumentoCodigo: string;
  numeroDocumento: string;
  nacimiento: string;
  primerNombre: string;
  segundoNombre: string;
  primerApellido: string;
  segundoApellido: string;
  genero: string;
  generoCodigo: string;
  correo: string;
  celular: string;
  direccion: string;
  departamento: string;
  ciudad: string;
  ciiu: string;
  peps: boolean;
};

export type CotizacionSesion = CotizacionViaje & {
  planUi?: PlanUiId;
  planCrmId?: number;
  quoteHeaderId?: string;
  prima?: number;
  planNombre?: string;
  viajeros?: ViajeroSesion[];
  paymentLink?: string;
};
