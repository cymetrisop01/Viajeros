import type { IdentidadResultado } from "../models/catalogos.types";

export type IdentidadCommand = {
  tipoDocumento: string;
  numeroDocumento: string;
  fechaNacimiento: string;
};

export abstract class IdentidadPort {
  abstract consultar(command: IdentidadCommand): Promise<IdentidadResultado>;
}
