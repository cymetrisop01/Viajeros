import type { CotizacionViaje, PlanTarifa, PlanUiId } from "../models/catalogos.types";

export type TarifarCommand = {
  planUi: PlanUiId;
  planCrmId: number;
  effectiveStartDate: string;
  effectiveEndDate: string;
  cantidadViajeros: number;
  codeDaneDepartment?: string;
  codeDaneCity?: string;
};

export abstract class TarifacionPort {
  abstract calcularPrima(command: TarifarCommand): Promise<PlanTarifa>;
  /** Cotiza Plus y Pro según modalidad del viaje (2 llamados CRM en BFF). */
  abstract calcularPrimasPlanes(viaje: CotizacionViaje): Promise<PlanTarifa[]>;
}
