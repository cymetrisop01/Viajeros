import type { DivisionPoliticaItem, PaisItem, TipoDocumentoItem } from "../models/catalogos.types";

export abstract class ParametriaPort {
  abstract listarPaises(): Promise<PaisItem[]>;
  abstract consultarDivisionPolitica(idPais: string): Promise<DivisionPoliticaItem[]>;
  abstract listarTiposDocumento(): Promise<TipoDocumentoItem[]>;
}
