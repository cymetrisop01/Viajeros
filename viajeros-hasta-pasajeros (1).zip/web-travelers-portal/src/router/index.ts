import { createRouter, createWebHistory } from "vue-router";
import { MainLayout } from "@/presentation/shared/layouts";

const DEFAULT_TITLE = "Seguro Viajero";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      component: MainLayout,
      children: [
        {
          path: "",
          name: "Cotizador",
          meta: { title: "Cotizador del Seguro Viajero" },
          component: () =>
            import("@/presentation/modules/travelers/pages").then((m) => m.CotizadorPage),
        },
        {
          path: "planes",
          name: "Planes",
          meta: { title: "Selecciona tu plan" },
          component: () =>
            import("@/presentation/modules/travelers/pages").then((m) => m.PlanesPage),
        },
        {
          path: "pasajeros",
          name: "Pasajeros",
          meta: { title: "Información de los pasajeros" },
          component: () =>
            import("@/presentation/modules/travelers/pages").then((m) => m.PasajerosPage),
        },
      ],
    },
  ],
});

router.afterEach((to) => {
  const title = to.meta.title;
  document.title = typeof title === "string" ? title : DEFAULT_TITLE;
});

export default router;
