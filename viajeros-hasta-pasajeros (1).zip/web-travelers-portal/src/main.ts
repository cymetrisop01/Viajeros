import { createApp } from "vue";
import PrimeVue from "primevue/config";
import Aura from "@primeuix/themes/aura";
import { definePreset } from "@primeuix/themes";
import App from "./App.vue";
import router from "./router";
import { publicUrl } from "@/shared/assets/public-url";
import "primeicons/primeicons.css";
import "./style.css";

const app = createApp(App);
app.config.globalProperties.$publicUrl = publicUrl;

const appTheme = definePreset(Aura, {
  semantic: {
    primary: {
      50: "#fff8f2",
      100: "#ffe8d4",
      200: "#ffc98f",
      300: "#ffa64d",
      400: "#ff880d",
      500: "#ff7500",
      600: "#e06600",
      700: "#b85200",
      800: "#933f00",
      900: "#7a3400",
      950: "#421c00",
    },
  },
});

app.use(PrimeVue, {
  theme: {
    preset: appTheme,
    options: {
      prefix: "p",
      darkModeSelector: false,
      cssLayer: false,
    },
  },
});
app.use(router);
app.mount("#app");
