const DEFAULT_BASE = "http://localhost:5001/api/viajeros/v1";
const DEFAULT_TIMEOUT_MS = 45_000;

export class ViajerosHttpError extends Error {
  status: number;
  body?: unknown;

  constructor(message: string, status: number, body?: unknown) {
    super(message);
    this.name = "ViajerosHttpError";
    this.status = status;
    this.body = body;
  }
}

export function viajerosApiBaseUrl(): string {
  const raw = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim();
  return (raw || DEFAULT_BASE).replace(/\/$/, "");
}

function detailFromBody(body: unknown): string | undefined {
  if (!body || typeof body !== "object") return undefined;
  const o = body as Record<string, unknown>;
  if (typeof o.detail === "string") return o.detail;
  if (typeof o.message === "string") return o.message;
  if (Array.isArray(o.message)) return o.message.map(String).join("; ");
  return undefined;
}

export async function viajerosFetch<T>(
  path: string,
  init: RequestInit = {},
  timeoutMs = DEFAULT_TIMEOUT_MS,
): Promise<T> {
  const url = `${viajerosApiBaseUrl()}${path.startsWith("/") ? path : `/${path}`}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const headers = new Headers(init.headers);
  if (!headers.has("Accept")) headers.set("Accept", "application/json");
  if (init.body != null && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  let res: Response;
  try {
    res = await fetch(url, { ...init, headers, signal: controller.signal });
  } catch (e) {
    const aborted = e instanceof Error && e.name === "AbortError";
    throw new ViajerosHttpError(
      aborted ? "El BFF Viajeros no respondió a tiempo." : "No se pudo contactar el BFF Viajeros.",
      0,
      e,
    );
  } finally {
    clearTimeout(timer);
  }

  const text = await res.text().catch(() => "");
  let parsed: unknown = undefined;
  if (text) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = text;
    }
  }

  if (!res.ok) {
    throw new ViajerosHttpError(
      detailFromBody(parsed) || `BFF respondió ${res.status}.`,
      res.status,
      parsed,
    );
  }

  return parsed as T;
}
