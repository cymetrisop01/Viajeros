import { IdentidadHttpAdapter } from "./identidad-http.adapter";
import { ParametriaHttpAdapter } from "./parametria-http.adapter";
import { TarifacionHttpAdapter } from "./tarifacion-http.adapter";

/** Composition root: un solo lugar cablea puertos → adapters HTTP del BFF. */
export const parametriaPort = new ParametriaHttpAdapter();
export const tarifacionPort = new TarifacionHttpAdapter();
export const identidadPort = new IdentidadHttpAdapter();
