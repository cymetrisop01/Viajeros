import type { CotizacionViaje, PlanTarifa } from "@/domain/travelers/models/catalogos.types";
import { TarifacionPort, type TarifarCommand } from "@/domain/travelers/ports/tarifacion.port";
import { viajerosFetch } from "@/infrastructure/http/viajeros-http";

type TarifaApi = {
  quoterHeaderId: string;
  plan?: string;
  prima?: number;
  message?: string;
  fuente: string;
};

type PlanesApi = {
  esNacional: boolean;
  planes: Array<{
    planUi: "plus" | "pro";
    planCrmId: number;
    quoterHeaderId: string;
    plan?: string;
    prima?: number;
    message?: string;
    fuente: string;
  }>;
};

/** Campo CRM «N° Viajeros» (guía / stub cotizadores). */
const FIELD_VIAJEROS = 1651;
const QUOTE_GENERATOR_ID = 1255;

/** Dos CRM en paralelo pueden superar 60 s c/u; margen del BFF batch. */
const BATCH_TIMEOUT_MS = 130_000;

export class TarifacionHttpAdapter extends TarifacionPort {
  async calcularPrima(command: TarifarCommand): Promise<PlanTarifa> {
    const body = {
      planId: command.planCrmId,
      quoteGeneratorId: QUOTE_GENERATOR_ID,
      effectiveStartDate: command.effectiveStartDate,
      effectiveEndDate: command.effectiveEndDate,
      fieldLines: [{ id: FIELD_VIAJEROS, value: String(command.cantidadViajeros) }],
      codeDaneDepartment: command.codeDaneDepartment ?? "11",
      codeDaneCity: command.codeDaneCity ?? "11001",
    };
    const res = await viajerosFetch<TarifaApi>("/tarifacion/calculo-prima", {
      method: "POST",
      body: JSON.stringify(body),
    });
    return {
      planUi: command.planUi,
      planCrmId: command.planCrmId,
      nombreCrm: res.plan,
      quoterHeaderId: res.quoterHeaderId,
      prima: Number(res.prima) || 0,
      fuente: res.fuente,
    };
  }

  /** Plus + Pro en un request; el BFF elige plan_id según nacional/internacional. */
  async calcularPrimasPlanes(viaje: CotizacionViaje): Promise<PlanTarifa[]> {
    const body = {
      esNacional: viaje.esNacional,
      effectiveStartDate: viaje.fechaInicio,
      effectiveEndDate: viaje.fechaFin,
      cantidadViajeros: viaje.cantidadViajeros,
      quoteGeneratorId: QUOTE_GENERATOR_ID,
      codeDaneDepartment: "11",
      codeDaneCity: "11001",
    };
    const res = await viajerosFetch<PlanesApi>(
      "/tarifacion/calculo-prima-planes",
      { method: "POST", body: JSON.stringify(body) },
      BATCH_TIMEOUT_MS,
    );
    return (res.planes ?? []).map((p) => ({
      planUi: p.planUi,
      planCrmId: p.planCrmId,
      nombreCrm: p.plan,
      quoterHeaderId: p.quoterHeaderId,
      prima: Number(p.prima) || 0,
      fuente: p.fuente,
    }));
  }
}
