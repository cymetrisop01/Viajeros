import type { IdentidadResultado } from "@/domain/travelers/models/catalogos.types";
import { IdentidadPort, type IdentidadCommand } from "@/domain/travelers/ports/identidad.port";
import { viajerosFetch } from "@/infrastructure/http/viajeros-http";

export class IdentidadHttpAdapter extends IdentidadPort {
  consultar(command: IdentidadCommand): Promise<IdentidadResultado> {
    return viajerosFetch<IdentidadResultado>("/validaciones/identidad", {
      method: "POST",
      body: JSON.stringify(command),
    });
  }
}
