import type {
  DivisionPoliticaItem,
  PaisItem,
  TipoDocumentoItem,
} from "@/domain/travelers/models/catalogos.types";
import { ParametriaPort } from "@/domain/travelers/ports/parametria.port";
import { viajerosFetch } from "@/infrastructure/http/viajeros-http";

export class ParametriaHttpAdapter extends ParametriaPort {
  listarPaises(): Promise<PaisItem[]> {
    return viajerosFetch<PaisItem[]>("/parametria/paises");
  }

  consultarDivisionPolitica(idPais: string): Promise<DivisionPoliticaItem[]> {
    const q = encodeURIComponent(idPais);
    return viajerosFetch<DivisionPoliticaItem[]>(`/parametria/division-politica?idPais=${q}`);
  }

  listarTiposDocumento(): Promise<TipoDocumentoItem[]> {
    return viajerosFetch<TipoDocumentoItem[]>("/parametria/tipos-documento");
  }
}
