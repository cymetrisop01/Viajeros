import { config } from "@vue/test-utils";
import { vi } from "vitest";
import { publicUrl } from "@/shared/assets/public-url";

vi.stubEnv("BASE_URL", "/");

config.global.mocks = {
  ...(config.global.mocks ?? {}),
  $publicUrl: publicUrl,
};
