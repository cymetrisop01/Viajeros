import { test, expect } from "@playwright/test";
import { irACotizador } from "./helpers";

test.describe("Cotizador — reglas de origen/destino", () => {
  test("carga catálogo de países desde BFF", async ({ page }) => {
    await irACotizador(page);
    const origen = page.locator("label:has-text('Origen*') select");
    const options = await origen.locator("option").count();
    expect(options).toBeGreaterThan(5);
    await expect(origen.locator("option").first()).toContainText(/Colombia/i);
  });

  test("Colombia origen permite destinos del catálogo API (incl. nacional)", async ({ page }) => {
    await irACotizador(page);
    const destino = page.locator("label:has-text('Destino*') select");
    await expect
      .poll(async () => destino.locator("option").count(), { timeout: 20_000 })
      .toBeGreaterThan(5);
    const labels = await destino.locator("option").allTextContents();
    expect(labels.some((l) => /Colombia/i.test(l))).toBeTruthy();
    expect(labels.some((l) => /España|Estados Unidos|México|Alemania/i.test(l))).toBeTruthy();
  });

  test("origen distinto a Colombia fuerza destino Colombia", async ({ page }) => {
    await irACotizador(page);
    const origen = page.locator("label:has-text('Origen*') select");
    const usa = origen.locator("option", { hasText: /Estados Unidos/i }).first();
    test.skip((await usa.count()) === 0, "Catálogo sin Estados Unidos");
    const value = await usa.getAttribute("value");
    await origen.selectOption(value!);
    const destino = page.locator("label:has-text('Destino*') select");
    await expect(destino.locator("option:checked")).toContainText(/Colombia/i);
    const labels = await destino.locator("option").allTextContents();
    expect(labels.map((l) => l.trim().toUpperCase())).toEqual(["COLOMBIA"]);
    await expect(destino).toBeDisabled();
  });

  test("toggle Soy Colombiano restaura Colombia", async ({ page }) => {
    await irACotizador(page);
    const toggle = page.getByRole("button", { name: /Soy Colombiano/i });
    await toggle.click();
    await expect(page.locator("label:has-text('Destino*') select option:checked")).toContainText(
      /Colombia/i,
    );
    await toggle.click();
    await expect(page.locator("label:has-text('Origen*') select")).toContainText(/Colombia/i);
  });

  test("Cotizar sin fecha muestra error visible", async ({ page }) => {
    await irACotizador(page);
    await page.locator('select[aria-label="Viajeros"]').selectOption("1");
    await page.getByRole("button", { name: /^Cotizar$/ }).click();
    await expect(page.getByText(/Selecciona fecha del viaje/i)).toBeVisible();
    await expect(page).toHaveURL(/\/?$/);
  });
});
