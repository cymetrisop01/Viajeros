import { test, expect } from "@playwright/test";
import { cotizarBasico, esperarPlanesCargados } from "./helpers";

test.describe("Flujo viaje nacional Colombia → Colombia", () => {
  test("destino Colombia marca sesión nacional", async ({ page }) => {
    await cotizarBasico(page, { viajeros: "1", destino: "Colombia" });
    await esperarPlanesCargados(page);
    await expect(page.getByText("Colombia - Colombia").first()).toBeVisible();

    const sesion = await page.evaluate(() =>
      JSON.parse(sessionStorage.getItem("viajeros.cotizacion.v1") || "{}"),
    );
    expect(sesion.esNacional).toBe(true);
    expect(sesion.destinoNombre).toMatch(/Colombia/i);

    await page
      .getByRole("button", { name: /^Seleccionar$/ })
      .first()
      .click();
    await expect(page).toHaveURL(/\/pasajeros/);
    const sesion2 = await page.evaluate(() =>
      JSON.parse(sessionStorage.getItem("viajeros.cotizacion.v1") || "{}"),
    );
    expect(sesion2.planUi).toBeTruthy();
    expect(sesion2.esNacional).toBe(true);
  });
});
