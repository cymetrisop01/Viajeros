import { test, expect } from "@playwright/test";
import { irACotizador, seleccionarFechaViaje, esperarPlanesCargados } from "./helpers";

test.describe("Flujo extranjero → Colombia", () => {
  test("origen USA bloquea destino y cotiza internacional", async ({ page }) => {
    await irACotizador(page);

    const origen = page.locator("label:has-text('Origen*') select");
    const destino = page.locator("label:has-text('Destino*') select");
    const usa = origen.locator("option", { hasText: /Estados Unidos/i }).first();
    test.skip((await usa.count()) === 0, "Sin Estados Unidos en catálogo");

    await origen.selectOption((await usa.getAttribute("value")) || { label: "Estados Unidos" });
    await expect(destino.locator("option:checked")).toContainText(/Colombia/i);
    await expect(destino).toBeDisabled();

    await seleccionarFechaViaje(page);
    await page.locator('select[aria-label="Viajeros"]').selectOption("1");
    await page.getByRole("button", { name: /^Cotizar$/ }).click();
    await expect(page).toHaveURL(/\/planes/);
    await esperarPlanesCargados(page);

    const sesion = await page.evaluate(() =>
      JSON.parse(sessionStorage.getItem("viajeros.cotizacion.v1") || "{}"),
    );
    expect(sesion.esNacional).toBe(false);
    expect(sesion.destinoNombre).toMatch(/Colombia/i);
    expect(sesion.destinoCodigo).toBe("170");
  });
});
