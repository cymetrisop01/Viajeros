import { test, expect } from "@playwright/test";
import { API_URL } from "./helpers";

test.describe("BFF Viajeros — salud y contratos", () => {
  test("GET /health responde 200", async ({ request }) => {
    const res = await request.get(`${API_URL}/health`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
  });

  test("GET /parametria/paises incluye Colombia", async ({ request }) => {
    const res = await request.get(`${API_URL}/api/viajeros/v1/parametria/paises`);
    expect(res.status()).toBe(200);
    const paises = await res.json();
    expect(Array.isArray(paises)).toBeTruthy();
    expect(paises.length).toBeGreaterThan(10);
    const colombia = paises.find(
      (p: { codigo: string; nombre: string }) =>
        p.codigo === "170" || p.nombre?.toUpperCase() === "COLOMBIA",
    );
    expect(colombia).toBeTruthy();
  });

  test("POST /tarifacion/calculo-prima Plus Internacional", async ({ request }) => {
    const res = await request.post(`${API_URL}/api/viajeros/v1/tarifacion/calculo-prima`, {
      data: {
        planId: 1453,
        effectiveStartDate: "2026-11-15",
        effectiveEndDate: "2026-12-02",
        fieldLines: [{ id: 1651, value: "2" }],
        quoteGeneratorId: 1255,
        codeDaneDepartment: "11",
        codeDaneCity: "11001",
      },
    });
    // CRM puede fallar por timeout; aceptamos 200 o 5xx documentado
    if (res.status() === 200) {
      const body = await res.json();
      expect(body.quoterHeaderId || body.fuente).toBeTruthy();
    } else {
      expect([502, 503, 504]).toContain(res.status());
    }
  });
});
