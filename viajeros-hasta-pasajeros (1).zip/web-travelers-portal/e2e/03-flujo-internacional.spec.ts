import { test, expect } from "@playwright/test";
import { cotizarBasico, esperarPlanesCargados } from "./helpers";

test.describe("Flujo viaje internacional Colombia → España", () => {
  test("cotizar navega a planes y muestra Plus/Pro", async ({ page }) => {
    await cotizarBasico(page, { viajeros: "1", destino: "España" });
    await esperarPlanesCargados(page);
    await expect(page.getByText("Plus", { exact: true }).first()).toBeVisible();
    await expect(page.getByText("Pro", { exact: true }).first()).toBeVisible();
    await expect(page.getByText("COP").first()).toBeVisible();
  });

  test("seleccionar Plus abre pasajeros con sesión", async ({ page }) => {
    await cotizarBasico(page, { viajeros: "1", destino: "España" });
    await esperarPlanesCargados(page);
    await page
      .getByRole("button", { name: /^Seleccionar$/ })
      .first()
      .click();
    await expect(page).toHaveURL(/\/pasajeros/);
    await expect(page.getByRole("button", { name: /Viajero 1/i })).toBeVisible();
    await expect(page.getByRole("heading", { name: /Carrito/i })).toBeVisible();

    const sesion = await page.evaluate(() => sessionStorage.getItem("viajeros.cotizacion.v1"));
    expect(sesion).toBeTruthy();
    const parsed = JSON.parse(sesion!);
    expect(parsed.cantidadViajeros).toBe(1);
    expect(parsed.planUi).toBe("plus");
    expect(parsed.esNacional).toBe(false);
    expect(parsed.destinoNombre).toMatch(/España/i);
  });
});
