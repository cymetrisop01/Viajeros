import { expect, type Page } from "@playwright/test";

export const API_URL = process.env.E2E_API_URL ?? "http://127.0.0.1:5001";

export async function irACotizador(page: Page) {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /Cotizador del Seguro/i })).toBeVisible();
  // Esperar catálogo BFF en Origen y Destino
  await expect
    .poll(async () => page.locator("label:has-text('Origen*') select option").count(), {
      timeout: 20_000,
    })
    .toBeGreaterThan(5);
  await expect
    .poll(async () => page.locator("label:has-text('Destino*') select option").count(), {
      timeout: 20_000,
    })
    .toBeGreaterThan(0);
}

export async function seleccionarFechaViaje(page: Page) {
  const input = page.locator("#cotizador-fecha-viaje-input");
  await input.click();
  const day = page.locator(
    ".p-datepicker-calendar td:not(.p-datepicker-other-month) span:not(.p-disabled)",
  );
  // Elegir un día habilitado hacia el final del mes visible (futuro)
  const count = await day.count();
  expect(count).toBeGreaterThan(0);
  await day.nth(Math.min(count - 1, 20)).click();
  await expect(input).not.toHaveValue("");
}

export async function cotizarBasico(page: Page, opts?: { viajeros?: string; destino?: string }) {
  await irACotizador(page);
  if (opts?.destino) {
    const destino = page.locator("label:has-text('Destino*') select");
    const option = destino.locator("option", {
      hasText: new RegExp(`^\\s*${opts.destino}\\s*$`, "i"),
    });
    if ((await option.count()) === 0) {
      // Fallback: primer país que coincida parcialmente (acentos/casing API)
      await destino.selectOption({ label: opts.destino });
    } else {
      const value = await option.first().getAttribute("value");
      await destino.selectOption(value!);
    }
  }
  await seleccionarFechaViaje(page);
  await page.locator('select[aria-label="Viajeros"]').selectOption(opts?.viajeros ?? "1");
  await page.getByRole("button", { name: /^Cotizar$/ }).click();
  await expect(page).toHaveURL(/\/planes/, { timeout: 20_000 });
}

export async function esperarPlanesCargados(page: Page) {
  await expect(page.getByText("Selecciona tu plan")).toBeVisible();
  await expect(page.getByTestId("loader-tarifas")).toBeHidden({ timeout: 120_000 });
}
