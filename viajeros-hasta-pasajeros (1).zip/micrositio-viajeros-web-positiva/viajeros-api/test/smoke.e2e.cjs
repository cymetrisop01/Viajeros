/**
 * Smoke e2e sobre el build compilado (dist/).
 * Ejecutar: npm run build && npm run test:e2e
 */
const request = require('supertest');
const {
  createNestApplication,
} = require('../dist/bootstrap/create-nest-application');
const { AppModule } = require('../dist/app.module');

async function main() {
  process.env.ALLOW_INTEGRATION_STUBS = 'true';
  const { app } = await createNestApplication({
    rootModule: AppModule,
    serviceName: 'Viajeros e2e',
  });

  try {
    const health = await request(app.getHttpServer()).get('/health');
    if (health.status !== 200 || health.body.ok !== true) {
      throw new Error(
        `Health falló: ${health.status} ${JSON.stringify(health.body)}`,
      );
    }

    const info = await request(app.getHttpServer()).get(
      '/api/viajeros/v1/system/info',
    );
    if (info.status !== 200 || info.body.name !== 'viajeros-api') {
      throw new Error(
        `System info falló: ${info.status} ${JSON.stringify(info.body)}`,
      );
    }

    const paises = await request(app.getHttpServer()).get(
      '/api/viajeros/v1/parametria/paises',
    );
    if (paises.status !== 200 || !Array.isArray(paises.body)) {
      throw new Error(
        `Paises falló: ${paises.status} ${JSON.stringify(paises.body)}`,
      );
    }

    const cotizadores = await request(app.getHttpServer()).get(
      '/api/viajeros/v1/cotizadores',
    );
    if (cotizadores.status !== 200 || !Array.isArray(cotizadores.body)) {
      throw new Error(
        `Cotizadores falló: ${cotizadores.status} ${JSON.stringify(cotizadores.body)}`,
      );
    }

    // eslint-disable-next-line no-console
    console.log(
      'e2e OK — /health, /system/info, /parametria/paises, /cotizadores',
    );
  } finally {
    await app.close();
  }
}

main().catch(error => {
  console.error(error);
  process.exit(1);
});
