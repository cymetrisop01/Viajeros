# viajeros-api

BFF NestJS del Micrositio Viajeros. Consulta el [README de la raíz](../README.md) para instalación, variables de entorno, pruebas y Docker.
