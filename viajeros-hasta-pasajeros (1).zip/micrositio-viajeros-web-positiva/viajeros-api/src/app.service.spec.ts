import { describe, expect, it } from 'vitest';
import { AppService } from './app.service';

describe('AppService', () => {
  it('returns health payload', () => {
    const service = new AppService();
    expect(service.getHealth()).toEqual({
      ok: true,
      service: 'viajeros-api',
    });
  });
});
