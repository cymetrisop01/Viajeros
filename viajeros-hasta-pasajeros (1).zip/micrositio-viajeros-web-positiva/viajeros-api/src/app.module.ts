import { Module } from '@nestjs/common';
import { AppController } from '@/app.controller';
import { AppService } from '@/app.service';
import { AppCoreModule } from '@/bootstrap/app-core.module';
import { BusModule } from '@/core/bus/bus.module';
import { CrmModule } from '@/core/crm/crm.module';
import { CotizadoresModule } from '@/modules/cotizadores/cotizadores.module';
import { ParametriaModule } from '@/modules/parametria/parametria.module';
import { SystemModule } from '@/modules/system/system.module';
import { TarifacionModule } from '@/modules/tarifacion/tarifacion.module';
import { ValidacionesModule } from '@/modules/validaciones/validaciones.module';

@Module({
  imports: [
    AppCoreModule,
    BusModule,
    CrmModule,
    SystemModule,
    CotizadoresModule,
    TarifacionModule,
    ValidacionesModule,
    ParametriaModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
