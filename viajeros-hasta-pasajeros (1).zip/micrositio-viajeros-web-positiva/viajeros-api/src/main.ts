import { listenNestApplication } from '@/bootstrap/create-nest-application';
import { AppModule } from '@/app.module';

void listenNestApplication({
  rootModule: AppModule,
  serviceName: 'Viajeros — BFF NestJS',
});
