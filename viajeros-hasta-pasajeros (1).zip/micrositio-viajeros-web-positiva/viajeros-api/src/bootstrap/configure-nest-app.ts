import { ValidationPipe, type INestApplication } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { json, urlencoded } from 'express';
import type { CreateNestApplicationOptions } from './create-nest-application';

const DEFAULT_API_PREFIX = 'api/viajeros/v1';

export async function configureNestApplication(
  app: INestApplication,
  options: CreateNestApplicationOptions,
): Promise<void> {
  const isProduction = process.env.NODE_ENV === 'production';
  const enableSwagger = process.env.ENABLE_SWAGGER === 'true' || !isProduction;
  const port = Number(process.env.PORT ?? 5000);
  const payloadLimit =
    options.payloadLimit ?? process.env.REQUEST_BODY_LIMIT ?? '1mb';
  const trustProxy = process.env.TRUST_PROXY === 'true';
  const serviceName = options.serviceName ?? 'Viajeros API';
  const apiPrefix = (process.env.API_PREFIX ?? DEFAULT_API_PREFIX).replace(
    /^\//,
    '',
  );

  const expressApp = app.getHttpAdapter().getInstance() as {
    disable: (name: string) => void;
    set: (name: string, value: unknown) => void;
  };
  expressApp.disable('x-powered-by');
  if (trustProxy) {
    expressApp.set('trust proxy', 1);
  }

  // `/health` queda fuera del prefijo para el health check de ALB/ECS.
  app.setGlobalPrefix(apiPrefix, {
    exclude: ['health'],
  });
  app.use(json({ limit: payloadLimit }));
  app.use(urlencoded({ extended: true, limit: payloadLimit }));
  app.use(
    helmet({
      contentSecurityPolicy: enableSwagger ? false : undefined,
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: { policy: 'cross-origin' },
    }),
  );
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      forbidUnknownValues: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  const localDevOrigins = [
    'http://localhost:5173',
    'http://localhost:5174',
    'http://127.0.0.1:5173',
    'http://127.0.0.1:5174',
    'http://localhost:8080',
    'http://127.0.0.1:8080',
  ];

  const frontendOrigins = (
    process.env.CORS_ORIGINS ??
    process.env.FRONTEND_URL ??
    ''
  )
    .split(',')
    .map(o => o.trim())
    .filter(Boolean);

  const allowedOrigins = [
    ...(!isProduction ? localDevOrigins : []),
    ...frontendOrigins,
  ].filter((o, i, all) => all.indexOf(o) === i);

  app.enableCors({
    origin: (
      requestOrigin: string | undefined,
      callback: (err: Error | null, allow?: boolean) => void,
    ) => {
      if (!requestOrigin) {
        callback(null, true);
        return;
      }
      if (allowedOrigins.includes(requestOrigin)) {
        callback(null, true);
        return;
      }
      callback(null, false);
    },
    credentials: allowedOrigins.length > 0,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key'],
  });

  if (!isProduction) {
    // eslint-disable-next-line no-console
    console.log(
      `CORS orígenes permitidos: ${allowedOrigins.join(', ') || '(ninguno)'}`,
    );
  }

  if (!isProduction || enableSwagger) {
    const devBase = `http://localhost:${port}`;
    const publicUrl = process.env.SWAGGER_SERVER_URL?.trim();

    const config = new DocumentBuilder()
      .setTitle(serviceName)
      .setDescription(
        'BFF NestJS del Micrositio Viajeros (Positiva Web). Orquestación hacia Bus/CRM (cotización, parametría y validación de identidad).',
      )
      .setVersion(process.env.APP_VERSION ?? '0.1.0')
      .addTag('Health', 'Comprobación de vida (ALB / ECS).')
      .addTag('System', 'Metadatos y diagnóstico de runtime.')
      .addTag('Cotizadores', 'WS-VIAJ-001 / WS-VIAJ-002 — cotización.')
      .addTag('Tarificacion', 'WS-VIAJ-003 — planes PRO / PLUS.')
      .addTag('Validaciones', 'Identidad (Bus) y SARLAFT.')
      .addTag('Parametria', 'WS-VIAJ-007 — países y catálogos.')
      .addServer(`${devBase}/${apiPrefix}`, 'Local')
      .addServer(
        publicUrl
          ? `${publicUrl.replace(/\/$/, '')}/${apiPrefix}`
          : `https://portalpruebas.positivaenlinea.gov.co/${apiPrefix}`,
        publicUrl ? 'Entorno (SWAGGER_SERVER_URL)' : 'DEV3 (placeholder)',
      )
      .build();

    const document = SwaggerModule.createDocument(app, config, {
      ignoreGlobalPrefix: true,
    });
    SwaggerModule.setup('docs', app, document, {
      customSiteTitle: `${serviceName} — Swagger`,
      jsonDocumentUrl: 'json',
      useGlobalPrefix: false,
    });
  }

  await app.init();
}
