import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

/** Config global compartida por todos los módulos del BFF Viajeros. */
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
  ],
  exports: [ConfigModule],
})
export class AppCoreModule {}
