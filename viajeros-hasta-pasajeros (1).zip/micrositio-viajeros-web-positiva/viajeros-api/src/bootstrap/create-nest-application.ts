import { type Type } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { configureNestApplication } from './configure-nest-app';

export type CreateNestApplicationOptions = {
  rootModule: Type<unknown>;
  serviceName?: string;
  payloadLimit?: string;
};

export async function createNestApplication(
  options: CreateNestApplicationOptions,
) {
  const app = await NestFactory.create(options.rootModule);
  const port = Number(process.env.PORT ?? 5000);
  const serviceName = options.serviceName ?? 'Viajeros API';
  await configureNestApplication(app, options);
  return { app, port, serviceName };
}

export async function listenNestApplication(
  options: CreateNestApplicationOptions,
): Promise<void> {
  const { app, port, serviceName } = await createNestApplication(options);
  await app.listen(port, '0.0.0.0');

  const isProduction = process.env.NODE_ENV === 'production';
  const enableSwagger = process.env.ENABLE_SWAGGER === 'true' || !isProduction;
  const apiPrefix = (process.env.API_PREFIX ?? 'api/viajeros/v1').replace(
    /^\//,
    '',
  );

  if (!isProduction) {
    // eslint-disable-next-line no-console
    console.log(`${serviceName} → http://localhost:${port}/${apiPrefix}`);
    // eslint-disable-next-line no-console
    console.log(`Health → http://localhost:${port}/health`);
    if (enableSwagger) {
      // eslint-disable-next-line no-console
      console.log(`Swagger → http://localhost:${port}/docs`);
    }
  }
}
