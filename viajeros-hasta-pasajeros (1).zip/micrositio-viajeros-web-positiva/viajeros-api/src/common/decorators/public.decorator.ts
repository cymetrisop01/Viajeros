import { SetMetadata } from '@nestjs/common';

/** Rutas sin autenticación cuando se active un guard global. */
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
