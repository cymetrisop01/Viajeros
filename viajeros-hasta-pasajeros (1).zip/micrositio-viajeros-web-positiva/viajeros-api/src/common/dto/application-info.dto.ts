import { ApiProperty } from '@nestjs/swagger';

export class ApplicationInfoDto {
  @ApiProperty({ example: 'viajeros-api' })
  name!: string;

  @ApiProperty({ example: '0.1.0' })
  version!: string;

  @ApiProperty({
    example: 'BFF NestJS Micrositio Viajeros Positiva Web.',
  })
  description!: string;
}
