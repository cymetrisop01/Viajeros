import { ApiProperty } from '@nestjs/swagger';

/** Respuesta de comprobación de vida (`GET /health`). */
export class HealthResponseDto {
  @ApiProperty({ example: true })
  ok!: boolean;

  @ApiProperty({ example: 'viajeros-api' })
  service!: string;
}
