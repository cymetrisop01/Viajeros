import { describe, expect, it } from 'vitest';
import { redactForLog, summarizeBody } from './log-upstream';

describe('log-upstream', () => {
  it('trunca cuerpos largos', () => {
    expect(summarizeBody('abc', 10)).toBe('abc');
    expect(summarizeBody('abcdefghijXXX', 10)).toBe('abcdefghij…(+3 chars)');
  });

  it('oculta secretos y JWT', () => {
    const redacted = redactForLog({
      username: 'demo',
      password: 'secret',
      token: 'abc',
      nested: { access_token: 'xyz' },
      jwt: 'aaa.bbb.ccc',
    }) as Record<string, unknown>;
    expect(redacted.username).toBe('demo');
    expect(redacted.password).toBe('[redacted]');
    expect(redacted.token).toBe('[redacted]');
    expect((redacted.nested as Record<string, unknown>).access_token).toBe(
      '[redacted]',
    );
  });
});
