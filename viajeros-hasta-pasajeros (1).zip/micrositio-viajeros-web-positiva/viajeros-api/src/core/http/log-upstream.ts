import { Logger } from '@nestjs/common';

const ERROR_BODY_MAX = 2500;
const SUCCESS_BODY_MAX = 800;
const SENSITIVE_KEY = /password|secret|token|authorization|bearer|jwt/i;

export type UpstreamCallMeta = {
  sistema: string;
  method: string;
  url: string;
  timeoutMs: number;
  startedAt: number;
  requestBody?: unknown;
};

export function summarizeBody(text: string, max: number): string {
  const compact = text.replace(/\s+/g, ' ').trim();
  if (!compact) return '(vacío)';
  if (compact.length <= max) return compact;
  return `${compact.slice(0, max)}…(+${compact.length - max} chars)`;
}

export function redactForLog(value: unknown): unknown {
  if (value == null) return value;
  if (typeof value === 'string') {
    if (value.length > 40 && /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\./.test(value)) {
      return '[redacted-jwt]';
    }
    return value;
  }
  if (Array.isArray(value)) return value.map(redactForLog);
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SENSITIVE_KEY.test(k) ? '[redacted]' : redactForLog(v);
    }
    return out;
  }
  return value;
}

export function causeMessage(cause: unknown): string {
  if (cause instanceof Error) {
    const name = cause.name || 'Error';
    return `${name}: ${cause.message}`;
  }
  return String(cause);
}

export function shouldLogSuccessBody(): boolean {
  const explicit = process.env.INTEGRATION_LOG_SUCCESS_BODY?.trim();
  if (explicit === 'true') return true;
  if (explicit === 'false') return false;
  const level = (process.env.LOG_LEVEL ?? '').toLowerCase();
  return level === 'debug' || level === 'verbose';
}

function elapsed(meta: UpstreamCallMeta): number {
  return Date.now() - meta.startedAt;
}

function requestPreview(meta: UpstreamCallMeta): string {
  if (meta.requestBody === undefined) return '';
  try {
    return ` request=${summarizeBody(JSON.stringify(redactForLog(meta.requestBody)), 600)}`;
  } catch {
    return '';
  }
}

/** Falla de red, timeout o HTTP no OK. Visible con LOG_LEVEL=info/error (producción). */
export function logUpstreamFailure(
  log: Logger,
  meta: UpstreamCallMeta,
  opts: { status?: number; body?: string; cause?: unknown },
): void {
  const status = opts.status != null ? String(opts.status) : 'NET';
  const cause = opts.cause ? ` cause=${causeMessage(opts.cause)}` : '';
  const body =
    opts.body != null
      ? ` body=${summarizeBody(opts.body, ERROR_BODY_MAX)}`
      : '';
  log.error(
    `[${meta.sistema}] ${meta.method} ${meta.url} status=${status} ${elapsed(meta)}ms timeout=${meta.timeoutMs}ms${cause}${requestPreview(meta)}${body}`,
  );
}

/** Éxito HTTP: siempre status/tiempo; el cuerpo solo con LOG_LEVEL=debug o INTEGRATION_LOG_SUCCESS_BODY=true. */
export function logUpstreamSuccess(
  log: Logger,
  meta: UpstreamCallMeta,
  opts: { status: number; body?: string },
): void {
  const bytes = opts.body?.length ?? 0;
  const preview = shouldLogSuccessBody()
    ? ` body=${summarizeBody(opts.body ?? '', SUCCESS_BODY_MAX)}`
    : '';
  log.log(
    `[${meta.sistema}] ${meta.method} ${meta.url} status=${opts.status} ${elapsed(meta)}ms bytes=${bytes}${preview}`,
  );
}
