import {
  BadGatewayException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  logUpstreamFailure,
  logUpstreamSuccess,
} from '@/core/http/log-upstream';

const DEFAULT_TOKEN_URL =
  'https://keycloak-sso-app.apps.openshift4.positiva.gov.co/auth/realms/apis-pre/protocol/openid-connect/token';
const TOKEN_SKEW_MS = 30_000;
const DEFAULT_TIMEOUT_MS = 15_000;

/**
 * Token OAuth2 (client_credentials) Keycloak / 3Scale para BUS y CRM.
 *
 * Env (prioridad):
 * - `BUS_API_BEARER_TOKEN` o `IDENTIDAD_API_BEARER_TOKEN`
 * - o `BUS_CLIENT_ID`/`BUS_CLIENT_SECRET` (alias `IDENTIDAD_CLIENT_ID`/`SECRET`)
 * - `BUS_TOKEN_URL` (alias `IDENTIDAD_TOKEN_URL`)
 */
@Injectable()
export class BusAuthTokenProvider {
  private readonly log = new Logger(BusAuthTokenProvider.name);
  private tokenCache: { token: string; expiresAt: number } | null = null;

  constructor(private readonly config: ConfigService) {}

  isConfigured(): boolean {
    return Boolean(this.resolveStaticToken() || this.resolveOauthPair());
  }

  async getAccessToken(): Promise<string> {
    const staticToken = this.resolveStaticToken();
    if (staticToken) return staticToken;

    const now = Date.now();
    if (this.tokenCache && this.tokenCache.expiresAt > now + TOKEN_SKEW_MS) {
      return this.tokenCache.token;
    }

    const oauth = this.resolveOauthPair();
    if (!oauth) {
      throw new ServiceUnavailableException({
        status: 503,
        title: 'Service Unavailable',
        detail:
          'BUS/CRM sin token: configure BUS_API_BEARER_TOKEN o BUS_CLIENT_ID/SECRET.',
      });
    }

    const tokenUrl =
      this.config.get<string>('BUS_TOKEN_URL')?.trim() ||
      this.config.get<string>('IDENTIDAD_TOKEN_URL')?.trim() ||
      DEFAULT_TOKEN_URL;
    const timeoutMs =
      Number(this.config.get<string>('HTTP_TIMEOUT_MS')) ||
      Number(this.config.get<string>('BUS_TIMEOUT_MS')) ||
      DEFAULT_TIMEOUT_MS;

    const body = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: oauth.clientId,
      client_secret: oauth.clientSecret,
    });

    const meta = {
      sistema: 'Keycloak',
      method: 'POST',
      url: tokenUrl,
      timeoutMs,
      startedAt: Date.now(),
      requestBody: {
        grant_type: 'client_credentials',
        client_id: oauth.clientId,
      },
    };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res: Response;
    try {
      res = await fetch(tokenUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: controller.signal,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logUpstreamFailure(this.log, meta, { cause: e });
      throw new ServiceUnavailableException({
        status: 503,
        title: 'Service Unavailable',
        detail: `No se pudo obtener token Keycloak: ${msg}`,
      });
    } finally {
      clearTimeout(timer);
    }

    const detail = await res.text().catch(() => '');
    if (!res.ok) {
      logUpstreamFailure(this.log, meta, { status: res.status, body: detail });
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: `Keycloak respondió ${res.status}.`,
      });
    }
    logUpstreamSuccess(this.log, meta, { status: res.status, body: detail });

    let data: { access_token?: string; expires_in?: number } = {};
    try {
      data = (detail ? JSON.parse(detail) : {}) as {
        access_token?: string;
        expires_in?: number;
      };
    } catch (e) {
      logUpstreamFailure(this.log, meta, {
        status: res.status,
        body: detail,
        cause: e,
      });
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: 'Keycloak no devolvió JSON válido.',
      });
    }
    const token = data.access_token?.trim();
    if (!token) {
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: 'Keycloak no devolvió access_token.',
      });
    }
    const expiresInMs = Math.max(60, Number(data.expires_in) || 300) * 1000;
    this.tokenCache = { token, expiresAt: Date.now() + expiresInMs };
    return token;
  }

  invalidate(): void {
    this.tokenCache = null;
  }

  private resolveStaticToken(): string | undefined {
    return (
      this.config.get<string>('BUS_API_BEARER_TOKEN')?.trim() ||
      this.config.get<string>('IDENTIDAD_API_BEARER_TOKEN')?.trim() ||
      undefined
    );
  }

  private resolveOauthPair():
    { clientId: string; clientSecret: string } | undefined {
    const clientId =
      this.config.get<string>('BUS_CLIENT_ID')?.trim() ||
      this.config.get<string>('IDENTIDAD_CLIENT_ID')?.trim();
    const clientSecret =
      this.config.get<string>('BUS_CLIENT_SECRET')?.trim() ||
      this.config.get<string>('IDENTIDAD_CLIENT_SECRET')?.trim();
    if (clientId && clientSecret) {
      return { clientId, clientSecret };
    }
    return undefined;
  }
}
