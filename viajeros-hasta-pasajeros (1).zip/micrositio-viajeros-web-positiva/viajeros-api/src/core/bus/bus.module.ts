import { Global, Module } from '@nestjs/common';
import { BusAuthTokenProvider } from './bus-auth-token';

@Global()
@Module({
  providers: [BusAuthTokenProvider],
  exports: [BusAuthTokenProvider],
})
export class BusModule {}
