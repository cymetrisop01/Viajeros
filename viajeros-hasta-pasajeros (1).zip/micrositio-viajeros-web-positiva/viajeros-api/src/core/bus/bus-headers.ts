import { randomBytes } from 'crypto';
import { ConfigService } from '@nestjs/config';

/** Cabeceras SCP / 3Scale usadas por paramétricas y CRM. */
export function buildScpHeaders(
  config: ConfigService,
  bearerToken: string,
): Record<string, string> {
  return {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    Authorization: `Bearer ${bearerToken}`,
    originator: config.get<string>('BUS_ORIGINATOR')?.trim() || 'syc',
    sender: config.get<string>('BUS_SENDER')?.trim() || 'App',
    messageId:
      config.get<string>('BUS_MESSAGE_ID')?.trim() ||
      randomBytes(16).toString('base64url'),
  };
}

export const DEFAULT_API_BASE =
  'https://core-positiva-apis-pre-apicast-staging.apps.openshift4.positiva.gov.co';

export const DEFAULT_CRM_BASE = `${DEFAULT_API_BASE}/crm`;
/** CRM calculoPrima en PRE suele superar 20 s; default 60 s. */
export const DEFAULT_TIMEOUT_MS = 60_000;

export function httpTimeoutMs(config: ConfigService): number {
  return (
    Number(config.get<string>('HTTP_TIMEOUT_MS')) ||
    Number(config.get<string>('BUS_TIMEOUT_MS')) ||
    DEFAULT_TIMEOUT_MS
  );
}

/** Producto Viajeros 2026 (guía técnica). */
export const VIAJERO_QUOTE_GENERATOR_ID = 1255;

export const VIAJERO_PLANES = {
  PLUS_NACIONAL: 1454,
  PLUS_INTERNACIONAL: 1453,
  PRO_NACIONAL: 1456,
  PRO_INTERNACIONAL: 1455,
} as const;

/** Campo CRM «N° Viajeros» (cotizador 1255). */
export const VIAJERO_FIELD_VIAJEROS = 1651;

/** IDs Plus/Pro según modalidad del viaje. */
export function planIdsPorModalidad(esNacional: boolean): {
  plus: number;
  pro: number;
} {
  return esNacional
    ? {
        plus: VIAJERO_PLANES.PLUS_NACIONAL,
        pro: VIAJERO_PLANES.PRO_NACIONAL,
      }
    : {
        plus: VIAJERO_PLANES.PLUS_INTERNACIONAL,
        pro: VIAJERO_PLANES.PRO_INTERNACIONAL,
      };
}
