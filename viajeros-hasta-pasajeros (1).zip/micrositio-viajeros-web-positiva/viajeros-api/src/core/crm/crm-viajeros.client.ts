import {
  BadGatewayException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BusAuthTokenProvider } from '@/core/bus/bus-auth-token';
import {
  buildScpHeaders,
  DEFAULT_CRM_BASE,
  httpTimeoutMs,
  VIAJERO_QUOTE_GENERATOR_ID,
} from '@/core/bus/bus-headers';
import {
  logUpstreamFailure,
  logUpstreamSuccess,
} from '@/core/http/log-upstream';

export type CotizadorCrmItem = {
  id: number | string;
  nombre: string;
  planes?: Array<{ id: number | string; nombre: string }>;
  raw?: unknown;
};

export type CampoCotizadorCrm = {
  id: number | string;
  nombre?: string;
  tipo?: string;
  obligatorio?: boolean;
  raw?: unknown;
};

export type CalculoPrimaRequest = {
  quoteGeneratorId?: number;
  planId: number;
  codeDaneDepartment?: string;
  codeDaneCity?: string;
  effectiveStartDate: string;
  effectiveEndDate: string;
  fieldLines: Array<{ id: number; value: string }>;
  billingPeriod?: string;
  modalityInsurance?: string;
  paymentMethod?: string;
};

export type CalculoPrimaResultado = {
  quoterHeaderId: string;
  plan?: string;
  prima?: number;
  message?: string;
  fuente: string;
  raw?: unknown;
};

export type VinculacionSeguro = {
  type_document: string;
  vat: string;
  first_name: string;
  second_name?: string;
  last_name: string;
  second_last_name?: string;
  email: string;
  mobile: string;
  birthdate: string;
  CodeEconomicActivity?: string;
  gender?: string;
  auth_data?: boolean;
  date_auth_data?: string;
  address: string;
  role?: string;
  family_group?: unknown[];
};

export type VinculacionRequest = {
  quote_id: string;
  insurances: VinculacionSeguro[];
};

export type VinculacionResultado = {
  quoterHeaderId?: string;
  plan?: string;
  prima?: number;
  paymentLink?: string;
  message?: string;
  fuente: string;
  raw?: unknown;
};

@Injectable()
export class CrmViajerosClient {
  private readonly log = new Logger(CrmViajerosClient.name);

  constructor(
    private readonly config: ConfigService,
    private readonly auth: BusAuthTokenProvider,
  ) {}

  isEnabled(): boolean {
    return this.auth.isConfigured();
  }

  private baseUrl(): string {
    return (
      this.config.get<string>('CRM_API_BASE_URL')?.trim() || DEFAULT_CRM_BASE
    ).replace(/\/$/, '');
  }

  private timeoutMs(): number {
    return (
      Number(this.config.get<string>('CRM_TIMEOUT_MS')) ||
      httpTimeoutMs(this.config)
    );
  }

  private async request(
    method: 'GET' | 'POST',
    path: string,
    body?: unknown,
  ): Promise<unknown> {
    const url = `${this.baseUrl()}${path}`;
    const token = await this.auth.getAccessToken();
    const timeoutMs = this.timeoutMs();
    const meta = {
      sistema: 'CRM',
      method,
      url,
      timeoutMs,
      startedAt: Date.now(),
      requestBody: body,
    };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res: Response;
    try {
      res = await fetch(url, {
        method,
        headers: buildScpHeaders(this.config, token),
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logUpstreamFailure(this.log, meta, { cause: e });
      throw new ServiceUnavailableException({
        status: 503,
        title: 'Service Unavailable',
        detail: `No se pudo contactar CRM: ${msg}`,
      });
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text().catch(() => '');
    if (!res.ok) {
      logUpstreamFailure(this.log, meta, { status: res.status, body: text });
      if (res.status === 401 || res.status === 403) this.auth.invalidate();
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: `CRM respondió ${res.status}.`,
      });
    }
    logUpstreamSuccess(this.log, meta, { status: res.status, body: text });

    try {
      return text ? JSON.parse(text) : {};
    } catch {
      return { raw: text };
    }
  }

  async listarCotizadores(): Promise<CotizadorCrmItem[]> {
    const parsed = await this.request(
      'GET',
      '/v1/positiva/crm/listarCotizadores',
    );
    const rows = extractArray(parsed);
    return rows.map(row => {
      const r = row as Record<string, unknown>;
      return {
        id: (r.id ?? r.quote_generator_id ?? r.codigo) as number | string,
        nombre: String(
          r.nombre ?? r.name ?? r.descripcion ?? r.producto ?? 'Cotizador',
        ),
        planes: Array.isArray(r.planes)
          ? (r.planes as Array<Record<string, unknown>>).map(p => ({
              id: (p.id ?? p.plan_id) as number | string,
              nombre: String(p.nombre ?? p.name ?? p.plan ?? ''),
            }))
          : undefined,
        raw: row,
      };
    });
  }

  async mostrarCamposCotizadores(
    codigo: number | string = VIAJERO_QUOTE_GENERATOR_ID,
  ): Promise<CampoCotizadorCrm[]> {
    const parsed = await this.request(
      'GET',
      `/v1/positiva/crm/mostrarCamposCotizadores?codigo=${encodeURIComponent(String(codigo))}`,
    );
    const rows = extractArray(parsed);
    return rows.map(row => {
      const r = row as Record<string, unknown>;
      return {
        id: (r.id ?? r.field_id ?? r.codigo) as number | string,
        nombre: r.nombre ? String(r.nombre) : undefined,
        tipo: r.tipo ? String(r.tipo) : undefined,
        obligatorio: Boolean(r.obligatorio ?? r.required),
        raw: row,
      };
    });
  }

  async calculoPrima(
    request: CalculoPrimaRequest,
  ): Promise<CalculoPrimaResultado> {
    const payload = {
      info: {
        quote_generator_id:
          request.quoteGeneratorId ?? VIAJERO_QUOTE_GENERATOR_ID,
        codeDaneDepartment: request.codeDaneDepartment ?? '11',
        codeDaneCity: request.codeDaneCity ?? '11001',
        plan_id: request.planId,
        BillingPeriod: request.billingPeriod ?? 'DIARIO',
        effective_start_date: request.effectiveStartDate,
        effective_end_date: request.effectiveEndDate,
        modality_insurance: request.modalityInsurance ?? 'no_contributory',
        allow_multiple_plans: false,
        payment_method: request.paymentMethod ?? 'PAGOS EN LÍNEA',
        field_lines: request.fieldLines,
      },
    };

    const parsed = await this.request(
      'POST',
      '/v1/positiva/crm/calculoPrima',
      payload,
    );
    const message = unwrapMessage(parsed);
    return {
      quoterHeaderId: String(
        message.quoter_header_id ?? message.quote_id ?? '',
      ),
      plan: message.plan ? String(message.plan) : undefined,
      prima:
        message.prima != null && message.prima !== ''
          ? Number(message.prima)
          : undefined,
      message: message.message ? String(message.message) : undefined,
      fuente: 'crm',
      raw: parsed,
    };
  }

  async conocimientoCliente(
    request: VinculacionRequest,
  ): Promise<VinculacionResultado> {
    const payload = sanitizeVinculacionRequest(request);
    const parsed = await this.request(
      'POST',
      '/v1/positiva/crm/conocimientoClienteCotizador',
      payload,
    );
    const message = unwrapMessage(parsed);
    const statusCode = crmStatusCode(parsed);
    const resultado: VinculacionResultado = {
      quoterHeaderId: message.quoter_header_id
        ? String(message.quoter_header_id)
        : undefined,
      plan: message.plan ? String(message.plan) : undefined,
      prima:
        message.prima != null && message.prima !== ''
          ? Number(message.prima)
          : undefined,
      paymentLink: message.payment_link
        ? String(message.payment_link)
        : undefined,
      message: message.message ? String(message.message) : undefined,
      fuente: 'crm',
      raw: parsed,
    };
    if (statusCode != null && statusCode >= 400) {
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail:
          resultado.message ||
          `CRM conocimientoCliente status_code=${statusCode}.`,
        quoterHeaderId: resultado.quoterHeaderId,
        paymentLink: resultado.paymentLink,
      });
    }
    return resultado;
  }
}

const SWAGGER_PLACEHOLDERS = new Set([
  'string',
  'date',
  'integer',
  'number',
  'boolean',
  'datetime',
]);

export function toIsoDateOrUndefined(raw?: string): string | undefined {
  const s = (raw ?? '').trim();
  if (!s || SWAGGER_PLACEHOLDERS.has(s.toLowerCase())) return undefined;
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const dmy = s.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`;
  return s;
}

const DEFAULT_ADDRESS = 'Cra 7 # 1-01';

export function sanitizeVinculacionRequest(
  request: VinculacionRequest,
): VinculacionRequest {
  return {
    quote_id: request.quote_id,
    insurances: request.insurances.map(ins => {
      const next: VinculacionSeguro = { ...ins };
      for (const key of Object.keys(next) as Array<keyof VinculacionSeguro>) {
        const v = next[key];
        if (
          typeof v === 'string' &&
          SWAGGER_PLACEHOLDERS.has(v.trim().toLowerCase())
        ) {
          delete next[key];
        }
      }
      const birthdate = toIsoDateOrUndefined(next.birthdate) ?? next.birthdate;
      const dateAuth = toIsoDateOrUndefined(next.date_auth_data);
      next.birthdate = birthdate;
      if (dateAuth) next.date_auth_data = dateAuth;
      else delete next.date_auth_data;
      if (next.auth_data && !next.date_auth_data) {
        next.date_auth_data = new Date().toISOString().slice(0, 10);
      }
      const address = (next.address ?? '').trim();
      next.address = address || DEFAULT_ADDRESS;
      return next;
    }),
  };
}

export function crmStatusCode(parsed: unknown): number | undefined {
  if (!parsed || typeof parsed !== 'object') return undefined;
  const result = (parsed as Record<string, unknown>).result;
  if (result && typeof result === 'object' && 'status_code' in result) {
    const n = Number((result as Record<string, unknown>).status_code);
    return Number.isFinite(n) ? n : undefined;
  }
  return undefined;
}

function extractArray(parsed: unknown): unknown[] {
  if (Array.isArray(parsed)) return parsed;
  if (parsed && typeof parsed === 'object') {
    const o = parsed as Record<string, unknown>;
    for (const key of ['data', 'result', 'message', 'items', 'cotizadores']) {
      const v = o[key];
      if (Array.isArray(v)) return v;
      if (v && typeof v === 'object') {
        const nested = v as Record<string, unknown>;
        for (const nk of ['data', 'items', 'message']) {
          if (Array.isArray(nested[nk])) return nested[nk] as unknown[];
        }
      }
    }
  }
  return [];
}

function unwrapMessage(parsed: unknown): Record<string, unknown> {
  if (!parsed || typeof parsed !== 'object') return {};
  const o = parsed as Record<string, unknown>;
  if (o.result && typeof o.result === 'object') {
    const result = o.result as Record<string, unknown>;
    if (result.message && typeof result.message === 'object') {
      return result.message as Record<string, unknown>;
    }
    return result;
  }
  if (o.message && typeof o.message === 'object') {
    return o.message as Record<string, unknown>;
  }
  return o;
}
