import { Global, Module } from '@nestjs/common';
import { BusModule } from '@/core/bus/bus.module';
import { CrmViajerosClient } from './crm-viajeros.client';

@Global()
@Module({
  imports: [BusModule],
  providers: [CrmViajerosClient],
  exports: [CrmViajerosClient],
})
export class CrmModule {}
