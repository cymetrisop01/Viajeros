import { describe, expect, it } from 'vitest';
import {
  crmStatusCode,
  sanitizeVinculacionRequest,
  toIsoDateOrUndefined,
} from './crm-viajeros.client';

describe('toIsoDateOrUndefined', () => {
  it('descarta el placeholder de Swagger', () => {
    expect(toIsoDateOrUndefined('string')).toBeUndefined();
  });

  it('acepta ISO y dd/MM/yyyy', () => {
    expect(toIsoDateOrUndefined('1985-08-30')).toBe('1985-08-30');
    expect(toIsoDateOrUndefined('30/08/1985')).toBe('1985-08-30');
  });
});

describe('sanitizeVinculacionRequest', () => {
  it('quita date_auth_data=string y rellena si hay auth_data', () => {
    const out = sanitizeVinculacionRequest({
      quote_id: 'COT000497',
      insurances: [
        {
          type_document: 'CC',
          vat: '1083022490',
          first_name: 'ANA',
          last_name: 'PEREZ',
          email: 'viajero@correo.com',
          mobile: '3002858967',
          birthdate: '1985-08-30',
          auth_data: true,
          date_auth_data: 'string',
          address: 'string',
        },
      ],
    });
    expect(out.insurances[0].address).toBe('Cra 7 # 1-01');
    expect(out.insurances[0].date_auth_data).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(out.insurances[0].date_auth_data).not.toBe('string');
  });
});

describe('crmStatusCode', () => {
  it('lee jsonrpc result.status_code', () => {
    expect(crmStatusCode({ result: { status_code: 500, message: {} } })).toBe(
      500,
    );
  });
});
