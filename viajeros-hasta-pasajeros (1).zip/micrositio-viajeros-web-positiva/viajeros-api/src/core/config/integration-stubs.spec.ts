import { describe, expect, it } from 'vitest';
import { areIntegrationStubsAllowed } from './integration-stubs';

describe('areIntegrationStubsAllowed', () => {
  it('honors explicit true', () => {
    expect(
      areIntegrationStubsAllowed(key =>
        key === 'ALLOW_INTEGRATION_STUBS' ? 'true' : undefined,
      ),
    ).toBe(true);
  });

  it('disables stubs in prod/dev3 by default', () => {
    expect(
      areIntegrationStubsAllowed(key =>
        key === 'APP_ENV' ? 'dev3' : undefined,
      ),
    ).toBe(false);
  });

  it('allows stubs locally', () => {
    expect(areIntegrationStubsAllowed(() => undefined)).toBe(true);
  });
});
