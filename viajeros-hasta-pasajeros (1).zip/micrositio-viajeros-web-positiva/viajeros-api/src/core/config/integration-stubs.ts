export type ConfigGetter = (
  key: string,
  defaultValue?: string,
) => string | undefined;

/**
 * Decide si se permiten adaptadores stub para integraciones externas.
 *
 * 1. ALLOW_INTEGRATION_STUBS=true|false — override explícito
 * 2. APP_ENV=dev3|production → false por defecto
 * 3. Local / tests → true
 */
export function areIntegrationStubsAllowed(get: ConfigGetter): boolean {
  const explicit = get('ALLOW_INTEGRATION_STUBS')?.trim().toLowerCase();
  if (explicit === 'true' || explicit === '1') {
    return true;
  }
  if (explicit === 'false' || explicit === '0') {
    return false;
  }

  const appEnv = (get('APP_ENV') ?? get('NODE_ENV') ?? '').trim().toLowerCase();
  if (appEnv === 'dev3' || appEnv === 'production' || appEnv === 'prod') {
    return false;
  }

  return true;
}
