export type FieldLine = { id: number; value: string };

export type TarifaRequest = {
  planId: number;
  effectiveStartDate: string;
  effectiveEndDate: string;
  fieldLines: FieldLine[];
  quoteGeneratorId?: number;
  codeDaneDepartment?: string;
  codeDaneCity?: string;
};

export type TarifaResultado = {
  quoterHeaderId: string;
  plan?: string;
  prima?: number;
  message?: string;
  fuente: string;
};

export abstract class TarifacionPort {
  abstract tarifar(request: TarifaRequest): Promise<TarifaResultado>;
}
