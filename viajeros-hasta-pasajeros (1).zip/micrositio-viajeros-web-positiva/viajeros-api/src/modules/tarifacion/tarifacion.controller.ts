import { Body, Controller, HttpCode, HttpStatus, Post } from '@nestjs/common';
import { ApiBody, ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Public } from '@/common/decorators/public.decorator';
import { TarifacionService } from './application/tarifacion.service';
import { TarifarDto, TarifarPlanesDto } from './dto/tarifacion.dto';

@ApiTags('Tarificacion')
@Controller('tarifacion')
export class TarifacionController {
  constructor(private readonly service: TarifacionService) {}

  @Public()
  @Post('calculo-prima')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Cálculo de prima CRM (un plan)',
    description:
      'POST /v1/positiva/crm/calculoPrima — BillingPeriod siempre DIARIO. Retorna quoter_header_id y prima.',
  })
  @ApiBody({ type: TarifarDto })
  @ApiOkResponse({ description: 'Cotización creada' })
  tarifar(@Body() dto: TarifarDto) {
    return this.service.tarifar(dto);
  }

  @Public()
  @Post('calculo-prima-planes')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Cálculo Plus + Pro según modalidad',
    description:
      'Hace dos llamados a CRM calculoPrima: Plus y Pro. ' +
      'Nacional (CO→CO): plan_id 1454 y 1456. Internacional: 1453 y 1455.',
  })
  @ApiBody({ type: TarifarPlanesDto })
  @ApiOkResponse({ description: 'Primas Plus y Pro' })
  tarifarPlanes(@Body() dto: TarifarPlanesDto) {
    return this.service.tarifarPlanes(dto);
  }
}
