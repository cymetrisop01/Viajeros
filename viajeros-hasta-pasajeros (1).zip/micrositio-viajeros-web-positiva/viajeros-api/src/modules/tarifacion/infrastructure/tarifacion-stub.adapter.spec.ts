import { describe, expect, it } from 'vitest';
import { TarifacionStubAdapter } from './tarifacion-stub.adapter';

describe('TarifacionStubAdapter', () => {
  it('returns quoter header and prima', async () => {
    const adapter = new TarifacionStubAdapter();
    const result = await adapter.tarifar({
      planId: 1454,
      effectiveStartDate: '2026-11-01',
      effectiveEndDate: '2026-11-10',
      fieldLines: [{ id: 1651, value: '1' }],
    });
    expect(result.fuente).toBe('stub');
    expect(result.quoterHeaderId).toMatch(/^COT-/);
    expect(result.prima).toBeGreaterThan(0);
  });
});
