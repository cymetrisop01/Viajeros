import { Injectable } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { VIAJERO_PLANES } from '@/core/bus/bus-headers';
import {
  TarifaRequest,
  TarifaResultado,
  TarifacionPort,
} from '../domain/ports/tarifacion.port';

/** Primas de referencia locales cuando CRM PRE no responde. */
const PRIMAS: Record<number, { plan: string; prima: number }> = {
  [VIAJERO_PLANES.PLUS_INTERNACIONAL]: {
    plan: 'VIAJERO PLUS INTERNACIONAL (stub)',
    prima: 675_392,
  },
  [VIAJERO_PLANES.PLUS_NACIONAL]: {
    plan: 'VIAJERO PLUS NACIONAL (stub)',
    prima: 189_500,
  },
  [VIAJERO_PLANES.PRO_INTERNACIONAL]: {
    plan: 'VIAJERO PRO INTERNACIONAL (stub)',
    prima: 283_459,
  },
  [VIAJERO_PLANES.PRO_NACIONAL]: {
    plan: 'VIAJERO PRO NACIONAL (stub)',
    prima: 98_200,
  },
};

@Injectable()
export class TarifacionStubAdapter extends TarifacionPort {
  async tarifar(request: TarifaRequest): Promise<TarifaResultado> {
    const meta = PRIMAS[request.planId] ?? {
      plan: `PLAN ${request.planId} (stub)`,
      prima: 150_000,
    };
    return {
      quoterHeaderId: `COT-${randomUUID().slice(0, 8).toUpperCase()}`,
      plan: meta.plan,
      prima: meta.prima,
      message: 'Cotización creada (stub — CRM no disponible)',
      fuente: 'stub',
    };
  }
}
