import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { areIntegrationStubsAllowed } from '@/core/config/integration-stubs';
import { CrmViajerosClient } from '@/core/crm/crm-viajeros.client';
import {
  TarifaRequest,
  TarifaResultado,
  TarifacionPort,
} from '../domain/ports/tarifacion.port';
import { TarifacionStubAdapter } from './tarifacion-stub.adapter';

/** Tras un fallo CRM, reutilizar stub un rato (evita 2×30s en batch Plus/Pro). */
const CIRCUIT_COOLDOWN_MS = 120_000;

@Injectable()
export class TarifacionHybridAdapter extends TarifacionPort {
  private readonly log = new Logger(TarifacionHybridAdapter.name);
  private circuitOpenUntil = 0;

  constructor(
    private readonly config: ConfigService,
    private readonly stub: TarifacionStubAdapter,
    private readonly crm: CrmViajerosClient,
  ) {
    super();
  }

  private get(key: string, def?: string) {
    return this.config.get<string>(key) ?? def;
  }

  /** Si CRM PRE falla (504/timeout), permite stub local sin apagar CRM. */
  private crmFallbackStub(): boolean {
    const v = this.get('CRM_FALLBACK_STUB')?.trim().toLowerCase();
    return v === 'true' || v === '1';
  }

  async tarifar(request: TarifaRequest): Promise<TarifaResultado> {
    if (
      areIntegrationStubsAllowed(this.get.bind(this)) ||
      !this.crm.isEnabled()
    ) {
      return this.stub.tarifar(request);
    }

    if (this.crmFallbackStub() && Date.now() < this.circuitOpenUntil) {
      this.log.warn(
        `CRM en cooldown; stub inmediato plan_id=${request.planId}`,
      );
      return this.stub.tarifar(request);
    }

    try {
      const result = await this.crm.calculoPrima(request);
      this.circuitOpenUntil = 0;
      return result;
    } catch (err) {
      if (!this.crmFallbackStub()) throw err;
      const msg = err instanceof Error ? err.message : String(err);
      this.circuitOpenUntil = Date.now() + CIRCUIT_COOLDOWN_MS;
      this.log.warn(
        `CRM calculoPrima falló (plan_id=${request.planId}); fallback stub ${CIRCUIT_COOLDOWN_MS / 1000}s. ${msg}`,
      );
      return this.stub.tarifar(request);
    }
  }
}
