import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsInt,
  IsOptional,
  IsString,
  Min,
  ValidateNested,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  VIAJERO_PLANES,
  VIAJERO_QUOTE_GENERATOR_ID,
} from '@/core/bus/bus-headers';

export class FieldLineDto {
  @ApiProperty({ example: 1651 })
  @IsInt()
  id!: number;

  @ApiProperty({ example: '2' })
  @IsString()
  value!: string;
}

export class TarifarDto {
  @ApiProperty({ example: VIAJERO_PLANES.PLUS_NACIONAL })
  @IsInt()
  planId!: number;

  @ApiProperty({ example: '2026-11-01' })
  @IsString()
  effectiveStartDate!: string;

  @ApiProperty({ example: '2026-11-15' })
  @IsString()
  effectiveEndDate!: string;

  @ApiProperty({ type: [FieldLineDto] })
  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => FieldLineDto)
  fieldLines!: FieldLineDto[];

  @ApiPropertyOptional({ example: VIAJERO_QUOTE_GENERATOR_ID })
  @IsOptional()
  @IsInt()
  quoteGeneratorId?: number;

  @ApiPropertyOptional({ example: '05' })
  @IsOptional()
  @IsString()
  codeDaneDepartment?: string;

  @ApiPropertyOptional({ example: '05088' })
  @IsOptional()
  @IsString()
  codeDaneCity?: string;
}

/**
 * Cotiza Plus + Pro en un solo request (2 llamadas CRM internas).
 * Nacional: 1454/1456 · Internacional: 1453/1455.
 */
export class TarifarPlanesDto {
  @ApiProperty({
    example: false,
    description:
      'true si origen y destino son Colombia (plan nacional); false = internacional',
  })
  @IsBoolean()
  esNacional!: boolean;

  @ApiProperty({ example: '2026-11-01' })
  @IsString()
  effectiveStartDate!: string;

  @ApiProperty({ example: '2026-11-15' })
  @IsString()
  effectiveEndDate!: string;

  @ApiProperty({ example: 1, minimum: 1 })
  @IsInt()
  @Min(1)
  cantidadViajeros!: number;

  @ApiPropertyOptional({ example: VIAJERO_QUOTE_GENERATOR_ID })
  @IsOptional()
  @IsInt()
  quoteGeneratorId?: number;

  @ApiPropertyOptional({ example: '11' })
  @IsOptional()
  @IsString()
  codeDaneDepartment?: string;

  @ApiPropertyOptional({ example: '11001' })
  @IsOptional()
  @IsString()
  codeDaneCity?: string;
}
