import { Module } from '@nestjs/common';
import { TarifacionController } from './tarifacion.controller';
import { TarifacionService } from './application/tarifacion.service';
import { TarifacionPort } from './domain/ports/tarifacion.port';
import { TarifacionHybridAdapter } from './infrastructure/tarifacion-hybrid.adapter';
import { TarifacionStubAdapter } from './infrastructure/tarifacion-stub.adapter';

@Module({
  controllers: [TarifacionController],
  providers: [
    TarifacionService,
    TarifacionStubAdapter,
    TarifacionHybridAdapter,
    { provide: TarifacionPort, useExisting: TarifacionHybridAdapter },
  ],
  exports: [TarifacionService, TarifacionPort],
})
export class TarifacionModule {}
