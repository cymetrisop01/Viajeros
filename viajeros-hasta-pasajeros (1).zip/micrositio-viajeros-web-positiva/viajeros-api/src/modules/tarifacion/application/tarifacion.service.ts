import { BadGatewayException, Injectable, Logger } from '@nestjs/common';
import {
  planIdsPorModalidad,
  VIAJERO_FIELD_VIAJEROS,
} from '@/core/bus/bus-headers';
import { TarifacionPort } from '../domain/ports/tarifacion.port';
import { TarifarDto, TarifarPlanesDto } from '../dto/tarifacion.dto';

export type PlanUiTarifa = {
  planUi: 'plus' | 'pro';
  planCrmId: number;
  quoterHeaderId: string;
  plan?: string;
  prima?: number;
  message?: string;
  fuente: string;
};

@Injectable()
export class TarifacionService {
  private readonly log = new Logger(TarifacionService.name);

  constructor(private readonly tarifacion: TarifacionPort) {}

  tarifar(dto: TarifarDto) {
    return this.tarifacion.tarifar(dto);
  }

  /**
   * Dos llamados CRM: Plus y Pro según modalidad nacional/internacional.
   */
  async tarifarPlanes(dto: TarifarPlanesDto): Promise<{
    esNacional: boolean;
    planes: PlanUiTarifa[];
  }> {
    const ids = planIdsPorModalidad(dto.esNacional);
    const fieldLines = [
      { id: VIAJERO_FIELD_VIAJEROS, value: String(dto.cantidadViajeros) },
    ];
    const base = {
      effectiveStartDate: dto.effectiveStartDate,
      effectiveEndDate: dto.effectiveEndDate,
      fieldLines,
      quoteGeneratorId: dto.quoteGeneratorId,
      codeDaneDepartment: dto.codeDaneDepartment,
      codeDaneCity: dto.codeDaneCity,
    };

    const specs: Array<{ planUi: 'plus' | 'pro'; planCrmId: number }> = [
      { planUi: 'plus', planCrmId: ids.plus },
      { planUi: 'pro', planCrmId: ids.pro },
    ];

    // Secuencial: PRE/APIcast satura con 2 calculoPrima en paralelo (~504 a 30s).
    const planes: PlanUiTarifa[] = [];
    const errors: string[] = [];

    for (const spec of specs) {
      try {
        const result = await this.tarifacion.tarifar({
          ...base,
          planId: spec.planCrmId,
        });
        planes.push({
          planUi: spec.planUi,
          planCrmId: spec.planCrmId,
          quoterHeaderId: result.quoterHeaderId,
          plan: result.plan,
          prima: result.prima,
          message: result.message,
          fuente: result.fuente,
        });
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        this.log.warn(
          `calculoPrima falló planUi=${spec.planUi} planId=${spec.planCrmId}: ${reason}`,
        );
        errors.push(`${spec.planUi}(${spec.planCrmId}): ${reason}`);
      }
    }

    if (!planes.length) {
      throw new BadGatewayException(
        `No se pudieron cotizar Plus/Pro en CRM: ${errors.join(' | ')}`,
      );
    }

    return { esNacional: dto.esNacional, planes };
  }
}
