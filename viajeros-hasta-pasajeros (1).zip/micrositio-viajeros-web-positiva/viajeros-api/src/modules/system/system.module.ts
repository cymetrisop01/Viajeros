import { Module } from '@nestjs/common';
import { SystemController } from './system.controller';
import { RuntimeDiagnosticsService } from './runtime-diagnostics.service';

@Module({
  controllers: [SystemController],
  providers: [RuntimeDiagnosticsService],
  exports: [RuntimeDiagnosticsService],
})
export class SystemModule {}
