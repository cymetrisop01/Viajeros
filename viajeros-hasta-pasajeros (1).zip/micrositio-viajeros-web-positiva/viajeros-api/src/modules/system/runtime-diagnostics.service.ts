import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApplicationInfoDto } from '@/common/dto/application-info.dto';
import { BusAuthTokenProvider } from '@/core/bus/bus-auth-token';
import { areIntegrationStubsAllowed } from '@/core/config/integration-stubs';

export type RuntimeDiagnosticsSnapshot = {
  info: ApplicationInfoDto;
  integrations: {
    stubsAllowed: boolean;
    busConfigured: boolean;
    identidadUrlConfigured: boolean;
    crmBaseConfigured: boolean;
  };
  fetchedAt: string;
};

@Injectable()
export class RuntimeDiagnosticsService {
  constructor(
    private readonly config: ConfigService,
    private readonly busAuth: BusAuthTokenProvider,
  ) {}

  snapshot(): RuntimeDiagnosticsSnapshot {
    const get = (key: string, defaultValue?: string): string | undefined => {
      const value = this.config.get<string>(key);
      if (value === undefined || value === null || value === '') {
        return defaultValue;
      }
      return value;
    };

    return {
      info: {
        name: 'viajeros-api',
        version: process.env.APP_VERSION ?? '0.2.2',
        description:
          'BFF NestJS Micrositio Viajeros Positiva Web. Orquestación hacia Bus/CRM (cotización, parametría y validación de identidad).',
      },
      integrations: {
        stubsAllowed: areIntegrationStubsAllowed(get),
        busConfigured: this.busAuth.isConfigured(),
        identidadUrlConfigured: Boolean(get('IDENTIDAD_API_URL')?.trim()),
        crmBaseConfigured: Boolean(get('CRM_API_BASE_URL')?.trim()),
      },
      fetchedAt: new Date().toISOString(),
    };
  }
}
