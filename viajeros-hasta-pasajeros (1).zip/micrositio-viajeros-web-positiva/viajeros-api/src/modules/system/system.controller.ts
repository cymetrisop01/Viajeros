import { Controller, Get } from '@nestjs/common';
import { ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ApplicationInfoDto } from '@/common/dto/application-info.dto';
import { Public } from '@/common/decorators/public.decorator';
import { RuntimeDiagnosticsService } from './runtime-diagnostics.service';

@ApiTags('System')
@Controller('system')
export class SystemController {
  constructor(private readonly diagnostics: RuntimeDiagnosticsService) {}

  @Public()
  @Get('info')
  @ApiOperation({
    summary: 'Metadatos del servicio',
    operationId: 'getSystemInfo',
  })
  @ApiOkResponse({ type: ApplicationInfoDto })
  getSystemInfo(): ApplicationInfoDto {
    return this.diagnostics.snapshot().info;
  }

  @Public()
  @Get('diagnostics')
  @ApiOperation({
    summary: 'Diagnóstico de runtime (sin secretos)',
    operationId: 'getRuntimeDiagnostics',
  })
  getDiagnostics() {
    return this.diagnostics.snapshot();
  }
}
