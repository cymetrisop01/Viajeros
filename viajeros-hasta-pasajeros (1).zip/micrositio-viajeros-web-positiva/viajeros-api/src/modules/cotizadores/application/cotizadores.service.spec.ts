import { describe, expect, it } from 'vitest';
import { CotizadoresService } from './cotizadores.service';
import type { CotizadorPort } from '../domain/ports/cotizador.port';

describe('CotizadoresService', () => {
  it('delegates listar and campos', async () => {
    const port: CotizadorPort = {
      listarCotizadores: async () => [{ id: 1255, nombre: 'VIAJERO 2026' }],
      mostrarCampos: async () => [{ id: 1651, nombre: 'N° Viajeros' }],
    };
    const service = new CotizadoresService(port);
    await expect(service.listar()).resolves.toEqual([
      { id: 1255, nombre: 'VIAJERO 2026' },
    ]);
    await expect(service.campos(1255)).resolves.toEqual([
      { id: 1651, nombre: 'N° Viajeros' },
    ]);
  });
});
