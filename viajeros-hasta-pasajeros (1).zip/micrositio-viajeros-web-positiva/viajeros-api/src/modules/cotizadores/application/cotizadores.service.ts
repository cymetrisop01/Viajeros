import { Injectable } from '@nestjs/common';
import { VIAJERO_QUOTE_GENERATOR_ID } from '@/core/bus/bus-headers';
import { CotizadorPort } from '../domain/ports/cotizador.port';

@Injectable()
export class CotizadoresService {
  constructor(private readonly cotizador: CotizadorPort) {}

  listar() {
    return this.cotizador.listarCotizadores();
  }

  campos(codigo?: number | string) {
    return this.cotizador.mostrarCampos(codigo ?? VIAJERO_QUOTE_GENERATOR_ID);
  }
}
