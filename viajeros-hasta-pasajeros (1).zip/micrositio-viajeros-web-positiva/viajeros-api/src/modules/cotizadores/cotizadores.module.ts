import { Module } from '@nestjs/common';
import { CotizadoresController } from './cotizadores.controller';
import { CotizadoresService } from './application/cotizadores.service';
import { CotizadorPort } from './domain/ports/cotizador.port';
import { CotizadorHybridAdapter } from './infrastructure/cotizador-hybrid.adapter';
import { CotizadorStubAdapter } from './infrastructure/cotizador-stub.adapter';

@Module({
  controllers: [CotizadoresController],
  providers: [
    CotizadoresService,
    CotizadorStubAdapter,
    CotizadorHybridAdapter,
    { provide: CotizadorPort, useExisting: CotizadorHybridAdapter },
  ],
  exports: [CotizadoresService, CotizadorPort],
})
export class CotizadoresModule {}
