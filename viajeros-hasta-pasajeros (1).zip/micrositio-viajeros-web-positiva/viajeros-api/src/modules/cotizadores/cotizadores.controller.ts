import { Controller, Get, Query } from '@nestjs/common';
import {
  ApiOkResponse,
  ApiOperation,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { Public } from '@/common/decorators/public.decorator';
import { VIAJERO_QUOTE_GENERATOR_ID } from '@/core/bus/bus-headers';
import { CotizadoresService } from './application/cotizadores.service';

@ApiTags('Cotizadores')
@Controller('cotizadores')
export class CotizadoresController {
  constructor(private readonly service: CotizadoresService) {}

  @Public()
  @Get()
  @ApiOperation({
    summary: 'Listar cotizadores CRM',
    description:
      'GET /v1/positiva/crm/listarCotizadores — producto VIAJERO 2026 (ID 1255) y planes 1453–1456.',
  })
  @ApiOkResponse({ description: 'Lista de cotizadores / planes' })
  listar() {
    return this.service.listar();
  }

  @Public()
  @Get('campos')
  @ApiOperation({
    summary: 'Campos dinámicos del cotizador',
    description:
      'GET /v1/positiva/crm/mostrarCamposCotizadores?codigo=1255 — formulario dinámico (no hardcodear campos).',
  })
  @ApiQuery({
    name: 'codigo',
    required: false,
    example: VIAJERO_QUOTE_GENERATOR_ID,
  })
  @ApiOkResponse({ description: 'Campos del cotizador' })
  campos(@Query('codigo') codigo?: string) {
    return this.service.campos(codigo ? Number(codigo) : undefined);
  }
}
