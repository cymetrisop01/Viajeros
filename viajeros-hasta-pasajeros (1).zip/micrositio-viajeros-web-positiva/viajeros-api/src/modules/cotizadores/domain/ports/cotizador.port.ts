export type CotizadorItem = {
  id: number | string;
  nombre: string;
  planes?: Array<{ id: number | string; nombre: string }>;
};

export type CampoCotizador = {
  id: number | string;
  nombre?: string;
  tipo?: string;
  obligatorio?: boolean;
};

export abstract class CotizadorPort {
  abstract listarCotizadores(): Promise<CotizadorItem[]>;
  abstract mostrarCampos(codigo?: number | string): Promise<CampoCotizador[]>;
}
