import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { areIntegrationStubsAllowed } from '@/core/config/integration-stubs';
import { CrmViajerosClient } from '@/core/crm/crm-viajeros.client';
import { VIAJERO_QUOTE_GENERATOR_ID } from '@/core/bus/bus-headers';
import {
  CampoCotizador,
  CotizadorItem,
  CotizadorPort,
} from '../domain/ports/cotizador.port';
import { CotizadorStubAdapter } from './cotizador-stub.adapter';

@Injectable()
export class CotizadorHybridAdapter extends CotizadorPort {
  constructor(
    private readonly config: ConfigService,
    private readonly stub: CotizadorStubAdapter,
    private readonly crm: CrmViajerosClient,
  ) {
    super();
  }

  private useStub(): boolean {
    const get = (key: string, def?: string) =>
      this.config.get<string>(key) ?? def;
    return areIntegrationStubsAllowed(get) || !this.crm.isEnabled();
  }

  listarCotizadores(): Promise<CotizadorItem[]> {
    if (this.useStub()) return this.stub.listarCotizadores();
    return this.crm.listarCotizadores();
  }

  mostrarCampos(
    codigo: number | string = VIAJERO_QUOTE_GENERATOR_ID,
  ): Promise<CampoCotizador[]> {
    if (this.useStub()) return this.stub.mostrarCampos(codigo);
    return this.crm.mostrarCamposCotizadores(codigo);
  }
}
