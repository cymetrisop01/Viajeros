import { Injectable } from '@nestjs/common';
import {
  VIAJERO_PLANES,
  VIAJERO_QUOTE_GENERATOR_ID,
} from '@/core/bus/bus-headers';
import {
  CampoCotizador,
  CotizadorItem,
  CotizadorPort,
} from '../domain/ports/cotizador.port';

@Injectable()
export class CotizadorStubAdapter extends CotizadorPort {
  async listarCotizadores(): Promise<CotizadorItem[]> {
    return [
      {
        id: VIAJERO_QUOTE_GENERATOR_ID,
        nombre: 'VIAJERO 2026',
        planes: [
          { id: VIAJERO_PLANES.PLUS_NACIONAL, nombre: 'VIAJERO PLUS NACIONAL' },
          {
            id: VIAJERO_PLANES.PLUS_INTERNACIONAL,
            nombre: 'VIAJERO PLUS INTERNACIONAL',
          },
          { id: VIAJERO_PLANES.PRO_NACIONAL, nombre: 'VIAJERO PRO NACIONAL' },
          {
            id: VIAJERO_PLANES.PRO_INTERNACIONAL,
            nombre: 'VIAJERO PRO INTERNACIONAL',
          },
        ],
      },
    ];
  }

  async mostrarCampos(
    _codigo: number | string = VIAJERO_QUOTE_GENERATOR_ID,
  ): Promise<CampoCotizador[]> {
    return [
      { id: 1651, nombre: 'N° Viajeros', tipo: 'number', obligatorio: true },
      { id: 1750, nombre: 'Nacionalidad', tipo: 'string', obligatorio: true },
      { id: 1653, nombre: 'Días cobertura', tipo: 'number', obligatorio: true },
      { id: 1654, nombre: 'Fecha salida', tipo: 'date', obligatorio: true },
      { id: 1655, nombre: 'Fecha regreso', tipo: 'date', obligatorio: true },
    ];
  }
}
