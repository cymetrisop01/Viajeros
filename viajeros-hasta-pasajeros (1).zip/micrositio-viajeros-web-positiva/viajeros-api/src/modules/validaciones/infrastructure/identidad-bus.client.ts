import {
  BadGatewayException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BusAuthTokenProvider } from '@/core/bus/bus-auth-token';
import {
  buildScpHeaders,
  DEFAULT_API_BASE,
  httpTimeoutMs,
} from '@/core/bus/bus-headers';
import {
  logUpstreamFailure,
  logUpstreamSuccess,
} from '@/core/http/log-upstream';
import {
  IdentidadConsultaRequest,
  IdentidadConsultaResultado,
  IdentidadPort,
} from '../domain/ports/identidad.port';

const DEFAULT_URL = `${DEFAULT_API_BASE}/identidad/v1/positiva/scp/validaridentidad`;

function toFechaMs(raw?: string): string {
  const s = (raw ?? '').trim();
  if (!s) return '';
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`;
  return s;
}

@Injectable()
export class IdentidadBusClient extends IdentidadPort {
  private readonly log = new Logger(IdentidadBusClient.name);

  constructor(
    private readonly config: ConfigService,
    private readonly auth: BusAuthTokenProvider,
  ) {
    super();
  }

  isEnabled(): boolean {
    return this.auth.isConfigured();
  }

  async consultar(
    request: IdentidadConsultaRequest,
  ): Promise<IdentidadConsultaResultado> {
    const url =
      this.config.get<string>('IDENTIDAD_API_URL')?.trim() || DEFAULT_URL;
    const timeoutMs = httpTimeoutMs(this.config);
    const token = await this.auth.getAccessToken();

    // Contrato BUS IdentidadDTO: tipoDocumento, documento, fechaNacimiento (dd/MM/yyyy).
    const body = {
      tipoDocumento: request.tipoDocumento.trim().toUpperCase(),
      documento: request.numeroDocumento.trim().replace(/\s/g, ''),
      fechaNacimiento: toFechaMs(request.fechaNacimiento),
    };

    const meta = {
      sistema: 'BUS-Identidad',
      method: 'POST',
      url,
      timeoutMs,
      startedAt: Date.now(),
      requestBody: body,
    };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res: Response;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: buildScpHeaders(this.config, token),
        body: JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logUpstreamFailure(this.log, meta, { cause: e });
      throw new ServiceUnavailableException({
        status: 503,
        title: 'Service Unavailable',
        detail: `No se pudo contactar validaridentidad: ${msg}`,
      });
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text().catch(() => '');
    if (!res.ok) {
      logUpstreamFailure(this.log, meta, { status: res.status, body: text });
      if (res.status === 401 || res.status === 403) this.auth.invalidate();
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: `validaridentidad respondió ${res.status}.`,
      });
    }
    logUpstreamSuccess(this.log, meta, { status: res.status, body: text });

    let parsed: Record<string, unknown> = {};
    try {
      parsed = text ? (JSON.parse(text) as Record<string, unknown>) : {};
    } catch {
      parsed = {};
    }

    const data =
      (parsed.data as Record<string, unknown>) ||
      (parsed.result as Record<string, unknown>) ||
      (parsed.message as Record<string, unknown>) ||
      parsed;

    const valido =
      data.validacionSatisfactoria === true ||
      data.valido === true ||
      data.existe === true ||
      Boolean(data.primerNombre || data.first_name);

    return {
      valido,
      tipoDocumento: request.tipoDocumento,
      numeroDocumento: request.numeroDocumento,
      primerNombre:
        String(data.primerNombre ?? data.first_name ?? '').trim() || undefined,
      primerApellido:
        String(data.primerApellido ?? data.last_name ?? '').trim() || undefined,
      fuente: 'bus',
      mensaje: data.estadoValidacion
        ? String(data.estadoValidacion)
        : undefined,
      consultadoEn: new Date().toISOString(),
    };
  }
}
