import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { areIntegrationStubsAllowed } from '@/core/config/integration-stubs';
import {
  IdentidadConsultaRequest,
  IdentidadConsultaResultado,
  IdentidadPort,
} from '../domain/ports/identidad.port';
import { IdentidadBusClient } from './identidad-bus.client';
import { IdentidadStubAdapter } from './identidad-stub.adapter';

@Injectable()
export class IdentidadHybridAdapter extends IdentidadPort {
  constructor(
    private readonly config: ConfigService,
    private readonly stub: IdentidadStubAdapter,
    private readonly bus: IdentidadBusClient,
  ) {
    super();
  }

  consultar(
    request: IdentidadConsultaRequest,
  ): Promise<IdentidadConsultaResultado> {
    const get = (key: string, def?: string) =>
      this.config.get<string>(key) ?? def;
    if (areIntegrationStubsAllowed(get) || !this.bus.isEnabled()) {
      return this.stub.consultar(request);
    }
    return this.bus.consultar(request);
  }
}
