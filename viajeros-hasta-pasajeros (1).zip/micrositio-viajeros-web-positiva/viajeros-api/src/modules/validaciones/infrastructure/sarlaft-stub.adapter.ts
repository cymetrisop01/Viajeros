import { Injectable } from '@nestjs/common';
import {
  SarlaftConsultaRequest,
  SarlaftConsultaResultado,
  SarlaftPort,
} from '../domain/ports/sarlaft.port';

/** Stub local WS-VIAJ-008…011. */
@Injectable()
export class SarlaftStubAdapter extends SarlaftPort {
  async consultar(
    _request: SarlaftConsultaRequest,
  ): Promise<SarlaftConsultaResultado> {
    return {
      aprobado: true,
      riesgo: 'BAJO',
      fuente: 'stub',
      consultadoEn: new Date().toISOString(),
    };
  }
}
