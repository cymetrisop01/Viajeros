import { Injectable } from '@nestjs/common';
import {
  IdentidadConsultaRequest,
  IdentidadConsultaResultado,
  IdentidadPort,
} from '../domain/ports/identidad.port';

/** Stub local WS-VIAJ-006. */
@Injectable()
export class IdentidadStubAdapter extends IdentidadPort {
  async consultar(
    request: IdentidadConsultaRequest,
  ): Promise<IdentidadConsultaResultado> {
    return {
      valido: true,
      tipoDocumento: request.tipoDocumento,
      numeroDocumento: request.numeroDocumento,
      primerNombre: 'Viajero',
      primerApellido: 'Demo',
      fuente: 'stub',
      consultadoEn: new Date().toISOString(),
    };
  }
}
