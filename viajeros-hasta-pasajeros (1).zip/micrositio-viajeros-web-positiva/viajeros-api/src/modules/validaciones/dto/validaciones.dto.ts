import { IsOptional, IsString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class IdentidadDto {
  @ApiProperty({ example: 'CC' })
  @IsString()
  tipoDocumento!: string;

  @ApiProperty({ example: '1083022490' })
  @IsString()
  numeroDocumento!: string;

  @ApiProperty({
    example: '1985-08-30',
    description: 'Obligatoria según RN guía Viajeros (fecha de nacimiento).',
  })
  @IsString()
  fechaNacimiento!: string;
}

export class SarlaftDto {
  @ApiProperty({ example: 'CC' })
  @IsString()
  tipoDocumento!: string;

  @ApiProperty({ example: '1083022490' })
  @IsString()
  numeroDocumento!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  fechaNacimiento?: string;
}
