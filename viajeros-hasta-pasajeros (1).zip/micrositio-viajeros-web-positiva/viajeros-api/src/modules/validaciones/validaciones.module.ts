import { Module } from '@nestjs/common';
import { ValidacionesController } from './validaciones.controller';
import { ValidacionesService } from './application/validaciones.service';
import { IdentidadPort } from './domain/ports/identidad.port';
import { SarlaftPort } from './domain/ports/sarlaft.port';
import { IdentidadBusClient } from './infrastructure/identidad-bus.client';
import { IdentidadHybridAdapter } from './infrastructure/identidad-hybrid.adapter';
import { IdentidadStubAdapter } from './infrastructure/identidad-stub.adapter';
import { SarlaftStubAdapter } from './infrastructure/sarlaft-stub.adapter';

@Module({
  controllers: [ValidacionesController],
  providers: [
    ValidacionesService,
    IdentidadStubAdapter,
    IdentidadBusClient,
    IdentidadHybridAdapter,
    SarlaftStubAdapter,
    { provide: IdentidadPort, useExisting: IdentidadHybridAdapter },
    { provide: SarlaftPort, useExisting: SarlaftStubAdapter },
  ],
  exports: [ValidacionesService, IdentidadPort, SarlaftPort],
})
export class ValidacionesModule {}
