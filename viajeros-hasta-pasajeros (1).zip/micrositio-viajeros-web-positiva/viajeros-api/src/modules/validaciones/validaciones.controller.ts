import { Body, Controller, Post } from '@nestjs/common';
import { ApiBody, ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Public } from '@/common/decorators/public.decorator';
import { ValidacionesService } from './application/validaciones.service';
import { IdentidadDto, SarlaftDto } from './dto/validaciones.dto';

@ApiTags('Validaciones')
@Controller('validaciones')
export class ValidacionesController {
  constructor(private readonly service: ValidacionesService) {}

  @Public()
  @Post('identidad')
  @ApiOperation({
    summary: 'Validar identidad BUS',
    description:
      'POST /identidad/v1/positiva/scp/validaridentidad. El BFF acepta numeroDocumento y lo mapea a documento (contrato BUS). fechaNacimiento obligatoria (ISO o dd/MM/yyyy).',
  })
  @ApiBody({ type: IdentidadDto })
  @ApiOkResponse({ description: 'Resultado de identidad' })
  identidad(@Body() dto: IdentidadDto) {
    return this.service.consultarIdentidad(dto);
  }

  @Public()
  @Post('sarlaft')
  @ApiOperation({
    summary: 'Consulta SARLAFT (stub hasta contratos definitivos)',
  })
  @ApiBody({ type: SarlaftDto })
  sarlaft(@Body() dto: SarlaftDto) {
    return this.service.consultarSarlaft(dto);
  }
}
