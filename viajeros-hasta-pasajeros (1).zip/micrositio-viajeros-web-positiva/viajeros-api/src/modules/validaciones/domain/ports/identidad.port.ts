export type IdentidadConsultaRequest = {
  tipoDocumento: string;
  numeroDocumento: string;
  fechaNacimiento?: string;
};

export type IdentidadConsultaResultado = {
  valido: boolean;
  tipoDocumento: string;
  numeroDocumento: string;
  primerNombre?: string;
  primerApellido?: string;
  fuente: string;
  mensaje?: string;
  consultadoEn: string;
};

export abstract class IdentidadPort {
  abstract consultar(
    request: IdentidadConsultaRequest,
  ): Promise<IdentidadConsultaResultado>;
}
