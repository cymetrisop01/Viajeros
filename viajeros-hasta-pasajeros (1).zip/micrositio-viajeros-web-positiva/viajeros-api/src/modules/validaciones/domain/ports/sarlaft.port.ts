export type SarlaftConsultaRequest = {
  tipoDocumento: string;
  numeroDocumento: string;
};

export type SarlaftConsultaResultado = {
  aprobado: boolean;
  riesgo: 'BAJO' | 'MEDIO' | 'ALTO' | 'BLOQUEADO';
  fuente: string;
  mensaje?: string;
  consultadoEn: string;
};

export abstract class SarlaftPort {
  abstract consultar(
    request: SarlaftConsultaRequest,
  ): Promise<SarlaftConsultaResultado>;
}
