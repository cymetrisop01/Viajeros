import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IdentidadPort } from '../domain/ports/identidad.port';
import { SarlaftPort } from '../domain/ports/sarlaft.port';
import { IdentidadDto, SarlaftDto } from '../dto/validaciones.dto';

@Injectable()
export class ValidacionesService {
  constructor(
    private readonly identidad: IdentidadPort,
    private readonly sarlaft: SarlaftPort,
    private readonly config: ConfigService,
  ) {}

  consultarIdentidad(dto: IdentidadDto) {
    return this.identidad.consultar(dto);
  }

  async consultarSarlaft(dto: SarlaftDto) {
    const maxAttempts = Math.max(
      1,
      Number(this.config.get<string>('SARLAFT_MAX_ATTEMPTS')) || 2,
    );
    let last: Awaited<ReturnType<SarlaftPort['consultar']>> | undefined;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      last = await this.sarlaft.consultar(dto);
      if (last.aprobado) return last;
    }
    return last!;
  }
}
