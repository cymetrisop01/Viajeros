import { Injectable } from '@nestjs/common';
import { ParametriaPort } from '../domain/ports/parametria.port';

@Injectable()
export class ParametriaService {
  constructor(private readonly parametria: ParametriaPort) {}

  listarPaises() {
    return this.parametria.listarPaises();
  }

  divisionPolitica(idPais: string) {
    return this.parametria.consultarDivisionPolitica(idPais);
  }

  listarTiposDocumento() {
    return this.parametria.listarTiposDocumento();
  }
}
