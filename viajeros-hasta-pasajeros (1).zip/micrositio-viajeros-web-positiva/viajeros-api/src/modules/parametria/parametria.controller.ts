import { Controller, Get, Query } from '@nestjs/common';
import {
  ApiOkResponse,
  ApiOperation,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { Public } from '@/common/decorators/public.decorator';
import { ParametriaService } from './application/parametria.service';

@ApiTags('Parametria')
@Controller('parametria')
export class ParametriaController {
  constructor(private readonly service: ParametriaService) {}

  @Public()
  @Get('paises')
  @ApiOperation({
    summary: 'Listar países',
    description:
      'GET /pais/v1/positiva/scp/parametrica/consultaPais (colección Postman).',
  })
  @ApiOkResponse({ description: 'Catálogo de países' })
  listarPaises() {
    return this.service.listarPaises();
  }

  @Public()
  @Get('division-politica')
  @ApiOperation({
    summary: 'División política por país',
    description:
      'GET /pdp/v1/positiva/scp/parametrica/consultaDivisionPolitica?idPais=',
  })
  @ApiQuery({ name: 'idPais', required: true, example: '840' })
  @ApiOkResponse({ description: 'Estados / divisiones del país' })
  divisionPolitica(@Query('idPais') idPais: string) {
    return this.service.divisionPolitica(idPais);
  }

  @Public()
  @Get('tipos-documento')
  @ApiOperation({
    summary: 'Tipos de documento de identidad',
    description:
      'Catálogo local de tipos de documento. ' +
      'No hay WS BUS dedicado; se usa un seed local.',
  })
  @ApiOkResponse({ description: 'Lista codigo/nombre (CC, CE, TI, PA, NIT)' })
  listarTiposDocumento() {
    return this.service.listarTiposDocumento();
  }
}
