import { Module } from '@nestjs/common';
import { ParametriaController } from './parametria.controller';
import { ParametriaService } from './application/parametria.service';
import { ParametriaPort } from './domain/ports/parametria.port';
import { BusDivisionPoliticaClient } from './infrastructure/bus-division-politica.client';
import { BusPaisesClient } from './infrastructure/bus-paises.client';
import { ParametriaHybridAdapter } from './infrastructure/parametria-hybrid.adapter';
import { ParametriaStubAdapter } from './infrastructure/parametria-stub.adapter';

@Module({
  controllers: [ParametriaController],
  providers: [
    ParametriaService,
    ParametriaStubAdapter,
    BusPaisesClient,
    BusDivisionPoliticaClient,
    ParametriaHybridAdapter,
    { provide: ParametriaPort, useExisting: ParametriaHybridAdapter },
  ],
  exports: [ParametriaService, ParametriaPort],
})
export class ParametriaModule {}
