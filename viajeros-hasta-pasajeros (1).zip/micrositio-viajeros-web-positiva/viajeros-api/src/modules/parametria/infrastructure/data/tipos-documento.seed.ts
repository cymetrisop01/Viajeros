import type { TipoDocumentoItem } from '../../domain/ports/parametria.port';

/**
 * Catálogo local de tipos de documento
 * (`CATALOGO_TIPOS_DOCUMENTO` + labels amigables del front MOCK_TIPOS_DOCUMENTO).
 * No existe WS BUS dedicado para tipos de documento de identidad.
 */
export const TIPOS_DOCUMENTO_SEED: TipoDocumentoItem[] = [
  { codigo: 'CC', nombre: 'Cédula de ciudadanía' },
  { codigo: 'CE', nombre: 'Cédula de extranjería' },
  { codigo: 'TI', nombre: 'Tarjeta de identidad' },
  { codigo: 'PA', nombre: 'Pasaporte' },
  { codigo: 'NIT', nombre: 'NIT' },
];
