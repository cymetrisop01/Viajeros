import {
  BadGatewayException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BusAuthTokenProvider } from '@/core/bus/bus-auth-token';
import {
  buildScpHeaders,
  DEFAULT_API_BASE,
  httpTimeoutMs,
} from '@/core/bus/bus-headers';
import {
  logUpstreamFailure,
  logUpstreamSuccess,
} from '@/core/http/log-upstream';
import type { DivisionPoliticaItem } from '../domain/ports/parametria.port';

const DEFAULT_URL = `${DEFAULT_API_BASE}/pdp/v1/positiva/scp/parametrica/consultaDivisionPolitica`;

type DivisionRaw = Record<string, unknown>;

function pick(row: DivisionRaw, ...keys: string[]): string {
  for (const k of keys) {
    const v = row[k];
    if (v != null && String(v).trim()) return String(v).trim();
  }
  return '';
}

export function mapDivisionRaw(
  row: DivisionRaw,
  idPais: string,
): DivisionPoliticaItem | null {
  const id = pick(
    row,
    'idDivisionPolitica',
    'idDivisonPolitica',
    'ID_DIVISION_POLITICA',
    'id',
    'codigo',
    'CONSECUTIVO',
  );
  const nombre = pick(
    row,
    'nombreEstado',
    'NOMBRE_ESTADO',
    'nombre',
    'NOMBRE',
    'nombreDivision',
    'descripcion',
  );
  if (!id && !nombre) return null;
  return {
    id: id || nombre,
    nombre: nombre || id,
    idPais: pick(row, 'idPais', 'ID_PAIS') || idPais,
    tipo: pick(row, 'tipo', 'TIPO') || undefined,
  };
}

export function extractDivisionArray(parsed: unknown): DivisionRaw[] {
  if (Array.isArray(parsed)) return parsed as DivisionRaw[];
  if (parsed && typeof parsed === 'object') {
    const o = parsed as Record<string, unknown>;
    for (const key of ['data', 'result', 'message', 'items', 'divisiones']) {
      if (Array.isArray(o[key])) return o[key] as DivisionRaw[];
    }
  }
  return [];
}

/** Cliente HTTP → WS Paramétrica consultaDivisionPolitica. */
@Injectable()
export class BusDivisionPoliticaClient {
  private readonly log = new Logger(BusDivisionPoliticaClient.name);

  constructor(
    private readonly config: ConfigService,
    private readonly auth: BusAuthTokenProvider,
  ) {}

  isEnabled(): boolean {
    return this.auth.isConfigured();
  }

  async consultarDivisionPolitica(
    idPais: string,
  ): Promise<DivisionPoliticaItem[]> {
    const base =
      this.config.get<string>('BUS_DIVISION_POLITICA_API_URL')?.trim() ||
      DEFAULT_URL;
    const url = `${base}?idPais=${encodeURIComponent(idPais)}`;
    const timeoutMs = httpTimeoutMs(this.config);
    const token = await this.auth.getAccessToken();

    const meta = {
      sistema: 'BUS-DivisionPolitica',
      method: 'GET',
      url,
      timeoutMs,
      startedAt: Date.now(),
    };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res: Response;
    try {
      res = await fetch(url, {
        method: 'GET',
        headers: buildScpHeaders(this.config, token),
        signal: controller.signal,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logUpstreamFailure(this.log, meta, { cause: e });
      throw new ServiceUnavailableException({
        status: 503,
        title: 'Service Unavailable',
        detail: `No se pudo contactar consultaDivisionPolitica: ${msg}`,
      });
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text().catch(() => '');
    if (!res.ok) {
      logUpstreamFailure(this.log, meta, { status: res.status, body: text });
      if (res.status === 401 || res.status === 403) this.auth.invalidate();
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: `consultaDivisionPolitica respondió ${res.status}.`,
      });
    }
    logUpstreamSuccess(this.log, meta, { status: res.status, body: text });

    let parsed: unknown = [];
    try {
      parsed = text ? JSON.parse(text) : [];
    } catch {
      parsed = [];
    }

    const rawRows = extractDivisionArray(parsed);
    const items = rawRows
      .map(row => mapDivisionRaw(row, idPais))
      .filter((x): x is DivisionPoliticaItem => Boolean(x));
    if (rawRows.length > 0 && items.length === 0) {
      this.log.warn(
        `[BUS-DivisionPolitica] ${rawRows.length} filas sin mapear; keys=${Object.keys(rawRows[0] ?? {}).join(',')}`,
      );
    }
    return items;
  }
}
