import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { areIntegrationStubsAllowed } from '@/core/config/integration-stubs';
import {
  DivisionPoliticaItem,
  PaisItem,
  ParametriaPort,
  TipoDocumentoItem,
} from '../domain/ports/parametria.port';
import { BusDivisionPoliticaClient } from './bus-division-politica.client';
import { BusPaisesClient } from './bus-paises.client';
import { ParametriaStubAdapter } from './parametria-stub.adapter';

@Injectable()
export class ParametriaHybridAdapter extends ParametriaPort {
  constructor(
    private readonly config: ConfigService,
    private readonly stub: ParametriaStubAdapter,
    private readonly paises: BusPaisesClient,
    private readonly division: BusDivisionPoliticaClient,
  ) {
    super();
  }

  private useStub(): boolean {
    const get = (key: string, def?: string) =>
      this.config.get<string>(key) ?? def;
    if (areIntegrationStubsAllowed(get)) return true;
    return !this.paises.isEnabled();
  }

  listarPaises(): Promise<PaisItem[]> {
    if (this.useStub()) return this.stub.listarPaises();
    return this.paises.listarPaises();
  }

  consultarDivisionPolitica(idPais: string): Promise<DivisionPoliticaItem[]> {
    if (this.useStub() || !this.division.isEnabled()) {
      return this.stub.consultarDivisionPolitica(idPais);
    }
    return this.division.consultarDivisionPolitica(idPais);
  }

  /** Catálogo local (no hay WS BUS dedicado). */
  listarTiposDocumento(): Promise<TipoDocumentoItem[]> {
    return this.stub.listarTiposDocumento();
  }
}
