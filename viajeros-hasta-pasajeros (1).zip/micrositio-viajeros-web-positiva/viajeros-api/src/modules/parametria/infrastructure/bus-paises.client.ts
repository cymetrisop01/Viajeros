import {
  BadGatewayException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BusAuthTokenProvider } from '@/core/bus/bus-auth-token';
import {
  buildScpHeaders,
  DEFAULT_API_BASE,
  httpTimeoutMs,
} from '@/core/bus/bus-headers';
import {
  logUpstreamFailure,
  logUpstreamSuccess,
} from '@/core/http/log-upstream';
import type { PaisItem } from '../domain/ports/parametria.port';

const DEFAULT_URL = `${DEFAULT_API_BASE}/pais/v1/positiva/scp/parametrica/consultaPais`;

type PaisRaw = Record<string, unknown>;

function pick(row: PaisRaw, ...keys: string[]): string {
  for (const k of keys) {
    const v = row[k];
    if (v != null && String(v).trim()) return String(v).trim();
  }
  return '';
}

export function mapPaisRaw(row: PaisRaw): PaisItem | null {
  const codigo = pick(
    row,
    'idPais',
    'ID_PAIS',
    'codigo',
    'CODIGO',
    'codigoPais',
    'id',
  );
  const nombre = pick(
    row,
    'nombrePais',
    'NOMBRE_PAIS',
    'nombre',
    'NOMBRE',
    'descripcion',
  );
  if (!codigo && !nombre) return null;
  return {
    codigo: codigo || nombre,
    nombre: nombre || codigo,
    iso2: pick(row, 'iso2', 'ISO2', 'codigoIso2') || undefined,
    iso3: pick(row, 'iso3', 'ISO3', 'codigoIso3') || undefined,
  };
}

export function extractPaisArray(parsed: unknown): PaisRaw[] {
  if (Array.isArray(parsed)) return parsed as PaisRaw[];
  if (parsed && typeof parsed === 'object') {
    const o = parsed as Record<string, unknown>;
    for (const key of ['data', 'result', 'message', 'paises', 'items']) {
      if (Array.isArray(o[key])) return o[key] as PaisRaw[];
    }
  }
  return [];
}

/** Cliente HTTP → WS Paramétrica consultaPais (colección Postman). */
@Injectable()
export class BusPaisesClient {
  private readonly log = new Logger(BusPaisesClient.name);
  private cache: PaisItem[] | null = null;
  private cacheAt = 0;

  constructor(
    private readonly config: ConfigService,
    private readonly auth: BusAuthTokenProvider,
  ) {}

  isEnabled(): boolean {
    return this.auth.isConfigured();
  }

  async listarPaises(): Promise<PaisItem[]> {
    const ttl =
      Number(this.config.get<string>('BUS_CACHE_TTL_MS')) || 3_600_000;
    if (this.cache && Date.now() - this.cacheAt < ttl) return this.cache;

    const url =
      this.config.get<string>('BUS_PAISES_API_URL')?.trim() || DEFAULT_URL;
    const timeoutMs = httpTimeoutMs(this.config);
    const token = await this.auth.getAccessToken();

    const meta = {
      sistema: 'BUS-Paises',
      method: 'GET',
      url,
      timeoutMs,
      startedAt: Date.now(),
    };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res: Response;
    try {
      res = await fetch(url, {
        method: 'GET',
        headers: buildScpHeaders(this.config, token),
        signal: controller.signal,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logUpstreamFailure(this.log, meta, { cause: e });
      throw new ServiceUnavailableException({
        status: 503,
        title: 'Service Unavailable',
        detail: `No se pudo contactar consultaPais: ${msg}`,
      });
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text().catch(() => '');
    if (!res.ok) {
      logUpstreamFailure(this.log, meta, { status: res.status, body: text });
      if (res.status === 401 || res.status === 403) this.auth.invalidate();
      throw new BadGatewayException({
        status: 502,
        title: 'Bad Gateway',
        detail: `consultaPais respondió ${res.status}.`,
      });
    }
    logUpstreamSuccess(this.log, meta, { status: res.status, body: text });

    let parsed: unknown = [];
    try {
      parsed = text ? JSON.parse(text) : [];
    } catch {
      parsed = [];
    }

    const items = extractPaisArray(parsed)
      .map(mapPaisRaw)
      .filter((x): x is PaisItem => Boolean(x));

    this.cache = items;
    this.cacheAt = Date.now();
    return items;
  }
}
