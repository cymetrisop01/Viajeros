import { describe, expect, it } from 'vitest';
import { extractPaisArray, mapPaisRaw } from './bus-paises.client';
import {
  extractDivisionArray,
  mapDivisionRaw,
} from './bus-division-politica.client';

describe('mapPaisRaw', () => {
  it('maps idPais/nombrePais', () => {
    expect(
      mapPaisRaw({ idPais: '840', nombrePais: 'Estados Unidos', iso2: 'US' }),
    ).toEqual({
      codigo: '840',
      nombre: 'Estados Unidos',
      iso2: 'US',
      iso3: undefined,
    });
  });

  it('returns null when empty', () => {
    expect(mapPaisRaw({})).toBeNull();
  });
});

describe('extractPaisArray', () => {
  it('unwraps data array', () => {
    expect(extractPaisArray({ data: [{ idPais: '170' }] })).toHaveLength(1);
  });
});

describe('mapDivisionRaw', () => {
  it('maps division politica', () => {
    expect(
      mapDivisionRaw({ idDivisionPolitica: 'NY', nombre: 'New York' }, '840'),
    ).toEqual({
      id: 'NY',
      nombre: 'New York',
      idPais: '840',
      tipo: undefined,
    });
  });

  it('maps contrato BUS (idDivisonPolitica / nombreEstado)', () => {
    expect(
      mapDivisionRaw(
        {
          idPais: 840,
          nombrePais: 'ESTADOS UNIDOS',
          idDivisonPolitica: 1,
          nombreEstado: 'ALABAMA',
        },
        '840',
      ),
    ).toEqual({
      id: '1',
      nombre: 'ALABAMA',
      idPais: '840',
      tipo: undefined,
    });
  });
});

describe('extractDivisionArray', () => {
  it('accepts top-level array', () => {
    expect(extractDivisionArray([{ id: 1 }])).toHaveLength(1);
  });
});
