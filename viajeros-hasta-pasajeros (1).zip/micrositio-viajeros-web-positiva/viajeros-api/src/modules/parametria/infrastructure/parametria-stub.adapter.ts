import { Injectable } from '@nestjs/common';
import {
  DivisionPoliticaItem,
  PaisItem,
  ParametriaPort,
  TipoDocumentoItem,
} from '../domain/ports/parametria.port';
import { TIPOS_DOCUMENTO_SEED } from './data/tipos-documento.seed';

@Injectable()
export class ParametriaStubAdapter extends ParametriaPort {
  async listarPaises(): Promise<PaisItem[]> {
    return [
      { codigo: '170', nombre: 'Colombia', iso2: 'CO', iso3: 'COL' },
      { codigo: '840', nombre: 'Estados Unidos', iso2: 'US', iso3: 'USA' },
      { codigo: '724', nombre: 'España', iso2: 'ES', iso3: 'ESP' },
      { codigo: '484', nombre: 'México', iso2: 'MX', iso3: 'MEX' },
    ];
  }

  async consultarDivisionPolitica(
    idPais: string,
  ): Promise<DivisionPoliticaItem[]> {
    if (idPais === '170' || idPais === 'CO') {
      return [
        { id: '11', nombre: 'Bogotá, D.C.', idPais, tipo: 'departamento' },
        { id: '05', nombre: 'Antioquia', idPais, tipo: 'departamento' },
      ];
    }
    return [
      { id: 'NY', nombre: 'New York', idPais, tipo: 'estado' },
      { id: 'CA', nombre: 'California', idPais, tipo: 'estado' },
    ];
  }

  async listarTiposDocumento(): Promise<TipoDocumentoItem[]> {
    return [...TIPOS_DOCUMENTO_SEED];
  }
}
