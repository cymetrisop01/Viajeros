export type PaisItem = {
  /** Código / id del país (p. ej. ISO numérico o interno BUS). */
  codigo: string;
  nombre: string;
  iso2?: string;
  iso3?: string;
};

export type DivisionPoliticaItem = {
  id: string;
  nombre: string;
  idPais: string;
  tipo?: string;
};

/** Catálogo de tipos de documento (seed local). */
export type TipoDocumentoItem = {
  codigo: string;
  nombre: string;
};

export abstract class ParametriaPort {
  abstract listarPaises(): Promise<PaisItem[]>;
  abstract consultarDivisionPolitica(
    idPais: string,
  ): Promise<DivisionPoliticaItem[]>;
  abstract listarTiposDocumento(): Promise<TipoDocumentoItem[]>;
}
