import { Controller, Get } from '@nestjs/common';
import { ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { HealthResponseDto } from '@/common/dto/health-response.dto';
import { Public } from '@/common/decorators/public.decorator';
import { AppService } from './app.service';

@ApiTags('Health')
@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  /** Health check ALB/ECS: `GET /health` (fuera del prefijo API). */
  @Public()
  @Get('health')
  @ApiOperation({
    summary: 'Health check',
    description:
      'Comprobación de vida para ALB/ECS. No consulta integraciones externas.',
  })
  @ApiOkResponse({ type: HealthResponseDto })
  getHealth(): HealthResponseDto {
    return this.appService.getHealth();
  }
}
