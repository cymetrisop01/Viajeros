#!/usr/bin/env bash
# Pruebas unitarias del BFF NestJS (víajeros-api).
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${ROOT}/viajeros-api"

if [[ ! -f "${APP_DIR}/package.json" ]]; then
  echo "No se encontró viajeros-api/package.json" >&2
  exit 1
fi

cd "${APP_DIR}"

export HUSKY=0
export CI=true

if [[ ! -d node_modules ]]; then
  npm ci --ignore-scripts
fi

npm test
