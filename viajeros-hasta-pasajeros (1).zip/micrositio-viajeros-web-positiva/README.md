# Micrositio Viajeros – Backend (NestJS)

BFF NestJS del Micrositio Viajeros de Positiva Web. Expone al frontend la cotización de planes, la parametría (países, división política y tipos de documento) y la validación de identidad del viajero.

Alcance de esta entrega: endpoints necesarios hasta la captura de datos de los pasajeros (paso 2 del flujo).

## Stack

| Elemento | Valor |
| --- | --- |
| Runtime | NestJS 11 / Node 22 |
| Código | `/viajeros-api` |
| Dockerfile | `/docker/Dockerfile` |
| Puerto (imagen Docker) | `5000/TCP` |
| Puerto local (`npm run start:dev`) | `5001` (`PORT` en `.env`; el 5000 de macOS lo usa AirPlay) |
| Health | `GET /health` → `200 OK` |
| Prefijo API | `/api/viajeros/v1` |
| Usuario contenedor | UID `10001` (no root) |

## Endpoints principales

| Módulo | Uso |
| --- | --- |
| `parametria` | Países, división política y tipos de documento |
| `tarifacion` / `cotizadores` | Cálculo de prima y planes Plus / Pro (CRM) |
| `validaciones` | Validación de identidad (BUS) |
| `system` | Metadatos y diagnóstico de runtime |

## Desarrollo local (sin Docker)

```bash
cd viajeros-api
cp .env.example .env   # completar credenciales de Keycloak/BUS
npm ci
npm run start:dev
```

- Health: http://localhost:5001/health
- Swagger: http://localhost:5001/docs

Con `ALLOW_INTEGRATION_STUBS=true` el BFF responde con datos de referencia cuando las integraciones no están configuradas.

## Pruebas

```bash
cd viajeros-api
npm test          # Vitest
npm run test:e2e  # build + smoke test
```

## Docker local

```bash
# Desde la raíz del proyecto
docker compose up --build

curl -s http://localhost:5001/health
curl -s http://localhost:5001/api/viajeros/v1/system/info
```

Build manual:

```bash
docker build -f docker/Dockerfile -t micrositio-viajeros-web-positiva:local .
```

Los secretos (Keycloak/BUS, CRM) **no** van en la imagen: se inyectan como variables de entorno en el despliegue.
